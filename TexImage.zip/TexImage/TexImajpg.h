#pragma once

#include "BasicType/All.h"


#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 



#include "TexImageBase.h"


#include "TexImagePalette.h"


namespace EngineNamespace
{






	namespace TexImage
	{



		#if TEXIMAGE_SUPPORT_JPEG






		class _PLATFORM_DECL TextureImageJPG : public TextureImageBase
		{
		protected:
			void CreateGrayColourMap(int n);
		public:
			TextureImageJPG();
			virtual ~TextureImageJPG();

			TextureImagePalette Palette;

			virtual bool ReadFile(FileIO::Path& imageFileName );
			virtual bool SaveFile(FileIO::Path& imageFileName, BasicType::String oldExt = "");

			void SetColorSpace(int);



		};


		#endif


	}; // namespace

}; // namespace EngineNamespace



