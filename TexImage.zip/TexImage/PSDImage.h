#pragma once

#include "BasicType\All.h"
#include "FileIO\Path.h"
#include "TexImageBase.h"

#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Q Suhmoon, Yongjin Kwon
// Summary : 
// 
//------------------------------------------------------------ 

namespace EngineNamespace
{
	namespace TexImage
	{
		class _PLATFORM_DECL TextureImagePSD : public TextureImageBase
		{
		public:
			
			TextureImagePSD();
			~TextureImagePSD();
			
			
			
			virtual bool ReadFile(FileIO::Path& fileName);
			virtual bool SaveFile(FileIO::Path& imageFileName, BasicType::String oldExt = "");
			
		};
	}
}