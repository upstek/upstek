#pragma once

#include "BasicType/All.h"


#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 





#include "TexImageBase.h"


#include "TexImagePalette.h"

#include "FileIO/VFS.h"




namespace EngineNamespace
{






	namespace TexImage
	{


	#if TEXIMAGE_SUPPORT_GIF

		typedef short int       code_int;   
		typedef long int        count_int;
		typedef unsigned char   pixval;



		struct _PLATFORM_DECL GIFPALETTEENTRY 
		{
			unsigned char        peRed;
			unsigned char        peGreen;
			unsigned char        peBlue;
			unsigned char        peFlags;
		} ;


		class _PLATFORM_DECL CTextureImageGIF: public TextureImageBase
		{
		protected:
			void CreateGrayColourMap(int n);
		public:
			CTextureImageGIF();
			virtual ~CTextureImageGIF();

			TextureImagePalette Palette;

			virtual bool ReadFile(FileIO::Path& imageFileName );
			virtual bool SaveFile(FileIO::Path& imageFileName, BasicType::String oldExt = "");

		private:
			int          Width, Height;
			int             curx, cury;
			int           BitsPerPixel;
			long             CountDown;
			unsigned long    cur_accum;
			int              cur_bits;
			unsigned char    *buffer;
			GIFPALETTEENTRY *palPalEntry;

		// Implementation
		protected:
			void BumpPixel (  );
			int GIFNextPixel ( );
			void Putword ( int w, FILE* fp );
			void compress ( int init_bits, FILE* outfile);
			void output ( code_int code );
			void cl_block (  );
			void cl_hash ( count_int hsize );
			void writeerr (  );
			void char_init (  );
			void char_out ( int c );
			void flush_char (  );
		};





	#endif





		/*
		//
		// Copyright Code3 corp. 2004
		//


		#if !defined(__ImaGIF_h)
		#define __ImaGIF_h

		#include "imafile.h"


		#include "ImageToolLibHeader.h"


		class _PLATFORM_DECL _IMAGETOOL_CLASS CImageGIF: public CFileImageImpl
		{
		public:
			CImageGIF(const CImageGIF * ima): CFileImageImpl(ima)
			{
			}
			CImageGIF(FileIO::Path& imageFileName): CFileImageImpl(imageFileName)
			{
			}
			~CImageGIF() {};

			virtual BOOL ReadFile(FileIO::Path& imageFileName );
			virtual BOOL SaveFile(FileIO::Path& imageFileName , int quality = 0);


		};

		#endif

		*/






	}; // namespace

}; // namespace EngineNamespace



