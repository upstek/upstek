#include "PicoDDS.h"

namespace EngineNamespace
{
	namespace PicoDDS
	{
		size_t Load_dds_file(const char * filename, DDSImg & dds)
		{
			// open the file for reading (binary mode)
			FILE* file = fopen(filename, "rb");
			if (file == NULL) {
				return 0;
			}

			// read the dds file
			size_t sizeRead = dds.Read(file);
			fclose(file);
			return sizeRead;
		}

		DDSImg::DDSImg()
		{
			memset(&m_sImageData_, 0, sizeof(m_sImageData_));
			memset(&m_sSurfacedata_, 0, sizeof(m_sSurfacedata_));
		}

		DDSImg::DDSImg(DDSImg const & lhs)
			: m_sImageData_(lhs.m_sImageData_), m_sSurfacedata_(lhs.m_sSurfacedata_)
		{
		}

		DDSImg::~DDSImg()
		{
			delete[] m_sImageData_.imgData;
		}

		size_t DDSImg::Read(FILE * pFile)
		{
			// Read in header and decode
			if (!readheader(pFile, m_sSurfacedata_))
				return -1;

			if (m_sSurfacedata_.mipmapcount == 0)
				m_sSurfacedata_.mipmapcount = 1;

			m_sImageData_.height = m_sSurfacedata_.height;
			m_sImageData_.width = m_sSurfacedata_.width;

			if (m_sSurfacedata_.flags & DDS::DDSD_DEPTH)
				m_sImageData_.depth = m_sSurfacedata_.depth;
			else
				m_sImageData_.depth = 0;	// no depth to these images

			m_sImageData_.colourdepth = m_sSurfacedata_.pixelformat.RGBBitCount;
			m_sImageData_.numMipMaps = m_sSurfacedata_.mipmapcount;
			m_sImageData_.format = GetTextureFormat();
			m_sImageData_.numImages = GetNumImages();
			m_sImageData_.size = CalculateStoreageSize();
			if (0 >= m_sImageData_.size)
				return -1;

			if (0 == m_sImageData_.format)
				return -1;

			fseek(pFile, 0, SEEK_END); // seek to end of file
			size_t size = ftell(pFile); // get current file pointer
			const long headerSize = 128;
			const size_t DDSStructSize = sizeof(DDS::DDSStruct) + 4;
			fseek(pFile, 0, SEEK_SET); // seek back to beginning of file
			fseek(pFile, headerSize, SEEK_SET); // seek back to beginning of file
												// proceed with allocating memory and reading the file
			m_sImageData_.imgData = new byte[m_sImageData_.size];

			// Read in remaining data
			size_t amtRead = fread(m_sImageData_.imgData, sizeof(byte), size - headerSize, pFile);
			return amtRead;
		}

		int DDSImg::GetMinDXTSize()
		{
			return getMinSize(GetDXTFormat());
		}

		inline int DDSImg::GetMipLevelSize(unsigned int width, unsigned int height, unsigned int depth, ImgFormat format)
		{
			if (!depth)
				depth = 1;

			int numPixels = width*height*depth;

			switch (format)
			{
			case FORMAT_L8:
			case FORMAT_A8:
				return numPixels;

			case FORMAT_R16F:
			case FORMAT_R5G6B5:
			case FORMAT_X1R5G5B5:
			case FORMAT_A1R5G5B5:
			case FORMAT_A8L8:
			case FORMAT_L16:
			case FORMAT_V8U8:
				return numPixels * 2;

			case FORMAT_RGB:
			case FORMAT_BGR:
				return numPixels * 3;

			case FORMAT_RGBA:
			case FORMAT_BGRA:
			case FORMAT_ABGR:
			case FORMAT_R32F:
			case FORMAT_G16R16F:
			case FORMAT_V16U16:
			case FORMAT_G16R16:
			case FORMAT_Q8W8V8U8:
				return numPixels * 4;

			case FORMAT_R16G16B16A16F:
			case FORMAT_G32R32F:
				return numPixels * 8;

			case FORMAT_R32G32B32A32F:
				return numPixels * 16;

			case FORMAT_DXT1:
				return ((width + 3) / 4) * ((height + 3) / 4) * depth * 8;
			case FORMAT_DXT2:
			case FORMAT_DXT3:
			case FORMAT_DXT4:
			case FORMAT_DXT5:
			case FORMAT_3DC:
				return ((width + 3) / 4) * ((height + 3) / 4) * depth * 16;
			default:
				break;
			}
			return -1;
		}

		int DDSImg::CalculateStoreageSize()
		{
			int size = 0;
			for (int i = 0; i < m_sImageData_.numImages; ++i)
			{
				int width = m_sImageData_.width;
				int height = m_sImageData_.height;
				int depth = m_sImageData_.depth;

				for (int m = 0; m<m_sImageData_.numMipMaps; ++m)
				{
					size += GetMipLevelSize(width, height, depth, m_sImageData_.format);
					width = max(width >> 1, 1);
					height = max(height >> 1, 1);
					depth = max(depth >> 1, 1);
				}
			}

			return size;
		}

		ImgFormat DDSImg::GetTextureFormat()
		{
			ImgFormat format = FORMAT_NONE;

			if (m_sSurfacedata_.pixelformat.flags & DDS::DDPF_FOURCC)
			{
				format = GetDXTFormat();
			}
			else if (m_sSurfacedata_.pixelformat.flags & DDS::DDPF_RGB)
			{
				if (m_sSurfacedata_.pixelformat.flags & DDS::DDPF_ALPHAPIXELS)
				{
					if (0xff == m_sSurfacedata_.pixelformat.bBitMask &&
						0xff00 == m_sSurfacedata_.pixelformat.gBitMask &&
						0xff0000 == m_sSurfacedata_.pixelformat.rBitMask &&
						0xff000000 == m_sSurfacedata_.pixelformat.alpahbitmask)
					{
						format = FORMAT_BGRA;
					}
					else if (0xff == m_sSurfacedata_.pixelformat.rBitMask &&
						0xff00 == m_sSurfacedata_.pixelformat.gBitMask &&
						0xff0000 == m_sSurfacedata_.pixelformat.bBitMask &&
						0xff000000 == m_sSurfacedata_.pixelformat.alpahbitmask)
					{
						format = FORMAT_RGBA;
					}
					else if (0xff == m_sSurfacedata_.pixelformat.alpahbitmask &&
						0xff00 == m_sSurfacedata_.pixelformat.bBitMask &&
						0xff0000 == m_sSurfacedata_.pixelformat.gBitMask &&
						0xff000000 == m_sSurfacedata_.pixelformat.rBitMask)
					{
						format = FORMAT_ABGR;
					}
					else if (0x8000 == m_sSurfacedata_.pixelformat.alpahbitmask &&
						0x1F == m_sSurfacedata_.pixelformat.bBitMask &&
						0x3E0 == m_sSurfacedata_.pixelformat.gBitMask &&
						0x7C00 == m_sSurfacedata_.pixelformat.rBitMask)
					{
						format = FORMAT_A1R5G5B5;
					}
				}
				else
				{
					if (0xff == m_sSurfacedata_.pixelformat.bBitMask &&
						0xff00 == m_sSurfacedata_.pixelformat.gBitMask &&
						0xff0000 == m_sSurfacedata_.pixelformat.rBitMask)
					{
						format = FORMAT_BGRA;
					}
					else if (0xff == m_sSurfacedata_.pixelformat.rBitMask &&
						0xff00 == m_sSurfacedata_.pixelformat.gBitMask &&
						0xff0000 == m_sSurfacedata_.pixelformat.bBitMask)
					{
						format = FORMAT_RGBA;
					}
					else if (0xffFF == m_sSurfacedata_.pixelformat.rBitMask &&
						0xffFF0000 == m_sSurfacedata_.pixelformat.gBitMask &&
						0x00 == m_sSurfacedata_.pixelformat.bBitMask &&
						0x00 == m_sSurfacedata_.pixelformat.alpahbitmask)
					{
						format = FORMAT_G16R16;
					}
					else if (0x1F == m_sSurfacedata_.pixelformat.bBitMask &&
						0x3E0 == m_sSurfacedata_.pixelformat.gBitMask &&
						0x7C00 == m_sSurfacedata_.pixelformat.rBitMask)
					{
						format = FORMAT_X1R5G5B5;
					}
					else if (0x1F == m_sSurfacedata_.pixelformat.bBitMask &&
						0x7E0 == m_sSurfacedata_.pixelformat.gBitMask &&
						0xF800 == m_sSurfacedata_.pixelformat.rBitMask)
					{
						format = FORMAT_R5G6B5;
					}
				}
			}
			else
			{
				if (0xFF == m_sSurfacedata_.pixelformat.rBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.gBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.bBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.alpahbitmask)
				{
					format = FORMAT_L8;
				}
				else if (0xFFFF == m_sSurfacedata_.pixelformat.rBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.gBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.bBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.alpahbitmask)
				{
					format = FORMAT_L16;
				}
				else if (0x0 == m_sSurfacedata_.pixelformat.rBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.gBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.bBitMask &&
					0xFF == m_sSurfacedata_.pixelformat.alpahbitmask)
				{
					format = FORMAT_A8;
				}
				else if (0xFF == m_sSurfacedata_.pixelformat.rBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.gBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.bBitMask &&
					0xFF00 == m_sSurfacedata_.pixelformat.alpahbitmask)
				{
					format = FORMAT_A8L8;
				}
				else if (0xFF == m_sSurfacedata_.pixelformat.rBitMask &&
					0xFF00 == m_sSurfacedata_.pixelformat.gBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.bBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.alpahbitmask)
				{
					format = FORMAT_V8U8;
				}
				else if (0xFF == m_sSurfacedata_.pixelformat.rBitMask &&
					0xFF00 == m_sSurfacedata_.pixelformat.gBitMask &&
					0xFF0000 == m_sSurfacedata_.pixelformat.bBitMask &&
					0xFF000000 == m_sSurfacedata_.pixelformat.alpahbitmask)
				{
					format = FORMAT_Q8W8V8U8;
				}
				else if (0xFFFF == m_sSurfacedata_.pixelformat.rBitMask &&
					0xFFFF0000 == m_sSurfacedata_.pixelformat.gBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.bBitMask &&
					0x0 == m_sSurfacedata_.pixelformat.alpahbitmask)
				{
					format = FORMAT_V16U16;
				}
			}
			return format;
		}

		int DDSImg::GetNumImages()
		{
			if (!(m_sSurfacedata_.ddscaps.caps2 & DDS::DDSCAPS2_CUBEMAP))
				return 1;

			// We are a cube map, so work out how many sides we have
			uint32_t mask = DDS::DDSCAPS2_CUBEMAP_POSITIVEX;
			int count = 0;
			for (int n = 0; n < 6; ++n)
			{
				if (m_sSurfacedata_.ddscaps.caps2 & mask)
					++count;
				mask *= 2;	// move to next face
			}
			return count;
		}

		ImgFormat DDSImg::GetDXTFormat()
		{
			ImgFormat format = FORMAT_NONE;
			switch (m_sSurfacedata_.pixelformat.fourCC)
			{
			case FOURCC('D', 'X', 'T', '1'):
				format = FORMAT_DXT1;
				break;
			case FOURCC('D', 'X', 'T', '2'):
				format = FORMAT_DXT2;
				break;
			case FOURCC('D', 'X', 'T', '3'):
				format = FORMAT_DXT3;
				break;
			case FOURCC('D', 'X', 'T', '4'):
				format = FORMAT_DXT4;
				break;
			case FOURCC('D', 'X', 'T', '5'):
				format = FORMAT_DXT5;
				break;
			case FOURCC('A', 'T', 'I', '2'):
				format = FORMAT_3DC;
				break;
			case 0x74:
				format = FORMAT_R32G32B32A32F;
				break;
			case 0x71:
				format = FORMAT_R16G16B16A16F;
				break;
			case 0x70:
				format = FORMAT_G16R16F;
				break;
			case 0x73:
				format = FORMAT_G32R32F;
				break;
			case 0x6F:
				format = FORMAT_R16F;
				break;
			case 0x72:
				format = FORMAT_R32F;
				break;
			default:
				break;
			}
			return format;
		}

		LoaderImgData DDSImg::GetImageData()
		{
			return m_sImageData_;
		}

		bool DDSImg::GetHeaderdone()
		{
			return m_bHeaderdone_;
		}

		DDS::DDSStruct DDSImg::GetSurfacedata()
		{
			return m_sSurfacedata_;
		}

		inline int DDSImg::getMinSize(ImgFormat flag)
		{
			int minsize = 1;

			switch (flag)
			{
			case FORMAT_DXT1:
				minsize = 8;
				break;
			case FORMAT_DXT2:
			case FORMAT_DXT3:
			case FORMAT_DXT4:
			case FORMAT_DXT5:
			case FORMAT_3DC:
				minsize = 16;
				break;
			case FORMAT_NONE:
				minsize = 0;
			default:
				break;
			}
			return minsize;
		}

		inline uint16_t DDSImg::read16_le(const byte * b)
		{
			return b[0] + (b[1] << 8);
		}

		inline void DDSImg::write16_le(byte * b, uint16_t value)
		{
			b[0] = value & 0xFF;
			b[1] = value >> 8;
		}

		inline uint16_t DDSImg::read16_be(const byte * b)
		{
			return (b[0] << 8) + b[1];
		}

		inline void DDSImg::write16_be(byte * b, uint16_t value)
		{
			b[0] = value >> 8;
			b[1] = value & 0xFF;
		}

		inline uint32_t DDSImg::read32_le(const byte * b)
		{
			return read16_le(b) + (read16_le(b + 2) << 16);
		}

		inline uint32_t DDSImg::read32_be(const byte * b)
		{
			return (read16_be(b) << 16) + read16_be(b + 2);
		}

		uint32_t DDSImg::readDword(byte *& pData)
		{
			uint32_t value = read32_le(pData);
			pData += 4;
			return value;
		}

		bool DDSImg::readheader(FILE * pFile, DDS::DDSStruct & header)
		{
			const int headerSize = 128;
			byte data[headerSize];
			byte * pData = data;
			size_t sizeRead = fread(pData, sizeof(char), headerSize, pFile);
			if (headerSize != sizeRead)
			{
				// amount read different from amount required/expected
				return false;
			}

			// verify DDS files
			if (!(pData[0] == 'D' && pData[1] == 'D' && pData[2] == 'S' && pData[3] == ' '))
			{
				return false;
			}
			pData += 4;

			header.size = readDword(pData);
			if (header.size != 124)
			{
				return false;
			}

			//convert the data
			header.flags = readDword(pData);
			header.height = readDword(pData);
			header.width = readDword(pData);
			header.sizeorpitch = readDword(pData);
			header.depth = readDword(pData);
			header.mipmapcount = readDword(pData);

			for (int i = 0; i<11; ++i)
			{
				header.reserved[i] = readDword(pData);
			}

			//pixelfromat
			header.pixelformat.size = readDword(pData);
			header.pixelformat.flags = readDword(pData);
			header.pixelformat.fourCC = readDword(pData);
			header.pixelformat.RGBBitCount = readDword(pData);
			header.pixelformat.rBitMask = readDword(pData);
			header.pixelformat.gBitMask = readDword(pData);
			header.pixelformat.bBitMask = readDword(pData);
			header.pixelformat.alpahbitmask = readDword(pData);

			//caps
			header.ddscaps.caps1 = readDword(pData);
			header.ddscaps.caps2 = readDword(pData);
			header.ddscaps.reserved[0] = readDword(pData);
			header.ddscaps.reserved[1] = readDword(pData);
			header.reserved2 = readDword(pData);

			return true;
		}

	}
}

