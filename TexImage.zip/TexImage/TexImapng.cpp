
#include "BasicType/All.h"

/*
 * File:	imapng.cc
 * Purpose:	Platform Independent JPEG Image Class
 * Author:	Alejandro Aguilar Sierra
 * Created:	1995
 * Copyright: (c) 1995, Alejandro Aguilar Sierra <asierra@servidor.unam.mx>
 *
 *      logjmp
 */

#include "Compatibility/syssetjmp.h"

#include "TexImapng.h"
#if TEXIMAGE_SUPPORT_PNG

extern "C" {
#include "png/png.h"
	
}

#include "TexImageIter.h"

#ifdef _DEBUG
//#define new DEBUG_NEW


#endif

#ifdef _ANDROID
		#ifndef max
			#define max(a,b)            (((a) > (b)) ? (a) : (b))
		#endif

		#ifndef min
			#define min(a,b)            (((a) < (b)) ? (a) : (b))
		#endif

#endif


namespace EngineNamespace
{


	namespace TexImage
	{


		#define PNG_SUPPORT_ALPHA

		TextureImagePNG::TextureImagePNG()
		{
		}



		TextureImagePNG::~TextureImagePNG()
		{
			//_CrtDbgBreak(); //CSI 0817 test code
		}








		static void
		ima_png_error(png_struct *png_ptr, char *message)
		{
		//        AfxMessageBox(message);

			sys_longjmp(png_ptr->jmpbuf, 1);
		}



		////////////////////////////////////////////////////////////////////////////////
		void TextureImagePNG::expand2to4bpp(unsigned char* prow)
		{
			unsigned char *psrc,*pdst;
			unsigned char pos,idx;
			for(long x=Width-1;x>=0;x--)
			{
				psrc = prow + ((2*x)>>3);
				pdst = prow + ((4*x)>>3);
				pos = (unsigned char)(2*(3-x%4));
				idx = (unsigned char)((*psrc & (0x03<<pos))>>pos);
				pos = (unsigned char)(4*(1-x%2));
				*pdst &= ~(0x0F<<pos);
				*pdst |= (idx & 0x0F)<<pos;
			}
		}

		/*

		#define CMAX_IMAGE_FORMATS 6


		typedef struct _PLATFORM_DECL tagCxImageInfo {
			unsigned long	dwEffWidth;			///< unsigned long aligned scan line width
			unsigned char*	pImage;				///< THE IMAGE BITS
			//CxImage* pGhost;			///< if this is a ghost, pGhost points to the body
			//CxImage* pParent;			///< if this is a layer, pParent points to the body
			unsigned long	dwType;				///< original image format
			char	szLastError[256];	///< debugging
			long	nProgress;			///< monitor
			long	nEscape;			///< escape
			long	nBkgndIndex;		///< used for GIF, PNG, MNG
			TRGBA nBkgndColor;		///< used for RGB transparency
			float	fQuality;			///< used for JPEG, JPEG2000 (0.0f ... 100.0f)
			unsigned char	nJpegScale;			///< used for JPEG [ignacio]
			long	nFrame;				///< used for TIF, GIF, MNG : actual frame
			long	nNumFrames;			///< used for TIF, GIF, MNG : total number of frames
			unsigned long	dwFrameDelay;		///< used for GIF, MNG
			long	xDPI;				///< horizontal resolution
			long	yDPI;				///< vertical resolution
			RECT	rSelectionBox;		///< bounding rectangle
			unsigned char	nAlphaMax;			///< max opacity (fade)
			bool	bAlphaPaletteEnabled; ///< true if alpha values in the palette are enabled.
			bool	bEnabled;			///< enables the painting functions
			long	xOffset;
			long	yOffset;
			unsigned long	dwCodecOpt[CMAX_IMAGE_FORMATS];	///< for GIF, TIF : 0=def.1=unc,2=fax3,3=fax4,4=pack,5=jpg
			TRGBA last_c;				///< for GetNearestIndex optimization
			unsigned char	last_c_index;
			bool	last_c_isvalid;
			long	nNumLayers;
			unsigned long	dwFlags;			///< 0x??00000 = reserved, 0x00??0000 = blend mode, 0x0000???? = layer id - user flags
			unsigned char	dispmeth;
			bool	bGetAllFrames;
			bool	bLittleEndianHost;

		} CXIMAGEINFO;
		*/




		bool
		TextureImagePNG::ReadFile(FileIO::Path& imageFileName)
		{
			ImagePalette = NULL;

			//CXIMAGEINFO info;
			bool bAlphaPaletteEnabled = false;
			char	szLastError[256];	///< debugging


			int number_passes;

			FileName = imageFileName;

			FILE *fp;
			png_struct *png_ptr;
			 png_info *info_ptr;
			TextureImageIterator iter(this);

			/* open the file */
			fp = fopen(FileName.GetSystemPath() , "rb");
			if (!fp)
				return false;




			unsigned char *row_pointers=NULL;
			
		#ifdef PNG_EXCEPTION
			try 
		#endif
			{
			/* Create and initialize the png_struct with the desired error handler
				* functions.  If you want to use the default stderr and longjump method,
				* you can supply NULL for the last three parameters.  We also supply the
				* the compiler header file version, so that we know if the application
				* was compiled with a compatible version of the library.  REQUIRED
				*/
				png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING,(void *)NULL,NULL,NULL);
				if (png_ptr == NULL)  
		#ifdef PNG_EXCEPTION
					throw "Failed to create PNG structure";
		#else
					return false; 
		#endif
				
				/* Allocate/initialize the memory for image information.  REQUIRED. */
				info_ptr = png_create_info_struct(png_ptr);
				if (info_ptr == NULL) {
					png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
		#ifdef PNG_EXCEPTION
					throw "Failed to initialize PNG info structure";
		#else
					return false; 
		#endif
				}
				
				/* Set error handling if you are using the setjmp/longjmp method (this is
				* the normal method of doing things with libpng).  REQUIRED unless you
				* set up your own error handlers in the png_create_read_struct() earlier.
				*/
				if (sys_setjmp(png_ptr->jmpbuf)) 
				{
					/* Free all of the memory associated with the png_ptr and info_ptr */
					if (row_pointers) delete[] row_pointers;
					png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		#ifdef PNG_EXCEPTION
					throw "Error reading PNG file";
		#else
					return false; 
		#endif
				}
				/* set up the input control */
				png_init_io(png_ptr, fp);
				
				/* read the file information */
				png_read_info(png_ptr, info_ptr);



				/* calculate new number of channels */
				int channels=0;
				switch(info_ptr->color_type){
				case PNG_COLOR_TYPE_GRAY:
				case PNG_COLOR_TYPE_PALETTE:
					channels = 1;
					break;
				case PNG_COLOR_TYPE_GRAY_ALPHA:
					channels = 2;
					break;
				case PNG_COLOR_TYPE_RGB:
					channels = 3;
					break;
				case PNG_COLOR_TYPE_RGB_ALPHA:
					channels = 4;
					break;
				default:
					strcpy(szLastError,"unknown PNG color type");
					sys_longjmp(png_ptr->jmpbuf, 1);
				}

				//find the right pixel depth used for cximage
				int pixel_depth = info_ptr->pixel_depth;
				if (channels == 1 && pixel_depth>8) pixel_depth=8;
				if (channels == 2) pixel_depth=8;
				if (channels == 3) 
				{
					RBSwap = true;
					pixel_depth=24;
				}
				if (channels == 4)
				{
					if (info_ptr->color_type == PNG_COLOR_TYPE_RGB_ALPHA || //Alpha channel
							(info_ptr->color_type == PNG_COLOR_TYPE_GRAY_ALPHA && info_ptr->pixel_depth == 32) )
						pixel_depth=32;
					else
						pixel_depth=24;

				}

				int chan_offset = info_ptr->bit_depth >> 3;
				//int pixel_offset = info_ptr->pixel_depth >> 3;
				int pixel_offset = pixel_depth >> 3;
				

		#if 0
				/*
				/* allocate the memory to hold the image using the fields of png_info. */
				png_color_16 my_background={ 0, 192, 192, 192, 0 };
				png_color_16 *image_background;


				if (info_ptr->pixel_depth != 32)
				{
					//<yeonjun jeong> preserve original background info.
					if (png_get_bKGD(png_ptr, info_ptr, &image_background))
						png_set_background(png_ptr, image_background,PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
					else
						png_set_background(png_ptr, &my_background,PNG_BACKGROUND_GAMMA_SCREEN, 0, 1.0);
					//<yeonjun jeong> safe check
					if (info_ptr->pixel_depth > 16 ) info_ptr->color_type = COLORTYPE_COLOR;
				}
				
				//<DP> hack for images with alpha channel
				if (info_ptr->pixel_depth == 32)
				{
					//		BackGroundIndex = 0; //enable transparency
					if (png_get_bKGD(png_ptr, info_ptr, &image_background))
					{
						BackGroundColor.r   = (unsigned char)image_background->red;
						BackGroundColor.g = (unsigned char)image_background->green;
						BackGroundColor.b  = (unsigned char)image_background->blue;
					}
				}
				*/
				
		#endif


				Create(info_ptr->width, info_ptr->height, pixel_depth, info_ptr->color_type); // Q 2017.7.26 �ؽ��� Ÿ�� ���ڿ� �߰�

				int biClrUsed;
				switch (Depth){
						case 1:
								biClrUsed = 2;	break;
						case 4:
								biClrUsed = 16; break;
						case 8:
								biClrUsed = 256; break;
						default:
								biClrUsed = 0;
				}


				
				if (info_ptr->num_palette>0)
					Palette.SetPalette((TRGB*)info_ptr->palette, info_ptr->num_palette);
				else 
				if (info_ptr->bit_depth ==2) 
				{ //<DP> needed for 2 bpp grayscale PNGs
					Palette.SetPaletteColor(0,0,0,0);
					Palette.SetPaletteColor(1,85,85,85);
					Palette.SetPaletteColor(2,170,170,170);
					Palette.SetPaletteColor(3,255,255,255);
				} 
				else 
					Palette.SetGrayPalette(); //<DP> needed for grayscale PNGs
				
		#ifdef PNG_RESOLUTION
				if (info_ptr->phys_unit_type==PNG_RESOLUTION_METER) 
				{
					SetXDPI(int(double(info_ptr->x_pixels_per_unit)*0.0254));
					SetYDPI(int(double(info_ptr->y_pixels_per_unit)*0.0254));
				}
		#endif


				// simple transparency (the real PGN transparency is more complex)
				if (info_ptr->num_trans!=0)
				{
					//palette transparency
					TRGBA* pal = Palette.Palette;

					if (pal)
					{
						unsigned long ip;
						for (ip=0;ip<min(biClrUsed,info_ptr->num_trans);ip++)
							pal[ip].a=info_ptr->trans[ip];
						if (info_ptr->num_trans==1 && pal[0].a==0)
						{
							BackGroundIndex = 0;
						} 
						else 
						{
							bAlphaPaletteEnabled = 1;
							for (;ip<biClrUsed;ip++)
								pal[ip].a=255;
						}
					}
				}
				

				if (info_ptr->color_type == PNG_COLOR_TYPE_RGB_ALPHA || //Alpha channel
					(info_ptr->color_type == PNG_COLOR_TYPE_GRAY_ALPHA && info_ptr->pixel_depth == 32))
				{
					if (info_ptr->color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
					{
						png_set_gray_to_rgb(png_ptr);
						png_set_expand(png_ptr);
					}
					png_set_filler(png_ptr, 0xff, PNG_FILLER_AFTER);
					//AlphaCreate();
				}
				
				//allocate the buffer
				int row_stride = info_ptr->width * ((info_ptr->pixel_depth+7)>>3);
				row_pointers = new unsigned char[10+row_stride];
				
				// turn on interlace handling
				if (info_ptr->interlace_type)
					number_passes = png_set_interlace_handling(png_ptr);
				else
					number_passes = 1;
				

				for (int pass=0; pass < number_passes; pass++) 
				{
					iter.Upset();
					int y=0;
					do	
					{

						// <vho> - handle cancel
						//if (info.nEscape) 
						//	sys_longjmp(png_ptr->jmpbuf, 1);

			#ifdef PNG_SUPPORT_ALPHA	// <vho>
						if (Depth == 32) //AlphaIsValid()) 
						{
							//compute the correct position of the line
							long ax,ay;
							ay = info_ptr->height-1-y;
							unsigned char* prow= iter.GetRow(ay);

							//recover data from previous scan
							if (info_ptr->interlace_type && pass>0 && pass!=7)
							{
								for(ax=0;ax<info_ptr->width;ax++)
								{
									long px = ax * pixel_offset;
									if (channels == 2)
									{
										row_pointers[px] = prow[ax];
										row_pointers[px+chan_offset] = GetAlpha(ax, ay); //AlphaGet(ax,ay);
									} 
									else 
									{
										long qx = ax * channels; // 3
										row_pointers[px]              =prow[qx+2];  // order  b g r 
										row_pointers[px+chan_offset]  =prow[qx+1];
										row_pointers[px+chan_offset*2]=prow[qx+0];
										row_pointers[px+chan_offset*3]= GetAlpha(ax, ay); //AlphaGet(ax,ay);
									}
								}
							}

							//read next row
							png_read_row(png_ptr, row_pointers, NULL);

							//RGBA -> RGB + A
							for(ax=0;ax<info_ptr->width;ax++)
							{
								long px = ax * pixel_offset;
								if (channels == 2)
								{
									prow[ax] = row_pointers[px];
									//AlphaSet(ax,ay,row_pointers[px+chan_offset]);
									SetAlpha(ax,ay,row_pointers[px+chan_offset]);
								} 
								else 
								{
									long qx = ax * channels; //3
									prow[qx]  =row_pointers[px+chan_offset*2];  // order  b g r 
									prow[qx+1]=row_pointers[px+chan_offset*1];
									prow[qx+2]=row_pointers[px+chan_offset*0];
									//AlphaSet(ax,ay,row_pointers[px+chan_offset*3]);
									SetAlpha(ax,ay,row_pointers[px+chan_offset*3]);
								}
							}
						} 
						else
			#endif // PNG_SUPPORT_ALPHA		// vho
						{
							//recover data from previous scan
							if (info_ptr->interlace_type && pass>0)
							{
								iter.GetRow(row_pointers, info_ptr->rowbytes);
								//re-expand buffer for images with bit depth > 8
								if (info_ptr->bit_depth > 8)
								{
									for(long ax=(info_ptr->width*channels-1);ax>=0;ax--)
										row_pointers[ax*chan_offset] = row_pointers[ax];
								}
							}

							//read next row
							png_read_row(png_ptr, row_pointers, NULL);

							//shrink 16 bit depth images down to 8 bits
							if (info_ptr->bit_depth > 8){
								for(long ax=0;ax<(info_ptr->width*channels);ax++)
									row_pointers[ax] = row_pointers[ax*chan_offset];
							}

							//copy the pixels
							iter.SetRow(row_pointers, info_ptr->rowbytes);
							//<DP> expand 2 bpp images only in the last pass
							if (info_ptr->bit_depth==2 && pass==(number_passes-1))
								expand2to4bpp(iter.GetRow());

							//go on
							iter.PrevRow();
						}

						y++;
					} while(y<info_ptr->height);
				}
				

				delete[] row_pointers;
				
				/* read the rest of the file, getting any additional chunks in info_ptr */
				png_read_end(png_ptr, info_ptr);
				
				/* clean up after the read, and free any memory allocated - REQUIRED */
				png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
				
			} 
		#ifdef PNG_EXCEPTION
			catch (char *message) 
			{
				strncpy(szLastError,message,255);
				fclose(fp);
				return false;
			}
		#endif
			/* that's it */
			fclose(fp);
			return true;




		}





		/* write a png file */

		bool TextureImagePNG::SaveFile(FileIO::Path& imageFileName, BasicType::String oldExt)
		{
			FileName = imageFileName;
			BasicType::String ext = FileName.GetExt();
			if (oldExt != ext)
				ext = oldExt;

			TextureImageIterator iter(this);
			FILE *fp;
			png_struct *png_ptr;
			png_info *info_ptr;

			 /* open the file */
			fp = fopen( FileName.GetSystemPath(), "wb");
			if (!fp)
				return false;


			 /* Create and initialize the png_struct with the desired error handler
				* functions.  If you want to use the default stderr and longjump method,
				* you can supply NULL for the last three parameters.  We also check that
				* the library version is compatible with the one used at compile time,
				* in case we are using dynamically linked libraries.  REQUIRED.
				*/
			png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
					(void *)NULL, NULL, NULL);

			if (png_ptr == NULL)
			{
				fclose(fp);
				/* If we get here, we had a problem reading the file */
				return false;
			}

				 /* Allocate/initialize the image information data.  REQUIRED */
			 info_ptr = png_create_info_struct(png_ptr);
			 if (info_ptr == NULL)
			 {
					fclose(fp);
					png_destroy_write_struct(&png_ptr,  (png_infopp)NULL);
					return false;
			 }

			 /* Set error handling.  REQUIRED if you aren't supplying your own
				* error hadnling functions in the png_create_write_struct() call.
				*/
			 if (sys_setjmp(png_ptr->jmpbuf))
			 {
					/* If we get here, we had a problem reading the file */
					fclose(fp);
					png_destroy_write_struct(&png_ptr,  (png_infopp)&info_ptr);
					return false;
			 }

		            
			int row_stride = GetWidth() * ((GetDepth()+7)>>3);
			/* set up the output control */
			 png_init_io(png_ptr, fp);

			/* set the file information here */
			info_ptr->width = GetWidth();
			info_ptr->height = GetHeight();
			info_ptr->pixel_depth = GetDepth();
			info_ptr->channels = GetDepth() / 8;
			if (info_ptr->channels > 0)
				info_ptr->bit_depth = GetDepth()/info_ptr->channels;
			info_ptr->color_type = GetColorType();
			info_ptr->compression_type = info_ptr->filter_type = info_ptr->interlace_type=0;
			info_ptr->valid = 0;
			info_ptr->rowbytes = row_stride;


		// printf("P = %d D = %d RS= %d GD= %d CH= %d ", info_ptr->pixel_depth, info_ptr->bit_depth, row_stride, GetDepth(), info_ptr->channels);
			/* set the palette if there is one */
			if ((GetColorType() & COLORTYPE_PALETTE) && Palette.Palette)
			{
			 // printf("writig paleta[%d %d %x]",GetColorType() ,COLORTYPE_PALETTE, Palette.Palette);
				info_ptr->valid |= PNG_INFO_PLTE;
				info_ptr->palette = new png_color[256];
				info_ptr->num_palette = 256;
				for (int i=0; i<256; i++)
				 Palette.GetRGB(i, &info_ptr->palette[i].red, &info_ptr->palette[i].green, &info_ptr->palette[i].blue);
			}  

			/* write the file information */
			png_write_info(png_ptr, info_ptr);
			/* If you are only writing one row at a time, this works */

			byte *row_pointers = new byte[row_stride];
  			iter.Upset();
				
			do {
				//	  (unsigned char *)iter.GetRow();
				iter.GetRow(row_pointers, row_stride);

				// Q 2017.7.27 
				// PNG ���� ��ƾ���� R�� B �ڹٲ�� ���� ����
				int interval = GetDepth() / 8;
				for (int i = 0; i < row_stride; i += interval)
				{
					byte btemp = row_pointers[i + 0];
					row_pointers[i + 0] = row_pointers[i + 2];
					row_pointers[i + 2] = btemp;
				}

				png_write_row(png_ptr, row_pointers);
			} while (iter.PrevRow());
		        
				delete [] row_pointers;

			 /* It is REQUIRED to call this to finish writing the rest of the file */
			 png_write_end(png_ptr, info_ptr);

			 /* if you malloced the palette, free it here */
			 if (info_ptr->palette)
				delete[] (info_ptr->palette);

			 /* clean up after the write, and free any memory allocated */
			 png_destroy_write_struct(&png_ptr, (png_infopp)&info_ptr);

			/* close the file */
			fclose(fp);

			/* that's it */
			return true;
		}






		#if 0 // _NEWALPHA save
		not implemented yet


		/* write a png file */

		bool TextureImagePNG::SaveFile(FileIO::Path& imageFileName)
		{
			if (imageFileName != "")
				FileName = imageFileName;

			TextureImageIterator iter(this);
			FILE *fp;
			png_struct *png_ptr;
			png_info *info_ptr;

			 /* open the file */
			fp = fopen((const TCHAR *)FileName, "wb");
			if (!fp)
				return false;



			if (!fp) 
				return false;

			unsigned char trans[256];	//for transparency (don't move)

			try
			{
				 /* Create and initialize the png_struct with the desired error handler
					* functions.  If you want to use the default stderr and longjump method,
					* you can supply NULL for the last three parameters.  We also check that
					* the library version is compatible with the one used at compile time,
					* in case we are using dynamically linked libraries.  REQUIRED.
					*/
				png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,(void *)NULL,NULL,NULL);
				if (png_ptr == NULL) throw "Failed to create PNG structure";

				/* Allocate/initialize the image information data.  REQUIRED */
				info_ptr = png_create_info_struct(png_ptr);
				if (info_ptr == NULL){
					png_destroy_write_struct(&png_ptr,  (png_infopp)NULL);
					throw "Failed to initialize PNG info structure";
				}

				 /* Set error handling.  REQUIRED if you aren't supplying your own
					* error hadnling functions in the png_create_write_struct() call.
					*/
				if (sys_setjmp(png_ptr->jmpbuf)){
					/* If we get here, we had a problem reading the file */
					if (info_ptr->palette) free(info_ptr->palette);
					png_destroy_write_struct(&png_ptr,  (png_infopp)&info_ptr);
					throw "Error saving PNG file";
				}
			            
				int row_stride = EffWidth; //info.dwEffWidth;
				/* set up the output control */
				png_init_io(png_ptr, fp);

				// use custom I/O functions
					///png_set_write_fn(png_ptr,fp,(png_rw_ptr)user_write_data,(png_flush_ptr)user_flush_data);

				/* set the file information here */
				info_ptr->width = GetWidth();
				info_ptr->height = GetHeight();
				info_ptr->pixel_depth = (unsigned char)Depth;
				info_ptr->channels = (Depth>8) ? (unsigned char)3: (unsigned char)1;
				info_ptr->bit_depth = (unsigned char)(Depth/info_ptr->channels);
				info_ptr->color_type = GetColorType();
				info_ptr->compression_type = info_ptr->filter_type = 0;
				info_ptr->valid = 0;
				info_ptr->rowbytes = row_stride;

				bool interlaced = false;//
				switch(interlaced)
				{
				case 1:
					info_ptr->interlace_type = PNG_INTERLACE_ADAM7;
					break;
				default:
					info_ptr->interlace_type = PNG_INTERLACE_NONE;
				}

				/* set compression level */
				//int compression = Z_BEST_COMPRESSION;
				//png_set_compression_level(png_ptr, Z_BEST_COMPRESSION);

				bool bGrayScale = Palette.IsGrayScale();

				if (Palette.PaletteSize){
					if (bGrayScale){
						info_ptr->color_type = PNG_COLOR_TYPE_GRAY;
					} else {
						info_ptr->color_type = PNG_COLOR_TYPE_PALETTE;
					}
				} else {
					info_ptr->color_type = PNG_COLOR_TYPE_RGB;
				}


			#ifdef PNG_SUPPORT_ALPHA
				if (AlphaIsValid()){
					info_ptr->color_type |= PNG_COLOR_MASK_ALPHA;
					info_ptr->channels++;
					info_ptr->bit_depth = 8;
					info_ptr->pixel_depth += 8;
				}
			#endif


				/* set background */
				png_color_16 image_background={ 0, 255, 255, 255, 0 };
				TRGBA tc;

				if (Depth <24 && BackGroundIndex>=0) 
					tc = Palette.GetRGBA((unsigned char)BackGroundIndex);
				else
					tc = BackGroundColor;

				if (BackGroundIndex != -1) 
				{
					image_background.blue = BackGroundColor.b;
					image_background.green = BackGroundColor.g;
					image_background.red = BackGroundColor.r;
				}
				png_set_bKGD(png_ptr, info_ptr, &image_background);

				/* set metrics */
				int biXPelsPerMeter = 500;
				int biYPelsPerMeter = 500;

				png_set_pHYs(png_ptr, info_ptr, biXPelsPerMeter, biYPelsPerMeter, PNG_RESOLUTION_METER);

				png_set_IHDR(png_ptr, info_ptr, info_ptr->width, info_ptr->height, info_ptr->bit_depth,
							info_ptr->color_type, info_ptr->interlace_type,
							PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

				//<DP> simple transparency
				if (BackGroundIndex >= 0)
				{
					info_ptr->num_trans = 1;
					info_ptr->valid |= PNG_INFO_tRNS;
					info_ptr->trans = trans;
					info_ptr->trans_values.index = (unsigned char)BackGroundIndex;
					info_ptr->trans_values.red   = tc.r;
					info_ptr->trans_values.green = tc.g;
					info_ptr->trans_values.blue  = tc.b;
					info_ptr->trans_values.gray  = info_ptr->trans_values.index;

					// the transparency indexes start from 0 for non grayscale palette
					if (!bGrayScale && Palette.PaletteSize && BackGroundIndex)
					{
						Palette.SwapIndex(0,(unsigned char)BackGroundIndex);
					}
				}


				/* set the palette if there is one */
				/* set the palette if there is one */
				if (GetPalette())
				{
					if (!bGrayScale)
					{
						info_ptr->valid |= PNG_INFO_PLTE;
					}

					int nc = 0;//GetClrImportant();
					if (nc==0) 
						nc = Palette.PaletteSize;

					if (info.bAlphaPaletteEnabled)
					{
						for(unsigned short ip=0; ip<nc;ip++)
							trans[ip]=Palette.GetPaletteColor((unsigned char)ip).rgbReserved;
						info_ptr->num_trans = (unsigned short)nc;
						info_ptr->valid |= PNG_INFO_tRNS;
						info_ptr->trans = trans;
					}

					// copy the palette colors
					info_ptr->palette = new png_color[nc];
					info_ptr->num_palette = (png_uint_16) nc;
					for (int i=0; i<nc; i++)
						Palette.GetRGB(i, &info_ptr->palette[i].red, &info_ptr->palette[i].green, &info_ptr->palette[i].blue);
				}  

			#ifdef PNG_SUPPORT_ALPHA	// <vho>
				//Merge the transparent color with the alpha channel
				if (AlphaIsValid() && Depth ==24 && BackGroundIndex>=0)
				{
					for(long y=0; y < head.biHeight; y++)
					{
						for(long x=0; x < head.biWidth ; x++)
						{
							RGBQUAD c=GetPixelColor(x,y,false);
							if (*(long*)&c==*(long*)&tc)
								AlphaSet(x,y,0);
				
						}	
					}
				}
			#endif // PNG_SUPPORT_ALPHA	// <vho>

				int row_size = max(info.dwEffWidth, info_ptr->width*info_ptr->channels*(info_ptr->bit_depth/8));
				info_ptr->rowbytes = row_size;
				unsigned char *row_pointers = new unsigned char[row_size];

				/* write the file information */
				png_write_info(png_ptr, info_ptr);

				//interlace handling
				int num_pass = png_set_interlace_handling(png_ptr);
				for (int pass = 0; pass < num_pass; pass++)
				{
					//write image
					iter.Upset();
					long ay=head.biHeight-1;
					TRGBA c;
					do	
					{
			#ifdef PNG_SUPPORT_ALPHA	// <vho>
						if (AlphaIsValid())
						{
							for (long ax=head.biWidth-1; ax>=0;ax--)
							{
								c = BlindGetPixelColor(ax,ay);
								int px = ax * info_ptr->channels;
								if (!bGrayScale)
								{
									row_pointers[px++]=c.r;
									row_pointers[px++]=c.g;
								}
								row_pointers[px++]=c.b;
								row_pointers[px] = AlphaGet(ax,ay);
							}
							png_write_row(png_ptr, row_pointers);
							ay--;
						}
						else
			#endif //PNG_SUPPORT_ALPHA	// <vho>
						{
							iter.GetRow(row_pointers, row_size);
							if (info_ptr->color_type == PNG_COLOR_TYPE_RGB) //HACK BY OP
							{
								RGBtoBGR(row_pointers, row_size);
							}
							png_write_row(png_ptr, row_pointers);
						}
					} while(iter.PrevRow());
				}

				delete [] row_pointers;

				//if necessary, restore the original palette
				if (!bGrayScale && head.biClrUsed && BackGroundIndex>0)
					Palette.SwapIndex((unsigned char)BackGroundIndex,0);

				/* It is REQUIRED to call this to finish writing the rest of the file */
				png_write_end(png_ptr, info_ptr);

				/* if you malloced the palette, free it here */
				if (info_ptr->palette){
					delete [] (info_ptr->palette);
					info_ptr->palette = NULL;
				}

				/* clean up after the write, and free any memory allocated */
				png_destroy_write_struct(&png_ptr, (png_infopp)&info_ptr);

			} 
			catch (char *message) 
			{
				if (strcmp(message,"")) 
					strncpy(szLastError,message,255);
				return false;
			}
			/* that's it */
			return true;






			if (GetPalette())
			{
				png_set_IHDR(png_ptr, info_ptr, info_ptr->width, info_ptr->height, info_ptr->bit_depth, 
							PNG_COLOR_TYPE_PALETTE, info_ptr->interlace_type, 
							PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);
				info_ptr->valid |= PNG_INFO_PLTE;

				//<DP> simple transparency
				if (BackGroundIndex != -1){
					trans[0]=0;
					info_ptr->num_trans = 1;
					info_ptr->valid |= PNG_INFO_tRNS;
					info_ptr->trans = trans;
					// the transparency indexes start from 0
					if (BackGroundIndex){
						SwapIndex(0,(unsigned char)BackGroundIndex);
						// the ghost must set the changed attributes in the body
						
						//TODO.TODO.TODO: if (info.pGhost) info.pGhost->SetTransIndex(0);
					}
				}

				int nc = Palette.PaletteSize;

				/* We not need to write unused colors! <Basara>*/
				/* only for small images <DP>*/
				if ((nc>2)&&((Width * Height)<65536))
				{
					nc = 0;
					for (unsigned long y=0;y<GetHeight();y++)
					{
						for (unsigned long x=0;x<GetWidth();x++)
						{
							if (GetPixelIndex(x,y)>nc)
							{
								nc=GetPixelIndex(x,y);
							}
						}
					}
					nc++;
				}

				if (bAlphaPaletteEnabled)
				{
					for(unsigned short ip=0; ip<nc;ip++)
						trans[ip]=Palette.GetPaletteColor((unsigned char)ip).a;
					info_ptr->num_trans = (unsigned short)nc;
					info_ptr->valid |= PNG_INFO_tRNS;
					info_ptr->trans = trans;
				}

				// copy the palette colors
				info_ptr->palette = new png_color[nc];
				info_ptr->num_palette = (png_uint_16) nc;
				for (int i=0; i<nc; i++) 
				{
					TRGBA c=Palette.GetPaletteColor(i);
					info_ptr->palette[i].red=c.r;
					info_ptr->palette[i].green=c.g;
					info_ptr->palette[i].blue=c.b;
					//GetPaletteColor(i, &info_ptr->palette[i].red, &info_ptr->palette[i].green, &info_ptr->palette[i].blue);
				}

			}  

		#ifdef PNG_SUPPORT_ALPHA	// <vho>
			//Merge the transparent color with the alpha channel
			bool bNeedTempAlpha = false;
			if (Depth==24 && BackGroundIndex>=0)
			{
				if (!AlphaIsValid())
				{
					bNeedTempAlpha = true;
					AlphaCreate();
				}

				TRGBA c,ct=GetTransColor();
				for(long y=0; y < Height; y++)
				{
					for(long x=0; x < Width ; x++)
					{
						c=GetPixelColor(x,y,false);
						if (*(long*)&c==*(long*)&ct)
							AlphaSet(x,y,0);
					}
				}
			}
		#endif // PNG_SUPPORT_ALPHA	// <vho>

		#ifdef PNG_SUPPORT_ALPHA	// <vho>
			if (AlphaIsValid()){
				row_stride = 4 * Width;

				info_ptr->pixel_depth = 32;
				info_ptr->channels = 4;
				info_ptr->bit_depth = 8;
				info_ptr->color_type = PNG_COLOR_TYPE_RGB_ALPHA;
				info_ptr->rowbytes = row_stride;

				/* write the file information */
				png_write_info(png_ptr, info_ptr);
				
				//<Ranger> "10+row_stride" fix heap deallocation problem during debug???
				unsigned char *row_pointers = new unsigned char[10+row_stride];

				//interlace handling
				int num_pass = png_set_interlace_handling(png_ptr);
				for (int pass = 0; pass < num_pass; pass++){

					//write image
  					iter.Upset();
					long ay=Height-1;
					TRGBA c;
					do	{
						for (long ax=Width-1; ax>=0;ax--){
							c=GetPixelColor(ax,ay);
							row_pointers[ax*4+3]=(unsigned char)((AlphaGet(ax,ay)*info.nAlphaMax)/255);
							row_pointers[ax*4+2]=c.b;
							row_pointers[ax*4+1]=c.g;
							row_pointers[ax*4]=c.r;
						}
						png_write_row(png_ptr, row_pointers);
						ay--;
					} while(iter.PrevRow());
				}
				
				delete [] row_pointers;
			}
			else
		#endif //PNG_SUPPORT_ALPHA	// <vho>
			{
				/* write the file information */
				png_write_info(png_ptr, info_ptr);
				/* If you are only writing one row at a time, this works */
				unsigned char *row_pointers = new unsigned char[10+row_stride];
		 
				//interlace handling
				int num_pass = png_set_interlace_handling(png_ptr);
				for (int pass = 0; pass < num_pass; pass++){
					
					//write image
					iter.Upset();
					do	{
						iter.GetRow(row_pointers, row_stride);
						//HACK BY OP
						if (info_ptr->color_type == 2 /*COLORTYPE_COLOR*/)
							RGBtoBGR(row_pointers, row_stride);
						png_write_row(png_ptr, row_pointers);
					} while(iter.PrevRow());

				}
				
				delete [] row_pointers;
			}

		#ifdef PNG_SUPPORT_ALPHA	// <vho>
			/* remove the temporary alpha channel*/
			if (bNeedTempAlpha) AlphaDelete();
		#endif // PNG_SUPPORT_ALPHA	// <vho>

			/* It is REQUIRED to call this to finish writing the rest of the file */
			png_write_end(png_ptr, info_ptr);

			/* if you malloced the palette, free it here */
			if (info_ptr->palette)	delete[] (info_ptr->palette);

			/* clean up after the write, and free any memory allocated */
			png_destroy_write_struct(&png_ptr, (png_infopp)&info_ptr);

			} catch (char *message) {
			strncpy(info.szLastError,message,255);
			return false;
			}
			/* that's it */
			return true;



		}








		#endif  //  new alpha 




		#endif // TEXIMAGE_SUPPORT_PNG



	}; // namespace

}; // namespace EngineNamespace




