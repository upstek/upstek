#pragma once

#include "BasicType/All.h"
#include "FileIO/Path.h"
#include "TexImageBase.h"

#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 



namespace EngineNamespace
{



	namespace TexImage
	{
		struct _PLATFORM_DECL RGBTRIPLE
		{
			unsigned char    rgbtBlue;
			unsigned char    rgbtGreen;
			unsigned char    rgbtRed;
		} ;
		struct _PLATFORM_DECL RGBQUAD 
		{
			unsigned char    rgbBlue;
			unsigned char    rgbGreen;
			unsigned char    rgbRed;
			unsigned char    rgbReserved;
		} ;

		// Q 2016.8.23
		struct _PLATFORM_DECL BMPREAD
		{
			int width;
			int height;
			char * rgb_data;
		};

		class _PLATFORM_DECL TextureImageRAW : public TextureImageBase
		{
		public:
			TextureImageRAW(int width, int height, int channel );
			TextureImageRAW();
			void CleanUp();
			bool Prepare(int width, int height, int channel);
			virtual ~TextureImageRAW();

			

			bool CopyFrom(int dstx, int dsty, TextureImageRAW *src, int x, int y, int w, int h);

			TextureImageRAW *Duplicate(); // new copy raw image

			virtual bool ReadFile(FileIO::Path& imageFileName);

			bool LoadBMP(FileIO::Path& fileName);
			bool LoadTGA(FileIO::Path& fileName);
			bool LoadRaw(FileIO::Path& fileName);
			bool SaveRaw(FileIO::Path& fileName);


			

		};






	}; // namespace

}; // namespace EngineNamespace

