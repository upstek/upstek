#pragma once

#include "BasicType/All.h"


#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 





#include "TexImageDef.h"



#include "TexImageBase.h"


namespace EngineNamespace
{





	namespace TexImage
	{



		class _PLATFORM_DECL TextureImageIterator
		{
		#ifndef _GCC
		friend TextureImageBase;
		#endif

		protected:
			int Itx, Ity;				// Counters
			int Stepx, Stepy;
			TImagePointerType IterImage;  		//  Image pointer
			TextureImageBase *ima;
		public:
		// Constructors
			TextureImageIterator ( void );
			TextureImageIterator ( TextureImageBase *imageImpl );
			operator TextureImageBase* ();

		// Iterators
			bool ItOK ();
			void Reset ();
			void Upset ();
			void SetRow(byte *buf, int n);
			void GetRow(byte *buf, int n);
			byte GetByte( ) { return IterImage[Itx]; }
			void SetByte(byte b) { IterImage[Itx] = b; }
			TImagePointerType GetRow(void);
			TImagePointerType GetRow(int n);
			bool NextRow();
			bool PrevRow();
			bool NextByte();
			bool PrevByte();

			void SetSteps(int x, int y=0) {  Stepx = x; Stepy = y; }
			void GetSteps(int *x, int *y) {  *x = Stepx; *y = Stepy; }
			bool NextStep();
			bool PrevStep();

		////////////////////////// AD - for interlace ///////////////////////////////
			void SetY(int y);
		/////////////////////////////////////////////////////////////////////////////
		};


		inline
		TextureImageIterator::TextureImageIterator(void)
		{
			ima = 0;
			IterImage = 0;
			Itx = Ity = 0;
			Stepx = Stepy = 0;
		}


		inline
		TextureImageIterator::TextureImageIterator(TextureImageBase *imageImpl): ima(imageImpl)
		{
			if (ima)
			 IterImage = ima->GetRawImage();
			Itx = Ity = 0;
			Stepx = Stepy = 0;
		}

		inline
		TextureImageIterator::operator TextureImageBase* ()
		{
			return ima;
		}

		inline
		bool TextureImageIterator::ItOK ()
		{
			if (ima)
			 return ima->Inside(Itx, Ity);
			else
			 return false;
		}


		inline void TextureImageIterator::Reset()
		{
			IterImage = ima->GetRawImage();
			Itx = Ity = 0;
		}

		inline void TextureImageIterator::Upset()
		{
			Itx = 0;
			Ity = ima->GetHeight()-1;
			IterImage = ima->GetRawImage() + ima->GetEffWidth()*(ima->GetHeight()-1);
		}

		inline bool TextureImageIterator::NextRow()
		{
			if (++Ity >= ima->GetHeight()) return 0;
			IterImage += ima->GetEffWidth();
			return 1;
		}

		inline bool TextureImageIterator::PrevRow()
		{
			if (--Ity < 0) return 0;
			//TRACE("%0x\r\n", ima);
			IterImage -= ima->GetEffWidth();
			return 1;
		}

		////////////////////////// AD - for interlace ///////////////////////////////
		inline void TextureImageIterator::SetY(int y)
		{
			if ((y < 0) || (y > ima->GetHeight())) return;
			Ity = y;
			IterImage = ima->GetRawImage() + ima->GetEffWidth()*y;
		}

		/////////////////////////////////////////////////////////////////////////////

		inline void TextureImageIterator::SetRow(byte *buf, int n)
		{
		// Here should be bcopy or memcpy
			//_fmemcpy(IterImage, (void far *)buf, n);
			if (n<0)
			 n = ima->GetWidth();

			for (int i=0; i<n; i++) IterImage[i] = buf[i];
		}

		inline void TextureImageIterator::GetRow(byte *buf, int n)
		{
			for (int i=0; i<n; i++) buf[i] = IterImage[i];
		}

		inline TImagePointerType TextureImageIterator::GetRow()
		{
			return IterImage;
		}

		inline TImagePointerType TextureImageIterator::GetRow(int y)
		{
			if (!((y < 0) || (y > (int)ima->GetHeight())))
			{
				Ity = y;
				IterImage = ima->GetRawImage() + ima->GetEffWidth()*y;
			}

			return IterImage;
		}

		inline bool TextureImageIterator::NextByte()
		{
			if (++Itx < ima->GetEffWidth())
			 return 1;
			else
			 if (++Ity < ima->GetHeight())
			 {
				IterImage += ima->GetEffWidth();
				Itx = 0;
				return 1;
			 } else
				return 0;
		}

		inline bool TextureImageIterator::PrevByte()
		{
			if (--Itx >= 0)
			 return 1;
			else
			 if (--Ity >= 0)
			 {
				IterImage -= ima->GetEffWidth();
				Itx = 0;
				return 1;
			 } else
				return 0;
		}

		inline bool TextureImageIterator::NextStep()
		{
			Itx += Stepx;
			if (Itx < ima->GetEffWidth())
			 return 1;
			else {
			 Ity += Stepy;
			 if (Ity < ima->GetHeight())
			 {
				IterImage += ima->GetEffWidth();
				Itx = 0;
				return 1;
			 } else
				return 0;
			}
		}

		inline bool TextureImageIterator::PrevStep()
		{
			Itx -= Stepx;
			if (Itx >= 0)
			 return 1;
			else {       
			 Ity -= Stepy;
			 if (Ity >= 0 && Ity < ima->GetHeight())
			 {
				IterImage -= ima->GetEffWidth();
				Itx = 0;
				return 1;
			 } else
				return 0;
			}
		}



	}; // namespace

}; // namespace EngineNamespace




