
/***********************************************************************************
FileName: 	hdrloader.cpp
Author:		Igor Kravtchenko
arranged by ������
************************************************************************************/

#include "hdrloader.h"

#include <math.h>
#include <memory.h>
#include <stdio.h>

typedef unsigned char RGBE[4];
#define R			0
#define G			1
#define B			2
#define E			3

#define  MINELEN	8				// minimum scanline length for encoding
#define  MAXELEN	0x7fff			// maximum scanline length for encoding

static void workOnRGBE(RGBE *scan, int len, long *Pixel);
static void reversedWorkOnRGBE(RGBE *scan, int len, long *Pixel);
static bool decrunch(RGBE *scanline, int len, FILE *file);
static bool crunch(RGBE *scanline, int len, FILE *file);
static bool oldDecrunch(RGBE *scanline, int len, FILE *file);
static bool oldCrunch(RGBE *scanline, int len, FILE *file);

bool HDRLoader::load(const char *fileName, HDRLoaderResult &res)
{
	int i;
	char str[200];
	FILE *file;

	file = fopen(fileName, "rb");

	if (!file)
		return false;

	fread(str, 10, 1, file);
	if (memcmp(str, "#?RADIANCE", 10)) {
		fclose(file);
		return false;
	}

	fseek(file, 1, SEEK_CUR);

	char cmd[200];
	memset(cmd, 0, 200);
	i = 0;
	char c = 0, oldc;
	while (true) {
		oldc = c;
		c = fgetc(file);
		if (c == 0xa && oldc == 0xa)
			break;
		cmd[i++] = c;
	}

	memcpy(res.Cmd, cmd, 200);

	char reso[200];
	i = 0;
	while (true) {
		c = fgetc(file);
		reso[i++] = c;
		if (c == 0xa)
			break;
	}

	int w, h;
	if (!sscanf(reso, "-Y %d +X %d", &h, &w)) {
		fclose(file);
		return false;
	}

	res.width = w;
	res.height = h;

	// Q 2016.9.22
	long *Pixel = new long[w * h];
	res.Pixel = Pixel;

	RGBE *scanline = new RGBE[w];
	if (!scanline) {
		fclose(file);
		return false;
	}

	// convert image 
	for (int y = h - 1; y >= 0; y--) {
		if (decrunch(scanline, w, file) == false)
			break;

		workOnRGBE(scanline, w, Pixel);

		Pixel += w;
	}

	delete[] scanline;
	fclose(file);

	return true;
}

bool HDRLoader::save(const char *fileName, HDRLoaderResult &res)
{
	FILE *file;

	file = fopen(fileName, "wb");

	if (!file)
		return false;

	fwrite("#?RADIANCE", 10, 1, file);
	fputc(0xa, file);
	fwrite(res.Cmd, 200, 1, file);
	fprintf(file, "-Y %d +X %d", res.width, res.height);

	RGBE *scanline = new RGBE[res.width];
	if (!scanline) {
		fclose(file);
		return false;
	}

	for (int y = res.height - 1; y >= 0; y--) {
		reversedWorkOnRGBE(scanline, res.width, res.Pixel);

		if (crunch(scanline, res.width, file) == false)
			break;

		res.Pixel += res.width;
	}

	delete[] scanline;
	fclose(file);

	return true;
}

float convertComponent(int expo, int val)
{
	float v = val / 256.0f;
	float d = (float)pow(2.0f, expo);
	return v * d;
}

void workOnRGBE(RGBE *scan, int len, long *Pixel)
{
	while (len-- > 0) {
		long r = scan[0][R];
		long g = scan[0][G];
		long b = scan[0][B];
		long e = scan[0][E];

		Pixel[0] = ((unsigned long)((((scan[0][E]) & 0x1f) << 27) | (((scan[0][B]) & 0x1ff) << 18) 
			| (((scan[0][G]) & 0x1ff) << 9) | ((scan[0][R]) & 0x1ff)));
		Pixel++;
		scan++;
	}
}

void reversedWorkOnRGBE(RGBE *scan, int len, long *Pixel)
{
	while (len-- > 0) {
		scan[0][R] = (unsigned char)(Pixel[0] & 0x1ff);
		scan[0][G] = (unsigned char)((Pixel[0] & ((0x1ff) << 9)) >> 9);
		scan[0][B] = (unsigned char)((Pixel[0] & ((0x1ff) << 18)) >> 18);
		scan[0][E] = (unsigned char)((Pixel[0] & ((0x1f) << 27)) >> 27);
		
		Pixel++;
		scan++;
	}
}

bool decrunch(RGBE *scanline, int len, FILE *file)
{
	int  i, j;

	if (len < MINELEN || len > MAXELEN)
		return oldDecrunch(scanline, len, file);

	i = fgetc(file);
	if (i != 2) {
		fseek(file, -1, SEEK_CUR);
		return oldDecrunch(scanline, len, file);
	}

	scanline[0][G] = fgetc(file);
	scanline[0][B] = fgetc(file);
	i = fgetc(file);

	if (scanline[0][G] != 2 || scanline[0][B] & 128) {
		scanline[0][R] = 2;
		scanline[0][E] = i;
		return oldDecrunch(scanline + 1, len - 1, file);
	}

	// read each component
	for (i = 0; i < 4; i++) {
		for (j = 0; j < len; ) {
			unsigned char code = fgetc(file);
			if (code > 128) { // run
				code &= 127;
				unsigned char val = fgetc(file);
				while (code--)
					scanline[j++][i] = val;

			}
			else {	// non-run
				while (code--)
					scanline[j++][i] = fgetc(file);
			}
		}
	}

	return feof(file) ? false : true;
}

bool crunch(RGBE *scanline, int len, FILE *file)
{
	int  i, j;

	fputc(2, file);
	fputc(scanline[0][G], file);
	fputc(scanline[0][B], file);
	fputc(0, file);

	// read each component
	for (i = 0; i < 4; i++) {
		for (j = 0; j < len; ) {
			char c, oldc;
			oldc = scanline[j++][i];
			c = scanline[j++][i];

			unsigned char code = 0;
			while (c == oldc) {
				code++;
				oldc = scanline[j++][i];
				c = scanline[j++][i];
			}
			fputc(code, file);
			fputc(oldc, file);

		}
	}

	return feof(file) ? false : true;
}

bool oldDecrunch(RGBE *scanline, int len, FILE *file)
{
	int i;
	int rshift = 0;

	while (len > 0) {
		scanline[0][R] = fgetc(file);
		scanline[0][G] = fgetc(file);
		scanline[0][B] = fgetc(file);
		scanline[0][E] = fgetc(file);
	
		if (feof(file))
			return false;

		if (scanline[0][R] == 1 &&
			scanline[0][G] == 1 &&
			scanline[0][B] == 1) {
			for (i = scanline[0][E] << rshift; i > 0; i--) {
				memcpy(&scanline[0][0], &scanline[-1][0], 4);
				scanline++;
				len--;
			}
			rshift += 8;
		}
		else {
			scanline++;
			len--;
			rshift = 0;
		}
	}
	return true;
}

bool oldCrunch(RGBE *scanline, int len, FILE *file)
{
	int i;
	int rshift = 0;

	while (len > 0) {
		scanline[0][R] = fgetc(file);
		scanline[0][G] = fgetc(file);
		scanline[0][B] = fgetc(file);
		scanline[0][E] = fgetc(file);

		if (feof(file))
			return false;

		if (scanline[0][R] == 1 &&
			scanline[0][G] == 1 &&
			scanline[0][B] == 1) {
			for (i = scanline[0][E] << rshift; i > 0; i--) {
				memcpy(&scanline[0][0], &scanline[-1][0], 4);
				scanline++;
				len--;
			}
			rshift += 8;
		}
		else {
			scanline++;
			len--;
			rshift = 0;
		}
	}
	return true;
}