#include "BasicType/All.h"

#include "DataCollection/All.h"

#include "PSDImage.h"

#include "FileIO/BufferedFile.h"

#include "Debugger/Logger.h"

namespace EngineNamespace
{
	namespace TexImage
	{
		


		

		

		TextureImagePSD::TextureImagePSD()
		{
			
		}

		TextureImagePSD::~TextureImagePSD()
		{
			Delete<psdlite::layered_image*>(PsdImg);
		}

		
		

		bool TextureImagePSD::ReadFile(FileIO::Path& fileName)
		{
			FileName = fileName;
			PsdImg = new psdlite::layered_image();

			if (psdlite::load_layered_image(*PsdImg, FileName.GetAbsolutePath()) == psdlite::error_code_no_error)
			{
				Width = PsdImg->size_.x;
				Height = PsdImg->size_.y;
				MergedPixelBuffer.SetSize(Width*Height);

				return true;
			}

			delete PsdImg;
			PsdImg = NULL;

			return false;
		}

		bool TextureImagePSD::SaveFile(FileIO::Path& fileName, BasicType::String oldExt)
		{
			return true;
		}

		
	}
}