#pragma once

#include "FileIO\Path.h"
#include "EngineNamespace.h"
#include "TexImageBase.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Q Suhmoon, Yongjin Kwon
// Summary : 
// 
//------------------------------------------------------------ 

namespace EngineNamespace
{
	namespace TexImage
	{
		class _PLATFORM_DECL TextureImageDDS : public TextureImageBase
		{
		public:
			TextureImageDDS();
			~TextureImageDDS();
			int GetSize();
			
			virtual bool ReadFile(FileIO::Path& fileName);
			int GetFormat();

		};
	}
}