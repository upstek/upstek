#include "BasicType/All.h"

#include "DataCollection/All.h"

#include "PSDImage.h"

#include "FileIO/BufferedFile.h"

#include "Debugger/Logger.h"

#include "ddsImage.h"

namespace EngineNamespace
{
	namespace TexImage
	{
		DDSImage::DDSImage()
			:Img(NULL)
		{
		}
		DDSImage::~DDSImage()
		{
			Delete<PicoDDS::DDSImg*>(Img);
		}

		bool DDSImage::GetPixel(int x, int y, int * r, int * g, int * b, int * a)
		{

			return true;
		}

		bool DDSImage::LoadDDS(FileIO::Path & fileName)
		{
			Img = new PicoDDS::DDSImg();
			const char filename[] = "../../../data/lena.dds";
			size_t sizeLoaded = PicoDDS::ddsLoad(filename, *Img);

			return true;
		}

	}
}

