#include "DDSImage.h"

namespace EngineNamespace
{
	namespace TexImage
	{
		TextureImageDDS::TextureImageDDS()
		{

		}

		TextureImageDDS::~TextureImageDDS()
		{
			Delete<PicoDDS::DDSImg*>(DdsImg);
			delete[] DXTnBuff;
		}

		int TextureImageDDS::GetSize()
		{
			return DdsImg->GetImageData().size;
		}



		

		bool TextureImageDDS::ReadFile(FileIO::Path & fileName)
		{
			FileName = fileName;
			DdsImg = new PicoDDS::DDSImg();
			
			// Q 2018.4.19
			if (PicoDDS::Load_dds_file(FileName.GetAbsolutePath(), *DdsImg) == 0)
				return false;

			Width = DdsImg->GetImageData().width;
			Height = DdsImg->GetImageData().height;
			Depth = DdsImg->GetImageData().depth;

			unsigned long nBuffSize = Width * Height * 4;
			DXTnBuff = new squish::u8[nBuffSize];

			return true;
		}
		int TextureImageDDS::GetFormat()
		{
			return DdsImg->GetImageData().format;
		}
	}

}


