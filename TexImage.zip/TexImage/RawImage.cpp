

#include "BasicType/All.h"

#include "DataCollection/All.h"

#include "RawImage.h"
#include "bitmap.h"
#include "hdrloader.h"


#include "FileIO/BufferedFile.h"

#include "Debugger/Logger.h"

#include <math.h>

#define _bmp_ReadLittleUint32(dest, fp) _bmp_ReadLittleBytes(dest, 4, fp)
#define BMPREAD_TOP_DOWN   1u
#define BMPREAD_BYTE_ALIGN 2u
#define BMPREAD_ANY_SIZE   4u

#ifdef _DEBUG
////#define new DEBUG_NEW
#endif

namespace EngineNamespace
{


	namespace TexImage
	{



		TextureImageRAW::TextureImageRAW()
		{
			Buffer = NULL;
			Width = 0;
			Height = 0;
			Channel = 3;
		}


		TextureImageRAW::TextureImageRAW(int width, int height, int channel )
		{
			Buffer = NULL;
			Width = 0;
			Height = 0;
			Channel = 3;
			Prepare(width, height, channel);
		}



		TextureImageRAW::~TextureImageRAW()
		{
			Delete<char*>(Buffer);
		}


		void TextureImageRAW::CleanUp()
		{
			Delete<char*>(Buffer);
			Width = 0;
			Height = 0;
			Channel = 3;
		}



		bool TextureImageRAW::Prepare(int width, int height, int channel )
		{
			Delete<char*>(Buffer);

			Width = width;
			Height = height;
			Channel = channel;
			Buffer = new char [ Width * Height * Channel ];
			memset(Buffer, 0, Width * Height * Channel);

			return true;
		}



		




		bool TextureImageRAW::CopyFrom(int dstx, int dsty, TextureImageRAW *src, int x, int y, int w, int h)
		{
			if (src->Channel != Channel)
				return false;

			if (!src->Buffer || !Buffer)
				return false;

			if (dstx == 0 && dsty == 0 && x == 0 && y == 0 && w <= Width && src->Width == Width)
			{
				memcpy(Buffer, src->Buffer, w * h * Channel);
				return true;
			}

			for (int j = 0; j < h; j++)
			{
				char *srcpixel = src->GetPixel(x, y+j);
				char *dstpixel = GetPixel(dstx, dsty+j);
				if (srcpixel && dstpixel)
				{
					int srccut = (x + w) - src->Width; 
					int dstcut = (dstx + w) - Width ;
					int cut = 0;
					if (srccut > 0 || dstcut > 0)
					{
						if (srccut < dstcut)
							cut = dstcut;
						else
							cut = srccut;
					}
					int copylen = w - cut;
					if (copylen > 0)
						memcpy(dstpixel, srcpixel, copylen * Channel );
				}
			}

			return true;
		}





		TextureImageRAW *TextureImageRAW::Duplicate() // new copy raw image
		{
			TextureImageRAW *image = new TextureImageRAW(Width, Height, Channel);
			memcpy(image->Buffer, Buffer, Width * Height * Channel);

			return image;

		}









		#define INVERTED_BIT            (1 << 5)

		#if !defined(_ANDROID) && !defined(_IPHONE) 
		#pragma pack(push,x1)                            // Byte alignment (8-bit)
		#endif

		#pragma pack(1)

		typedef struct
		{
			 unsigned char  IdSize,
											MapType,
											ImageType;
			 unsigned short PaletteStart,
											PaletteSize;
			 unsigned char  PaletteEntryDepth;
			 unsigned short X,
											Y,
											Width,
											Height;
			 unsigned char  ColorDepth,
											Descriptor;
		         
		} TGA_HEADER;

		#if !defined(_ANDROID) && !defined(_IPHONE) 
		#pragma pack(pop,x1)
		#endif

		bool TextureImageRAW::ReadFile(FileIO::Path& imageFileName)
		{
			FileName = imageFileName;
			switch (FileType)
			{
			case 0:
				return LoadTGA(imageFileName);

			case 1:
				return LoadBMP(imageFileName);
			}
			return true;
		}

		bool TextureImageRAW::LoadBMP(FileIO::Path& fileName)
		{
			int success = 1;

			Bitmap bmp;
			bmp.Load(fileName.GetSystemPath());
			
			Width = bmp.GetWidth();
			Height = bmp.GetHeight();


			Channel = 4;
			int iter = 0;
			Buffer = new char[Width * Height * Channel];
			for (int i = Height-1; i >=0 ; i--)
			{
				for (int j = 0; j < Width; j++)
				{
					Buffer[iter++] = bmp.m_BitmapData[i * Width + j].Red;
					Buffer[iter++] = bmp.m_BitmapData[i * Width + j].Green;
					Buffer[iter++] = bmp.m_BitmapData[i * Width + j].Blue;
					Buffer[iter++] = bmp.m_BitmapData[i * Width + j].Alpha;
				}
			}

			return success;
		}

		//#include "base/TickTracer.h" _CE_PERF_TUNING

		bool TextureImageRAW::LoadTGA( FileIO::Path& fileName )
		{
			//CTickTracer tracer("LoadTGA");

			CleanUp();


			TGA_HEADER   Header;

			FileIO::BufferedFile f;
			FileIO::FileException ex;

			if (!f.Open(fileName, FileIO::File::modeRead | FileIO::File::typeBinary, &ex))
				return false;


			f.Read ( &Header, sizeof(TGA_HEADER));

			Width = Header.Width;
			Height = Header.Height;

			if ( Header.ColorDepth == 24 )
			{
				Debugger::GetLogger().Log("------------------------log 24bit, %d %d %s" , Width, Height, (const char*)fileName.GetSystemPath() );

				Channel = 3;

				RGBTRIPLE *Buffer24;
				Buffer24= new RGBTRIPLE[(Width) * (Height)];

				if(Buffer24)
				{
					int i=0;
					int x, y;

					f.Read(Buffer24, sizeof(RGBTRIPLE) * (Width) * (Height));

					Buffer = new char [Channel * (Width) * (Height)];

					int Index = 0;
					if(!(Header.Descriptor & INVERTED_BIT))
					{
						/* old slow code
						for ( y = 0; y < Height; y++ )
						for( x = 0; x < Width; x++ )
						{
							int Index ;

							Index= ((Height) - 1 - y) * (Width) + x;

							RGBTRIPLE *p = Buffer24+Index;
							(Buffer)[i]= p->rgbtRed;
							i ++;
							(Buffer)[i]= p->rgbtGreen;
							i ++;
							(Buffer)[i]= p->rgbtBlue;
							i ++;
						}
						*/
						char *buf = Buffer;
						for ( y = 0; y < Height; y++ )
						{
							int Index ;

							Index= ((Height) - 1 - y) * (Width) + 0;
							RGBTRIPLE *p = Buffer24+Index;

							for( x = 0; x < Width; x++ )
							{
								*buf = p->rgbtRed;
								buf ++;
								*buf = p->rgbtGreen;
								buf ++;
								*buf = p->rgbtBlue;
								buf ++;
								p++;
							}
						}

					}
					else
					{
						// faster code rewrite
						RGBTRIPLE *p = Buffer24;
						char *buf = Buffer;
						for ( y = 0; y < Height; y++ )
						for( x = 0; x < Width; x++ )
						{
							*buf = p->rgbtRed;
							buf ++;
							*buf = p->rgbtGreen;
							buf ++;
							*buf = p->rgbtBlue;
							buf ++;
							p++;
						}
					}

					f.Close();
					Delete<RGBTRIPLE *>(Buffer24);

					return true;
				}		
				else
					return false;

			}
			else
			if ( Header.ColorDepth == 32)
			{	
				Debugger::GetLogger().Log("------------------------log 32bit, %d %d %s" , Width, Height, (const char*)fileName.GetSystemPath() );
				//Debugger::GetLogger().Log(Debugger::FilterDebug, "------------------------log 32bit, %d %d %s" , Width, Height, fileName  );

				Channel = 4;
				RGBQUAD *Buffer32;
				Buffer32= new RGBQUAD[(Width) * (Height)];

				if(Buffer32)
				{
					int i=0;
					int x, y;

					f.Read(Buffer32, sizeof(RGBQUAD) * (Width) * (Height) );

					Buffer = new char [Channel * (Width) * (Height)];

					if(!(Header.Descriptor & INVERTED_BIT))
					{

						/* old slow code
						for ( y = 0; y < Height; y++ )
						for( x = 0; x < Width; x++ )
						{
							 int Index= 0;

								Index= ((Height) - 1 - y) * (Width) + x;

							 (Buffer)[(i * 4)]=      Buffer32[Index].rgbRed;
							 (Buffer)[(i * 4) + 1]=  Buffer32[Index].rgbGreen;
							 (Buffer)[(i * 4) + 2]=  Buffer32[Index].rgbBlue;
							 (Buffer)[(i * 4) + 3]=  Buffer32[Index].rgbReserved;

							 i++;
						}
						*/
						char *buf = Buffer;
						for ( y = 0; y < Height; y++ )
						{
							int Index = 0;

							Index = ((Height) - 1 - y) * (Width) + 0 ;
							RGBQUAD *p = Buffer32 + Index;

							for( x = 0; x < Width; x++ )
							{
								*buf = p->rgbRed;
								buf ++;
								*buf = p->rgbGreen;
								buf ++;
								*buf = p->rgbBlue;
								buf ++;
								*buf = p->rgbReserved;
								buf ++;
								p++;
							}
						}
					}
					else
					{
						// faster code rewrite
						RGBQUAD *p = Buffer32;
						char *buf = Buffer;
						for ( y = 0; y < Height; y++ )
						for( x = 0; x < Width; x++ )
						{
							*buf = p->rgbRed;
							buf ++;
							*buf = p->rgbGreen;
							buf ++;
							*buf = p->rgbBlue;
							buf ++;
							*buf = p->rgbReserved;
							buf ++;
							p++;
						}
					}

					f.Close();
					Delete<RGBQUAD *>(Buffer32);
					return(true);
				}		
			}
			else
			if ( Header.ColorDepth == 16 )
			{
				//Debugger::GetLogger().Log(Debugger::FilterDebug, "------------------------log 24bit, %d %d %s" , Width, Height, fileName  );

				Channel = 3;

				unsigned short *Buffer16;
				Buffer16 = new unsigned short[(Width) * (Height)];

				if(Buffer16)
				{
					int i=0;
					int x, y;

					f.Read(Buffer16, sizeof(unsigned short) * (Width) * (Height));

					Buffer = new char [Channel * (Width) * (Height)];

					int Index = 0;
					if(!(Header.Descriptor & INVERTED_BIT))
					{
						/* old slow code
						for ( y = 0; y < Height; y++ )
						for( x = 0; x < Width; x++ )
						{
							int Index ;

							Index= ((Height) - 1 - y) * (Width) + x;

							RGBTRIPLE *p = Buffer24+Index;
							(Buffer)[i]= p->rgbtRed;
							i ++;
							(Buffer)[i]= p->rgbtGreen;
							i ++;
							(Buffer)[i]= p->rgbtBlue;
							i ++;
						}
						*/
						char *buf = Buffer;
						for ( y = 0; y < Height; y++ )
						{
							int Index ;

							Index= ((Height) - 1 - y) * (Width) + 0;
							unsigned short *p = Buffer16+Index;

							for( x = 0; x < Width; x++ )
							{
								char r, g, b;
								r = ((*p>>10)&31)*255/31;
								g = ((*p>>5)&31)*255/31;
								b = ((*p>>0)&31)*255/31;

								*buf = r;
								buf ++;
								*buf = g;
								buf ++;
								*buf = b;
								buf ++;
								p++;
							}
						}

					}
					else
					{
						// faster code rewrite
						unsigned short *p = Buffer16;
						char *buf = Buffer;
						for ( y = 0; y < Height; y++ )
						for( x = 0; x < Width; x++ )
						{
							char r, g, b;
							r = ((*p>>10)&31)*255/31;
							g = ((*p>>5)&31)*255/31;
							b = ((*p>>0)&31)*255/31;

							*buf = r;
							buf ++;
							*buf = g;
							buf ++;
							*buf = b;
							buf ++;
							p++;
						}
					}

					f.Close();
					Delete<unsigned short *>(Buffer16);

					return true;
				}		
				else
					return false;

			}
			else
			{
				char * str = fileName.ToString();
				Debugger::GetLogger().Log(Debugger::FilterDebug, "------------------- Unknown TGA %s" , str );
			}
			return false;
		}





		bool TextureImageRAW::LoadRaw( FileIO::Path& fileName )
		{
			CleanUp();
			 
			FileIO::BufferedFile f;

			FileIO::FileException ex;
			if (!f.Open(fileName, FileIO::File::modeRead | FileIO::File::typeBinary, &ex))
				return false;

			int len = f.GetLength();

			Width = (int)sqrt( ((float)len) / sizeof(RGBTRIPLE) );
			Height = Width;
			Channel = 3;

			Buffer = new char [Channel * (Width) * (Height) ];
			f.Read(Buffer, Channel * (Width) * (Height));
			f.Close();

			return true;
		}





		bool TextureImageRAW::SaveRaw( FileIO::Path& fileName  )
		{
			 
			FileIO::BufferedFile f;

			FileIO::FileException ex;
			if (!f.Open(fileName, FileIO::File::modeCreate | FileIO::File::modeWrite | FileIO::File::typeBinary, &ex))
				return false;

			f.Write(Buffer, Channel * (Width) * (Height));
			f.Close();

			return true;
		}





	}; // namespace

}; // namespace EngineNamespace

 