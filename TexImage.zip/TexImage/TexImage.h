#pragma once

#include "BasicType/All.h"
#include "FileIO/Path.h"

#include "TexImageBase.h"


#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 



namespace EngineNamespace
{




	namespace TexImage
	{

		class _PLATFORM_DECL TextureImageBase;
		class _PLATFORM_DECL TextureVideo;

		typedef unsigned char *TImagePointerType;

		extern TextureImageBase *LoadTextureImage(FileIO::Path &filename, BasicType::String ext = "");  // should delete after use

	#ifdef _DX
		// by ghostfilm, by code3 for Video
		extern TextureVideo *LoadTextureVideo(FileIO::Path &filename, bool is360 = false);  // should delete after use
	#endif

		extern bool CopyImage(TextureImageBase *src, TextureImageBase *tar);  // should delete after use


	}; // namespace





}; // namespace EngineNamespace
