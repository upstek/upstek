//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
//
// Author : Choi Hansik
// Summary : E# API Ver2 for Wolrd class
//
//------------------------------------------------------------


#ifdef USE_ESHARP


#include "BasicType/All.h"

#include "Debugger/Logger.h"
#include "Utility/StringTool.h"


#ifdef _WIN32PC
#include <Windows.h>
#endif
#include "video/TexImageVideo.h"
#include "ComponentDictionary.h"

#include "../Platform/Context/Context.h"



using namespace EngineNamespace;


void Engine_TextureVideo_Play(const es_char * VideoFilePath)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);

	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video)
	{
		video->Play();
	}
	

	


}
typedef void(*Func_TextureVideo_Play)(const es_char * VideoFilePath);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_Play);

void Engine_TextureVideo_Play_time(const es_char * VideoFilePath, double time)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);

	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video)
	{
		video->Play(time);
	}





}
typedef void(*Func_TextureVideo_Play_time)(const es_char * VideoFilePath, double time);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_Play_time);



void Engine_TextureVideo_Stop(const es_char * VideoFilePath)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);
	
	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video)
	{
		video->Stop();
	}
}
typedef void(*Func_TextureVideo_Stop)(const es_char * VideoFilePath);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_Stop);

void Engine_TextureVideo_Pause(const es_char * VideoFilePath)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);
	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video)
	{
		video->Pause();
	}


}
typedef void(*Func_TextureVideo_Pause)(const es_char * VideoFilePath);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_Pause);







bool Engine_TextureVideo_IsPlaying(const es_char * VideoFilePath)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);

	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video != NULL)
	{
		return video->IsPlaying();
	}

	return false;
}
typedef bool(*Func_TextureVideo_IsPlaying)(const es_char * VideoFilePath);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_IsPlaying);



bool Engine_TextureVideo_IsTimeEnd(const es_char * VideoFilePath)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);

	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video != NULL)
	{
		return video->IsTimeEnd();
	}

	return false;
}
typedef bool(*Func_TextureVideo_IsTimeEnd)(const es_char * VideoFilePath);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_IsTimeEnd);


float Engine_TextureVideo_GetPlayTime(const es_char * VideoFilePath)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);

	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video != NULL)
	{
		return video->GetPlayTime();
	}

	return 0.0f;
}
typedef float(*Func_TextureVideo_GetPlayTime)(const es_char * VideoFilePath);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_GetPlayTime);



bool Engine_TextureVideo_SetPlayTime(const es_char * VideoFilePath, float time)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);

	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video != NULL)
	{
		return video->SetPlayTime(time);
	}

	return false;
}
typedef bool(*Func_TextureVideo_SetPlayTime)(const es_char * VideoFilePath, float time);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_SetPlayTime);


float Engine_TextureVideo_GetTotalPlayTime(const es_char * VideoFilePath)
{
	Context::Context *ActiveContext = EngineNamespace::Context::GetActiveContext();
	Code3::BasicType::String strVideoFilePath = ASTRING(VideoFilePath);
	EngineNamespace::FileIO::Path VideoPath;
	VideoPath.FromString(strVideoFilePath.GetString());
	//VideoPath.SetRelativePath(Code3::Dictionary::project, strVideoFilePath);

	EngineNamespace::TexImage::TextureVideo* video = ActiveContext->FindVideo(VideoPath);
	if (video != NULL)
	{
		return video->GetTotalPlayTime();
	}

	return 0.0f;
}
typedef float(*Func_TextureVideo_GetTotalPlayTime)(const es_char * VideoFilePath);
ES_INTERFACE_MAP_USERFUNC_CALLBACK(TextureVideo_GetTotalPlayTime);








ES_INTERFACE_LINKFUNC_BEGIN(TexImage, TextureVideo)

	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_Play);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_Play_time);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_Stop);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_Pause);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_IsPlaying);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_IsTimeEnd);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_GetPlayTime);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_SetPlayTime);
	ES_INTERFACE_MAP_USERFUNC_METHOD_CODE(TextureVideo_GetTotalPlayTime);


	ES_INTERFACE_LINKFUNC_END











#endif // USE_ESHARP



