#pragma once

// by ghostfilm
#include "BasicType/All.h"


#include "EngineNamespace.h"


#include "TexImageBase.h"


#include "TexImagePalette.h"

#include "ESInterface/ESTypes.h"
#include "ESInterface/ESString.h"
#include "ESInterface/ESInterfaceTemplates.h"
#include "ESInterface/ESInterface.h"

namespace EngineNamespace
{


	namespace Time
	{
		class FrameTimer;
	}




	namespace TexImage
	{



#if TEXIMAGE_SUPPORT_JPEG






		class _PLATFORM_DECL TextureVideo : public TextureImageBase
		{
			void*	pPlayerObj;
			void*	pCallbackObj;
			void*	pReceiveProcObj;

		private:
			//0:none, 1:play, 2:pause, 3:timeend
			int State;

		protected:
			void CreateGrayColourMap(int n);
		public:
			TextureVideo();
			virtual ~TextureVideo();

			TextureImagePalette Palette;

			virtual bool ReadFile(FileIO::Path& imageFileName, bool is360 = false);
			virtual bool SaveFile(FileIO::Path& imageFileName);
			virtual bool HasUpdatedTextureData();
			virtual bool GetUpdatedTextureData(void* pPixels);

			virtual bool Update(Time::FrameTimer *t);
			void Play();
			void Pause();
			void Stop();
			void PauseFixFrame(double worldTime);
			void Play(double worldTime);
			//HBITMAP TextureVideo::GetFrame(double ts);

			bool IsPlaying();
			bool IsTimeEnd();
			float GetPlayTime();
			bool SetPlayTime(float time);
			float GetTotalPlayTime();


			void SetColorSpace(int);

			// kbj
			void SetRenderVisibleType(bool _type);
			int frameCount;
			//bool m_bDumpToFile;
			//double m_nextTimeToSave;

			ES_INTERFACE_MAP_DECL(TextureVideo);
		};


#endif
		

	}; // namespace



}; // namespace EngineNamespace



#pragma once
