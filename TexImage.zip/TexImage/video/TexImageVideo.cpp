// by ghostfilm


#include <atlbase.h>
#include <assert.h>

#include "BasicType/All.h"

#include "TexImageDef.h"

#include "FileIO/VFS.h"

#include "Compatibility/syssetjmp.h"

#include "TexImajpg.h"


#include "DataCollection/All.h"

#include "time/Timer.h"



#if TEXIMAGE_SUPPORT_JPEG



#include <stdio.h>



#include "TexImageIter.h"

#include "FileIO/BufferedFile.h"

#include "Math3D/ColorConversion.h"


#include "Debugger/Logger.h"


#include "Utility/FileTool.h"

#include "TexImageVideo.h"
/*#include "ltmm.h"
#include "filters\ILMVCallback2.h"  // for ILMVUserCallback
#include "filters\ILMMCommon.h"  // for ILMMCommon*/

#include "VideoPlayer.h"

#include "BasicType/All.h"
#include "Math3D/All.h"


#ifdef _DEBUG
//#define new DEBUG_NEW
#endif


//#pragma comment (lib, "ltmm.lib")
//#pragma comment (lib, "ltmmuuid.lib")



namespace EngineNamespace
{
	static bool g_bCoInitializeCalled = false;

	namespace Scene
	{
		extern Matrix CurrentCameraViewMatrix;
		extern Matrix CurrentCameraProjMatrix;
		extern Matrix CurrentCameraWorldMatrix;
	}


	namespace TexImage
	{
#if false
		class _PLATFORM_DECL CallbackReceiver : public ILMVUserCallback2
		{
			TextureVideo* m_texVideo;
			CRITICAL_SECTION  m_csPaint;
			struct
			{
				BITMAPINFOHEADER  bmiHeader;
				RGBQUAD           bmiColors[256];
			} m_bi;

			// variables containing the last image buffer
			unsigned char *   m_pBuffer;        // pointer to the buffer holding the data
			long              m_nBufferSize;    // size of the useful data in m_pBuffer
			long              m_nMaxBufferSize; // maximum size of the buffer

		public:
			CallbackReceiver(TextureVideo* _texVideo)
			{
				this->m_texVideo = _texVideo;

				ZeroMemory(&m_bi, sizeof(m_bi));
				m_pBuffer = NULL;
				m_nBufferSize = 0;
				m_nMaxBufferSize = 0;

				InitializeCriticalSection(&m_csPaint);
			}

			~CallbackReceiver()
			{
				if (m_pBuffer)
				{
					free(m_pBuffer);
					m_pBuffer = 0;
					m_nBufferSize = 0;
					m_nMaxBufferSize = 0;
				}

				DeleteCriticalSection(&m_csPaint);
			}

			// implement the IUnknown
			STDMETHODIMP QueryInterface(REFIID riid, void **ppv)
			{
				if (ppv == NULL) return E_POINTER;

				if (riid == IID_ILMVUserCallback2)
				{
					*ppv = (ILMVUserCallback2 *)this;
					return S_OK;
				}

				return E_NOINTERFACE;
			}

			STDMETHODIMP_(ULONG) AddRef()
			{
				return S_OK;
			}

			STDMETHODIMP_(ULONG) Release()
			{
				return S_OK;
			}

			// ILMVUserCallback function
			STDMETHODIMP ReceiveProc(LONGLONG pData, LONG lWidth, LONG lHeight, LONG lBitCount, LONG lSize, LONG bTopDown)
			{
				EnterCriticalSection(&m_csPaint);

				if (m_bi.bmiHeader.biWidth != lWidth || abs(m_bi.bmiHeader.biHeight) != lHeight || m_bi.bmiHeader.biBitCount != lBitCount)
				{
					m_bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
					m_bi.bmiHeader.biWidth = lWidth;
					m_bi.bmiHeader.biHeight = bTopDown ? -lHeight : lHeight;
					m_bi.bmiHeader.biPlanes = 1;
					m_bi.bmiHeader.biBitCount = (WORD)lBitCount;
					m_bi.bmiHeader.biCompression = BI_RGB;
					m_bi.bmiHeader.biSizeImage = lSize;
					m_bi.bmiHeader.biXPelsPerMeter = 0;
					m_bi.bmiHeader.biYPelsPerMeter = 0;
					m_bi.bmiHeader.biClrUsed = 0;
					m_bi.bmiHeader.biClrImportant = 0;
				}

				HRESULT hr = SaveBitmapBuffer((void *)pData, lSize);
				assert(hr == S_OK);

				Debugger::GetLogger().Log("ReceiveProc: %ldx%ld %ld-bit %ld-byte\n", lWidth, lHeight, lBitCount, lSize);

				LeaveCriticalSection(&m_csPaint);

				return hr;
			}

			HRESULT SaveBitmapBuffer(void *pData, long lSize)
			{
				if (m_nMaxBufferSize < lSize)
				{
					unsigned char* pBuffer = (unsigned char*)realloc(m_pBuffer, lSize);
					if (!pBuffer)
						return E_OUTOFMEMORY;
					m_pBuffer = pBuffer;
					m_nMaxBufferSize = lSize;
				}
				memcpy(m_pBuffer, pData, lSize);
				m_nBufferSize = lSize;

				return S_OK;
			}

			// should be called by main thread
			int LoadTextures(TextureVideo* pTex, void* pPixels)					// Load bitmaps to texture
			{
				int status = FALSE;

				//EnterCriticalSection(&m_csPaint);

				if (m_pBuffer != NULL && m_nBufferSize > 0)
				{
					status = TRUE;
					WORD wBitCount = m_bi.bmiHeader.biBitCount;

					//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, m_bi.bmiHeader.biWidth, m_bi.bmiHeader.biHeight, 0, GL_BGRA_EXT, GL_UNSIGNED_BYTE, m_pBuffer);
					int width = m_bi.bmiHeader.biWidth;
					int height = m_bi.bmiHeader.biHeight;

					unsigned int* pPixel = (unsigned int *)pPixels;
					for (int row = 0; row < height; row++) {
						for (int col = 0; col < width; col++)
						{
							int index = (row * width + col);
							byte r = m_pBuffer[(row * m_bi.bmiHeader.biWidth + col) * (m_bi.bmiHeader.biBitCount / 8)];
							byte g = m_pBuffer[(row * m_bi.bmiHeader.biWidth + col) * (m_bi.bmiHeader.biBitCount / 8) + 1];
							byte b = m_pBuffer[(row * m_bi.bmiHeader.biWidth + col) * (m_bi.bmiHeader.biBitCount / 8) + 2];
							byte a = 0xff;
							pPixel[index] = COLOR_ARGB(a, b, g, r);
						}
					}
				}

				//LeaveCriticalSection(&m_csPaint);

				return status;
			}
		};

		static HRESULT AddVideoProcessor(IltmmPlay* pPlayer, LPWSTR pwszProcessorName, REFIID riid, void **ppv)
		{
			// Add the processor
			CComPtr<IltmmProcessors> processors;
			CComPtr<IltmmProcessors> selprocessors;
			CComPtr<IltmmProcessor> proc;

			HRESULT hr = pPlayer->get_VideoProcessors(&processors);
			assert(hr == S_OK);

			hr = pPlayer->get_SelectedVideoProcessors(&selprocessors);
			assert(hr == S_OK);

			//Get the processor index:
			long lIndex = 0;
			BSTR bstr = SysAllocString(pwszProcessorName);
			hr = processors->Find(bstr, &lIndex);
			SysFreeString(bstr); // free the string, as I don't need it anymore
			assert(hr == S_OK);

			hr = processors->Item(lIndex, &proc);
			assert(hr == S_OK);

			hr = selprocessors->RemoveAll();
			assert(hr == S_OK);

			hr = selprocessors->Add(proc, -1);
			assert(hr == S_OK);

			CComPtr<IUnknown> pProcessor;
			hr = pPlayer->GetSubObject(ltmmPlay_Object_SelVideoProcessor + 0, &pProcessor);
			assert(hr == S_OK);

			return pProcessor->QueryInterface(riid, ppv);
		}
#endif

		TextureVideo::TextureVideo()
			: State(0)
		{
			if (!g_bCoInitializeCalled) {
				CoInitialize(NULL);
				g_bCoInitializeCalled = true;
			}
			
			bool renderVisibleOnly = true;
			VideoPlayer* pPlayer = new VideoPlayer(renderVisibleOnly, false);

			//VideoPlayer* pPlayer = new VideoPlayer(true, false);
			this->pPlayerObj = pPlayer;

			frameCount = 0;
		}

		TextureVideo::~TextureVideo()
		{
			/*if (this->pPlayerObj != NULL) {
				IltmmPlay* pPlayer = (IltmmPlay *)this->pPlayerObj;
				pPlayer->Release();
			}
			if (this->pCallbackObj != NULL) {
				ILMVCallback* pCallback = (ILMVCallback *)this->pCallbackObj;
				pCallback->put_ReceiveProcObj(NULL);
				pCallback->Release();
			}*/
		}

		bool TextureVideo::ReadFile(FileIO::Path& imageFileName, bool is360)
		{
			USES_CONVERSION;
			BasicType::String pathstr = imageFileName.GetAbsolutePath(); // fix by code3 // ghostfilm notice 

			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (!pPlayer->OpenFile(A2W((const char*)pathstr), is360))
				return false; 

			//
			Create(pPlayer->m_width, pPlayer->m_height, 32);

			for (int i = 0; i < this->GetHeight(); i++) {
				int idx = i * this->GetEffWidth();
				for (int j = 0; j < this->GetEffWidth() / 4; j++) {
					// BGRA
					RawImageData[idx + j * 4] = 0;
					RawImageData[idx + j * 4 + 1] = 255;
					RawImageData[idx + j * 4 + 2] = 0;
					RawImageData[idx + j * 4 + 3] = 255;
				}
			}

			

			if (is360)
			{
				pPlayer->SetRenderVisibleOnly(true);
			}
			else
			{
				pPlayer->SetRenderVisibleOnly(false);
			}

			// kbj
			// �ӽ÷� ����
			this->Play();
			this->Stop();

#if false
			char* pathstr = imageFileName.GetPathName().GetString();

			//
			IltmmPlay* pPlayer = (IltmmPlay *)this->pPlayerObj;
			HRESULT hr = pPlayer->put_SourceFile(A2BSTR(pathstr));
			assert(hr == S_OK);
			hr = pPlayer->put_AllowedStreams(ltmmPlay_Stream_Video);
			assert(hr == S_OK);

			long lRendered = 0;
			hr = pPlayer->get_RenderedStreams(&lRendered);
			assert(hr == S_OK);
			if ((lRendered & ltmmPlay_Stream_Video) != ltmmPlay_Stream_Video)
			{
				pPlayer->ResetSource();
				assert(false);
			}

			long video_width, video_height;
			/*
			hr = pPlayer->get_VideoWidth(&video_width);
			assert(hr == S_OK);
			hr = pPlayer->get_VideoHeight(&video_height);
			assert(hr == S_OK);
			*/
			video_width = 1280;
			video_height = 640;

			// temp
			Create(video_width, video_height, 32);

			for (int i = 0; i < this->GetHeight(); i++) {
				int idx = i * this->GetEffWidth();
				for (int j = 0; j < this->GetEffWidth() / 4; j++) {
					// BGRA
					RawImageData[idx + j * 4] = 0;
					RawImageData[idx + j * 4 + 1] = 255;
					RawImageData[idx + j * 4 + 2] = 0;
					RawImageData[idx + j * 4 + 3] = 255;
				}
			}

			//
			ILMVCallback* pCallback = (ILMVCallback *)this->pCallbackObj;
			CComPtr<ILMMCommon> pCommon;
			hr = pCallback->QueryInterface(IID_ILMMCommon, (void**)&pCommon);
			if (SUCCEEDED(hr) && pCommon)
			{
				long lBitPerPixel = 0;
				hr = pCommon->get_InBits(0, &lBitPerPixel);
				if (SUCCEEDED(hr))
				{
					if (lBitPerPixel == 16 || lBitPerPixel == 12)
					{
						assert(false);
					}
				}
			}
			else {
				assert(false);
			}

			CallbackReceiver* pReceiveProc = (CallbackReceiver *)this->pReceiveProcObj;
			hr = pCallback->put_ReceiveProcObj(pReceiveProc);
			assert(hr == S_OK);

			//
			this->Play();
#endif
			return true;
		}

		bool TextureVideo::SaveFile(FileIO::Path& imageFileName)
		{
			return true;
		}

		void TextureVideo::SetColorSpace(int)
		{

		}

		void TextureVideo::SetRenderVisibleType(bool _type)
		{
			if (this == NULL || this->pPlayerObj == NULL)
			{
				return;
			}

			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			pPlayer->SetRenderVisibleOnly(_type);
		}

		bool TextureVideo::HasUpdatedTextureData()
		{
			return true;
		}

		bool TextureVideo::GetUpdatedTextureData(void* pPixels)
		{
			/*CallbackReceiver* pReceiverProc = (CallbackReceiver *)this->pReceiveProcObj;
			int ret = pReceiverProc->LoadTextures(this, pPixels);
			return (ret == 1);*/
			HRESULT hr;

			Matrix matWorld = Scene::CurrentCameraWorldMatrix;
			Matrix matView = Scene::CurrentCameraViewMatrix;

			Matrix mat = matWorld * matView;

			Vector3 pos, scale;
			Quaternion rot;
			matWorld.DecomposeMatrix(&pos, &rot, &scale);
			Vector3 rot_v = Quaternion::QuaternionToEulerDegreeFloat(rot);

			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			hr = pPlayer->LoadTexture(pPixels, rot_v.x, rot_v.y, rot_v.z);
			return (hr == S_OK);
		}

		bool TextureVideo::Update(Time::FrameTimer *t)
		{
			//int fpsTickCount = t->GetTickCount();
			//int fpsTickCount = frameCount;
			double stepAdvance = t->GetStepAdvance();
			if (stepAdvance > 0)
			{
//<<<<<<< HEAD
				Debugger::GetLogger().Log("Timer Step Advance is on. Force %.2f FPS", 1.0/(float)stepAdvance);
				

				double frameTime = frameCount * stepAdvance;
				Debugger::GetLogger().Log("Timer Step Advance is on. this time %.2f", frameTime);

				if (frameCount < 1)
				{
					SetRenderVisibleType(false);
					this->Pause();
				}
				// frameTime ����Ͽ� ������ pause �ð��� ���߾�� �Ѵ�.
				PauseFixFrame(frameTime);
				//PauseFixFrame(0.1);

				frameCount++;
//=======
//			#ifdef _DEBUG
//				Debugger::GetLogger().Log("Timer Step Advance is on. Force %.2f FPS", 1.0/(float)t->GetStepAdvance() );
//			#endif
//>>>>>>> 0e464e29018fc18feae78eee8560961cdbeaeca8
			}
			else
			{
			}

			if (State == 1)
			{
				if (GetPlayTime() >= GetTotalPlayTime())
				{
					State = 3;
				}
			}
			else if (State == 3)
			{
				State = 0;
			}

			return true;
		}



		void TextureVideo::Play()
		{
			HRESULT hr;
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer)
			{
				if (State == 0)
					SetPlayTime(0.0f);

				//pPlayer->SeekToTimeAndRun(0.1);
				hr = pPlayer->Run();
				assert(hr == S_OK);

				if (hr == S_OK)
					State = 1;
			}
		}

		void TextureVideo::Pause()
		{
			HRESULT hr;

			//IltmmPlay* pPlayer = (IltmmPlay *)this->pPlayerObj;
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer)
			{
				hr = pPlayer->Pause();
				assert(hr == S_OK);


				if (hr == S_OK)
					State = 2;
			}

		}

		void TextureVideo::Stop()
		{
			HRESULT hr;

			//IltmmPlay* pPlayer = (IltmmPlay *)this->pPlayerObj;
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer)
			{
				pPlayer->SeekToTimeAndRun(0.0);
				hr = pPlayer->Pause();
				assert(hr == S_OK);

				if (hr == S_OK)
					State = 0;
			}
		}

		void TextureVideo::PauseFixFrame(double worldTime)
		{
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer)
			{
				HRESULT hr = pPlayer->SeekToTime(worldTime);

				if (hr == S_OK)
					State = 2;
			}
		}

		void TextureVideo::Play(double worldTime)
		{
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer)
			{
				HRESULT hr = pPlayer->SeekToTimeAndRun(worldTime);

				if (hr == S_OK)
					State = 1;
			}
		}

		bool TextureVideo::IsPlaying()
		{
			return (State == 1);
		}

		bool TextureVideo::IsTimeEnd()
		{
			return (State == 3);
		}

		float TextureVideo::GetPlayTime()
		{
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer != NULL)
			{
				return pPlayer->GetCurrentPosition();
			}

			return -1.0f;
		}

		bool TextureVideo::SetPlayTime(float time)
		{
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer != NULL)
			{
				pPlayer->SeekToTimeAndRun(time);

				if (State != 1)
					Pause();
			}

			return false;
		}

		float TextureVideo::GetTotalPlayTime()
		{
			VideoPlayer* pPlayer = (VideoPlayer *)this->pPlayerObj;
			if (pPlayer != NULL)
			{
				return pPlayer->GetTotalLength();
			}

			return -1.0f;
		}

		//HBITMAP TextureVideo::GetFrame(double ts)
		//{
		//	m_bDumpToFile = false;

		//	m_nextTimeToSave = ts;

		//	REFERENCE_TIME rtBegin = COARefTime(ts);
		//	REFERENCE_TIME rtEnd = COARefTime(ts + 0.1);

		//	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
		//	IMediaSeeking* pSeeking = (IMediaSeeking *)this->pSeekingObj;

		//	pSeeking->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
		//	HRESULT hr = pSeeking->SetPositions(&rtBegin, AM_SEEKING_AbsolutePositioning, &rtEnd, AM_SEEKING_AbsolutePositioning);

		//	IMediaEventEx* pEvent = (IMediaEventEx *)this->pEventObj;

		//	pControl->Pause();
		//	pControl->Run();

		//	long evCode;
		//	hr = pEvent->WaitForCompletion(INFINITE, &evCode);

		//	pControl->Pause();

		//	//
		//	if (m_bmp != NULL) {
		//		using namespace Gdiplus;
		//		Bitmap* bmp = (Gdiplus::Bitmap *)m_bmp;
		//		HBITMAP hbm;
		//		bmp->GetHBITMAP(Color::Transparent, &hbm);

		//		return hbm;
		//	}

		//	return NULL;
		//}

	}; // namespace

}; // namespace EngineNamespace



#endif // TEXIMAGE_SUPPORT_JPEG

