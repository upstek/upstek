
// by ghostfilm

#ifdef _WIN32PC
#include <Windows.h>
#endif
#include <dshow.h>
#include "qedit.h"
#include "Reftime.h"
#include <assert.h>
#include <math.h>

#include "VideoPlayer.h"

#define ASSERT(X)	

#ifndef COLOR_ARGB
#define COLOR_ARGB(a,r,g,b) ((unsigned long)((((a)&0xff)<<24)|(((r)&0xff)<<16)|(((g)&0xff)<<8)|((b)&0xff)))
#endif

#define MAX(A, B)	(((A) >= (B))? (A) : (B))
#define MIN(A, B)	(((A) <= (B))? (A) : (B))


template <class T> static void SafeRelease(T **ppT)
{
	if (*ppT)
	{
		(*ppT)->Release();
		*ppT = NULL;
	}
}

// Query whether a pin is connected to another pin.
//
// Note: This function does not return a pointer to the connected pin.
static HRESULT IsPinConnected(IPin *pPin, BOOL *pResult)
{
	IPin *pTmp = NULL;
	HRESULT hr = pPin->ConnectedTo(&pTmp);
	if (SUCCEEDED(hr))
	{
		*pResult = TRUE;
	}
	else if (hr == VFW_E_NOT_CONNECTED)
	{
		// The pin is not connected. This is not an error for our purposes.
		*pResult = FALSE;
		hr = S_OK;
	}

	SafeRelease(&pTmp);
	return hr;
}

// Query whether a pin has a specified direction (input / output)
static HRESULT IsPinDirection(IPin *pPin, PIN_DIRECTION dir, BOOL *pResult)
{
	PIN_DIRECTION pinDir;
	HRESULT hr = pPin->QueryDirection(&pinDir);
	if (SUCCEEDED(hr))
	{
		*pResult = (pinDir == dir);
	}
	return hr;
}

// Match a pin by pin direction and connection state.
static HRESULT MatchPin(IPin *pPin, PIN_DIRECTION direction, BOOL bShouldBeConnected, BOOL *pResult)
{
	ASSERT(pResult != NULL);

	BOOL bMatch = FALSE;
	BOOL bIsConnected = FALSE;

	HRESULT hr = IsPinConnected(pPin, &bIsConnected);
	if (SUCCEEDED(hr))
	{
		if (bIsConnected == bShouldBeConnected)
		{
			hr = IsPinDirection(pPin, direction, &bMatch);
		}
	}

	if (SUCCEEDED(hr))
	{
		*pResult = bMatch;
	}
	return hr;
}

// Return the first unconnected input pin or output pin.
static HRESULT FindUnconnectedPin(IBaseFilter *pFilter, PIN_DIRECTION PinDir, IPin **ppPin)
{
	IEnumPins *pEnum = NULL;
	IPin *pPin = NULL;
	BOOL bFound = FALSE;

	HRESULT hr = pFilter->EnumPins(&pEnum);
	if (FAILED(hr))
	{
		goto done;
	}

	while (S_OK == pEnum->Next(1, &pPin, NULL))
	{
		hr = MatchPin(pPin, PinDir, FALSE, &bFound);
		if (FAILED(hr))
		{
			goto done;
		}
		if (bFound)
		{
			*ppPin = pPin;
			(*ppPin)->AddRef();
			break;
		}
		SafeRelease(&pPin);
	}

	if (!bFound)
	{
		hr = VFW_E_NOT_FOUND;
	}

done:
	SafeRelease(&pPin);
	SafeRelease(&pEnum);
	return hr;
}

static HRESULT ConnectFilters(
	IGraphBuilder *pGraph, // Filter Graph Manager.
	IPin *pOut,            // Output pin on the upstream filter.
	IBaseFilter *pDest)    // Downstream filter.
{
	IPin *pIn = NULL;

	// Find an input pin on the downstream filter.
	HRESULT hr = FindUnconnectedPin(pDest, PINDIR_INPUT, &pIn);
	if (SUCCEEDED(hr))
	{
		// Try to connect them.
		hr = pGraph->Connect(pOut, pIn);
		pIn->Release();
	}
	return hr;
}

// Connect filter to filter
static HRESULT ConnectFilters(IGraphBuilder *pGraph, IBaseFilter *pSrc, IBaseFilter *pDest)
{
	IPin *pOut = NULL;

	// Find an output pin on the first filter.
	HRESULT hr = FindUnconnectedPin(pSrc, PINDIR_OUTPUT, &pOut);
	if (SUCCEEDED(hr))
	{
		hr = ConnectFilters(pGraph, pOut, pDest);
		pOut->Release();
	}
	return hr;
}

static HRESULT SaveGraphFile(IGraphBuilder *pGraph, WCHAR *wszPath)
{
	const WCHAR wszStreamName[] = L"ActiveMovieGraph";
	HRESULT hr;

	IStorage *pStorage = NULL;
	hr = StgCreateDocfile(
		wszPath,
		STGM_CREATE | STGM_TRANSACTED | STGM_READWRITE | STGM_SHARE_EXCLUSIVE,
		0, &pStorage);
	if (FAILED(hr))
	{
		return hr;
	}

	IStream *pStream;
	hr = pStorage->CreateStream(
		wszStreamName,
		STGM_WRITE | STGM_CREATE | STGM_SHARE_EXCLUSIVE,
		0, 0, &pStream);
	if (FAILED(hr))
	{
		pStorage->Release();
		return hr;
	}

	IPersistStream *pPersist = NULL;
	pGraph->QueryInterface(IID_IPersistStream, (void**)&pPersist);
	hr = pPersist->Save(pStream, TRUE);
	pStream->Release();
	pPersist->Release();
	if (SUCCEEDED(hr))
	{
		hr = pStorage->Commit(STGC_DEFAULT);
	}
	pStorage->Release();
	return hr;
}


//
static class  SVideoProcessAdapter : public ISampleGrabberCB
{
public:
	SVideoProcessAdapter(VideoPlayer *pOwner) : m_pOwner(pOwner) {}
public:
	virtual ~SVideoProcessAdapter(void) {}

public:
	STDMETHOD(BufferCB)(double SampleTime, BYTE *pBuffer, long nBufferLen)
	{
		return m_pOwner->ProcessFrame(SampleTime, pBuffer, nBufferLen);
	}
	STDMETHOD(SampleCB)(double, IMediaSample *)
	{
		return S_OK;
	}
	STDMETHOD(QueryInterface)(REFIID iid, LPVOID *ppv)
	{
		if (iid == IID_ISampleGrabberCB || iid == IID_IUnknown)
		{
			*ppv = (void *) static_cast<ISampleGrabberCB*>(this);
			return NOERROR;
		}
		return E_NOINTERFACE;
	}
	STDMETHOD_(ULONG, AddRef)() { return 2; }
	STDMETHOD_(ULONG, Release)() { return 1; }

protected:
	VideoPlayer *m_pOwner;
};


static unsigned int g_YUV2PIXEL[256][256][256];

//
VideoPlayer::VideoPlayer(bool renderVisibleOnly, bool verticalFlip)
{

	m_width = m_height = 0;
	m_duration = 0;
	m_nTotalFrames = 0;

	m_pBuffer = NULL;
	m_nBufferLen = 0;

	m_is360 = false;	// Q 2017.8.21

	InitializeCriticalSection(&m_csBuffer);

	// create LUT
	for (int y = 0; y < 256; y++) {
		for (int u = 0; u < 256; u++) {
			for (int v = 0; v < 256; v++) {
				byte b = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 2.018 * (u - 128))));
				byte g = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) - 0.813 * (v - 128) - 0.391 * (u - 128))));
				byte r = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 1.596*(v - 128))));
				byte a = 0xff;
				g_YUV2PIXEL[y][u][v] = COLOR_ARGB(a, b, g, r);
			}
		}
	}

#ifdef _DEBUG
	AllocConsole();
	freopen("CONOUT$", "w", stdout);
	freopen("CONOUT$", "w", stderr);
#endif

	if (m_is360) {
		// �� �� true�� �ϸ� ���� ���� �۵����� ����
		this->SetRenderVisibleOnly(true);
		this->SetVerticalFlip(false);
		printf("SetRenderVisibleOnly  oo");
	}
	else {
		// �� �� true�� �ϸ� ���� ���� �۵����� ����
		this->SetRenderVisibleOnly(renderVisibleOnly);
		this->SetVerticalFlip(verticalFlip);
	}

}


VideoPlayer::~VideoPlayer()
{
	IGraphBuilder *pGraph = (IGraphBuilder *)this->pGraphObj;
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
	IMediaEventEx* pEvent = (IMediaEventEx *)this->pEventObj;
	IBaseFilter* pGrabberF = (IBaseFilter *)this->pGrabberFObj;
	ISampleGrabber* pGrabber = (ISampleGrabber *)this->pGrabberObj;
	IBaseFilter* pSourceF = (IBaseFilter *)this->pSourceFObj;
	IBaseFilter* pNullF = (IBaseFilter *)this->pNullFObj;
	SVideoProcessAdapter* pVideoProcessorAdapter = (SVideoProcessAdapter *)this->pVideoProcessorAdapterObj;

	SafeRelease(&pGraph);
	SafeRelease(&pControl);
	SafeRelease(&pEvent);
	SafeRelease(&pGrabberF);
	SafeRelease(&pGrabber);
	SafeRelease(&pSourceF);
	SafeRelease(&pNullF);
	delete pVideoProcessorAdapter;

	if (m_pBuffer) {
		delete[] m_pBuffer;
	}

	DeleteCriticalSection(&m_csBuffer);
}

bool VideoPlayer::OpenFile(wchar_t* pszVideoFile, bool is360) // Q 2017.8.21
{
	IGraphBuilder *pGraph = NULL;
	IMediaControl *pControl = NULL;
	IMediaEventEx *pEvent = NULL;
	IBaseFilter *pGrabberF = NULL;
	ISampleGrabber *pGrabber = NULL;
	IBaseFilter *pSourceF = NULL;
	IEnumPins *pEnum = NULL;
	IPin *pPin = NULL;
	IBaseFilter *pNullF = NULL;
	SVideoProcessAdapter* pVideoProcessorAdapter = NULL;

	m_is360 = is360; // Q 2017.8.21

	HRESULT hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pGraph));
	ASSERT(hr == S_OK);

	hr = pGraph->QueryInterface(IID_PPV_ARGS(&pControl));
	ASSERT(hr == S_OK);

	hr = pGraph->QueryInterface(IID_PPV_ARGS(&pEvent));
	ASSERT(hr == S_OK);

	// Create the Sample Grabber filter.
	hr = CoCreateInstance(CLSID_SampleGrabber, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pGrabberF));
	ASSERT(hr == S_OK);

	hr = pGraph->AddFilter(pGrabberF, L"Sample Grabber");
	ASSERT(hr == S_OK);

	hr = pGrabberF->QueryInterface(IID_ISampleGrabber, (void **)&pGrabber);
	ASSERT(hr == S_OK);

	AM_MEDIA_TYPE mt;
	ZeroMemory(&mt, sizeof(mt));
	mt.majortype = MEDIATYPE_Video;
	mt.subtype = MEDIASUBTYPE_NV12;

	hr = pGrabber->SetMediaType(&mt);
	ASSERT(hr == S_OK);

	hr = pGraph->AddSourceFilter(pszVideoFile, L"Source", &pSourceF);
	if (hr != S_OK)
		return false;

	ASSERT(hr == S_OK);

	//
	hr = pSourceF->EnumPins(&pEnum);
	ASSERT(hr == S_OK);

	PIN_INFO info;
	while (S_OK == pEnum->Next(1, &pPin, NULL))
	{
		hr = pPin->QueryPinInfo(&info);
		ASSERT(hr == S_OK);
		hr = ConnectFilters(pGraph, pPin, pGrabberF);
		//
		if (SUCCEEDED(hr))
		{
			IPin* pPinNext = NULL;
			hr = pPin->ConnectedTo(&pPinNext);
			ASSERT(hr == S_OK);
			hr = pPinNext->QueryPinInfo(&info);
			ASSERT(hr == S_OK);
			IBaseFilter* pDemuxF = info.pFilter;
			//
			IPin* pPinOutAudio = NULL;
			hr = FindUnconnectedPin(pDemuxF, PINDIR_OUTPUT, &pPinOutAudio);
			if (hr == S_OK && pPinOutAudio != NULL) {
				pGraph->Render(pPinOutAudio);
				SafeRelease(&pPinOutAudio);
			}
			hr = S_OK;
			//
			SafeRelease(&pDemuxF);
			SafeRelease(&pPinNext);
			SafeRelease(&pPin);
			break;
		}
		else {
			SafeRelease(&pPin);
		}
	}
	ASSERT(hr == S_OK);

	hr = CoCreateInstance(CLSID_NullRenderer, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pNullF));
	ASSERT(hr == S_OK);

	hr = pGraph->AddFilter(pNullF, L"Null Filter");
	ASSERT(hr == S_OK);

	hr = ConnectFilters(pGraph, pGrabberF, pNullF);
	ASSERT(hr == S_OK);

	//
	hr = pGrabber->SetBufferSamples(FALSE);
	ASSERT(hr == S_OK);

	pVideoProcessorAdapter = new SVideoProcessAdapter(this);
	hr = pGrabber->SetCallback(pVideoProcessorAdapter, 1);
	ASSERT(hr == S_OK);

	//
	// Retrieve the actual media type
	ZeroMemory(&mt, sizeof(mt));
	hr = pGrabber->GetConnectedMediaType(&mt);
	VIDEOINFOHEADER *pVih;
	if (mt.formattype == FORMAT_VideoInfo) {
		pVih = reinterpret_cast<VIDEOINFOHEADER*>(mt.pbFormat);
	}
	else ASSERT(false);

	this->m_width = pVih->bmiHeader.biWidth;
	this->m_height = pVih->bmiHeader.biHeight;
	this->m_bitCount = pVih->bmiHeader.biBitCount;

	// Get video info
	IMediaSeeking *pSeeking = NULL;
	pGraph->QueryInterface(IID_IMediaSeeking, (void **)(&pSeeking));
	pSeeking->GetDuration(&this->m_duration);
	if (FAILED(pSeeking->SetTimeFormat(&TIME_FORMAT_FRAME))) {
		this->m_nTotalFrames = this->m_duration / pVih->AvgTimePerFrame;
	}
	else {
		pSeeking->GetDuration(&this->m_nTotalFrames);
	}
	SafeRelease(&pSeeking);

	// Free the media type
	if (mt.cbFormat != 0) {
		CoTaskMemFree((PVOID)mt.pbFormat);
		// Strictly unnecessary but tidier
		mt.cbFormat = 0;
		mt.pbFormat = NULL;
	}
	if (mt.pUnk != NULL) {
		// Unnecessary because pUnk should not be used, but safest.
		mt.pUnk->Release();
		mt.pUnk = NULL;
	}

	//
	this->pGraphObj = pGraph;
	this->pControlObj = pControl;
	this->pEventObj = pEvent;
	this->pGrabberFObj = pGrabberF;
	this->pGrabberObj = pGrabber;
	this->pSourceFObj = pSourceF;
	this->pNullFObj = pNullF;
	this->pVideoProcessorAdapterObj = pVideoProcessorAdapter;

	return true;
}

HRESULT VideoPlayer::Run()
{
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
	HRESULT hr = pControl->Run();
	//
	OAFilterState fs;
	pControl->GetState(10000000, &fs);
	if (fs == FILTER_STATE::State_Running) return S_OK;

	return hr;
}

HRESULT VideoPlayer::Pause()
{
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
	HRESULT hr = pControl->Pause();
	//
	OAFilterState fs;
	pControl->GetState(10000000, &fs);
	if (fs == FILTER_STATE::State_Paused) return S_OK;

	return hr;
}

HRESULT VideoPlayer::Stop()
{
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
	HRESULT hr = pControl->Stop();
	//
	OAFilterState fs;
	pControl->GetState(10000000, &fs);
	if (fs == FILTER_STATE::State_Stopped) return S_OK;

	return hr;
}

HRESULT VideoPlayer::ProcessFrame(double SampleTime, BYTE *pBuffer, long nBufferLen)
{
	EnterCriticalSection(&m_csBuffer);

	if (m_nBufferLen < nBufferLen) {
		unsigned char* pNewBuffer = (unsigned char*)realloc(m_pBuffer, nBufferLen);
		if (!pNewBuffer) {
			return E_OUTOFMEMORY;
		}
		m_pBuffer = pNewBuffer;
	}

	memcpy(m_pBuffer, pBuffer, nBufferLen);
	m_nBufferLen = nBufferLen;

	LeaveCriticalSection(&m_csBuffer);

	return S_OK;
}

// should be called by main thread
HRESULT VideoPlayer::LoadTexture(void* pPixels, double rot_x, double rot_y, double rot_z)					// Load bitmaps to texture
{
	EnterCriticalSection(&m_csBuffer);

	if (m_pBuffer != NULL && m_nBufferLen > 0)
	{
		//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, m_bi.bmiHeader.biWidth, m_bi.bmiHeader.biHeight, 0, GL_BGRA_EXT, GL_UNSIGNED_BYTE, m_pBuffer);
		const int nChannels = (m_bitCount / 8);
		unsigned int* pPixel = (unsigned int *)pPixels;
		const int offset_uv = m_width * m_height;

#if false
		for (int row = 0; row < m_height; row++) {
			int index_y = row * m_width;
			int index_uv_0 = offset_uv + (row / 2) * m_width;
			for (int col = 0; col < m_width; col++)
			{
				int index_uv = index_uv_0 + (col & ~1);
				//int index_uv = offset_uv + (row / 2) * m_width + (col / 2) * 2;
				int y = m_pBuffer[index_y];
				int u = m_pBuffer[index_uv];
				int v = m_pBuffer[index_uv + 1];
				pPixel[index_y] = g_YUV2PIXEL[y][u][v];
				//
				index_y++;
#if false
				byte b = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 2.018 * (u - 128))));
				byte g = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) - 0.813 * (v - 128) - 0.391 * (u - 128))));
				byte r = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 1.596*(v - 128))));
				/*
				int index = (row * m_width + col);
				byte b = m_pBuffer[(row * m_width + col) * nChannels];
				byte g = m_pBuffer[(row * m_width + col) * nChannels  + 1];
				byte r = m_pBuffer[(row * m_width + col) * nChannels + 2];*/
				byte a = 0xff;
				pPixel[index_y] = COLOR_ARGB(a, b, g, r);
#endif
			}
		}
#else
		/*LARGE_INTEGER Frequency;
		LARGE_INTEGER BeginTime;
		LARGE_INTEGER Endtime;
		QueryPerformanceFrequency(&Frequency);
		QueryPerformanceCounter(&BeginTime);*/

		// left, top, right, bottom
		//float bounds[] = { 0.0f, 1.0f, 0.0f, 1.0f };
		//int bounds_i[] = { int(bounds[0] * m_width), int(bounds[1] * m_height), int(bounds[2] * m_width), int(bounds[3] * m_height) };
#if true
		//double wu = 0.5 - atan2(view_x, view_z) / (3.1415926535 * 2);
		double wu = 0.5 + rot_y / 360.0;
		if (wu > 1.0) wu -= 1.0;
		//double wv = 0.5 - atan2(-view_y, sqrt(view_x * view_x + view_z * view_z)) / 3.1415926535;
		//double wv = 0.5 - atan2(-view_y, sqrt(view_x * view_x + view_z * view_z)) / 3.1415926535;

		if (rot_x >= 180) rot_x -= 360;
		double wv = 0.5 + rot_x / 180.0;
		//double wv = 0.5 - atan2(-view_y, view_z) / 3.1415926535;
		//fprintf(stderr, "%f %f <- %f %f %f\n", wu, wv, view_x, view_y, view_z);

		wu = MAX(0, MIN(1, wu));
		wv = MAX(0, MIN(1, wv));

		const double view_range_x = 0.24;
		const double view_range_y = MIN(0.25, 0.24 * (1 + (wv - 0.5) * (wv - 0.5) * 3));

		double wv0 = MAX(0, wv - view_range_y);
		double wv1 = MIN(1, wv + view_range_y);

		double u_range0 = view_range_x * 0.5 / (sqrt(0.5 * 0.5 - (wv0 - 0.5) * (wv0 - 0.5)) + 1e-10);
		double u_range1 = view_range_x * 0.5 / (sqrt(0.5 * 0.5 - (wv1 - 0.5) * (wv1 - 0.5)) + 1e-10);
		double u_range = MAX(u_range0, u_range1);

		double wu0 = MAX(-1.0, wu - u_range);
		double wu1 = MIN(2.0, wu + u_range);

		//fprintf(stderr, "%.3lf %.3lf   %.3lf %.3lf %.3lf %.3lf\n", wu, wv, wu0, wu1, wv0, wv1);

		if (wu1 - wu0 > 1.0) wu1 = wu0 + 1.0;

		// �̷��� �ϸ� 360�� ��ü ������ �¿� 30%, ���� 70% (�� 21%)�� ������
		//int bounds_i[] = { int(m_width * 0.0f), int(m_height * 0.3f), int(m_width * 0.3f), int(m_height * 0.7f) };
		//int bounds_i[] = { int(m_width * 0.5f), int(m_height * 0.3f), int(m_width * 0.8f), int(m_height * 0.7f) };
#else
		// �̷��� �ϸ� 360�� ��ü ���� ������
		int bounds_i[] = { 0, 0, m_width, m_height };
#endif

		if (this->bRenderVisibleOnly == false) {
			wu0 = 0; wu1 = 1;
			wv0 = 0; wv1 = 1;
		}

		// �Ϲ� ������ ���� ��ü ������ �ӽ÷� �д�.
		wu0 = 0; wu1 = 1;
		wv0 = 0; wv1 = 1;

		memset(pPixel, COLOR_ARGB(0xff, 128, 128, 128), m_width * m_height * sizeof(unsigned int));

		for (int row = int(m_height * wv0); row < int(m_height * wv1); row++) {
			//
			int bounds_l = int(m_width * wu0);
			int bounds_r = int(m_width * wu1 + 1.0);
			//
			if (bounds_l < 0) {
				bounds_l += m_width;
				int index_y_dst = ((this->bVerticalFlip) ? (m_height - 1 - row) : row) * m_width + bounds_l;
				int index_y = row * m_width + bounds_l;
				int index_uv_0 = offset_uv + (row / 2) * m_width;
				for (int col = bounds_l; col < m_width; col++) {
					int index_uv = index_uv_0 + (col & ~1);
					int y = m_pBuffer[index_y];
					int u = m_pBuffer[index_uv];
					int v = m_pBuffer[index_uv + 1];
					pPixel[index_y_dst] = g_YUV2PIXEL[y][u][v];
					//
					index_y++;
					index_y_dst++;
				}
				//
				bounds_l = 0;
			}
			//
			if (bounds_r > m_width) {
				bounds_r -= m_width;
				int index_y_dst = ((this->bVerticalFlip) ? (m_height - 1 - row) : row) * m_width;
				int index_y = row * m_width;
				int index_uv_0 = offset_uv + (row / 2) * m_width;
				for (int col = 0; col < bounds_r; col++) {
					int index_uv = index_uv_0 + (col & ~1);
					int y = m_pBuffer[index_y];
					int u = m_pBuffer[index_uv];
					int v = m_pBuffer[index_uv + 1];
					pPixel[index_y_dst] = g_YUV2PIXEL[y][u][v];
					//
					index_y++;
					index_y_dst++;
				}
				//
				bounds_r = m_width;
			}
			//
			{
				int index_y_dst = ((this->bVerticalFlip) ? (m_height - 1 - row) : row) * m_width + bounds_l;
				int index_y = row * m_width + bounds_l;
				int index_uv_0 = offset_uv + (row / 2) * m_width;
				for (int col = bounds_l; col < bounds_r; col++) {
					int index_uv = index_uv_0 + (col & ~1);
					int y = m_pBuffer[index_y];
					int u = m_pBuffer[index_uv];
					int v = m_pBuffer[index_uv + 1];
					pPixel[index_y_dst] = g_YUV2PIXEL[y][u][v];
					//
					index_y++;
					index_y_dst++;
				}
			}
		}

		/*QueryPerformanceCounter(&Endtime);
		__int64 elapsed = Endtime.QuadPart - BeginTime.QuadPart;
		double duration = (double)elapsed / (double)Frequency.QuadPart;
		fprintf(stdout, "time: %lf\n", duration);*/
#endif

	}

	LeaveCriticalSection(&m_csBuffer);

	return S_OK;
}

//HRESULT VideoPlayer::SeekToTime(double time)
//{
//	IGraphBuilder *pGraph = (IGraphBuilder *)this->pGraphObj;
//	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
//
//	IMediaSeeking* pSeeking;
//	pGraph->QueryInterface(IID_IMediaSeeking, (void **)(&pSeeking));
//
//	REFERENCE_TIME rtBegin = COARefTime(time);
//	pSeeking->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
//	HRESULT hr = pSeeking->SetPositions(&rtBegin, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
//	if (hr != S_OK) return hr;
//
//	hr = pControl->Pause();
//
//	return hr;
//}

HRESULT VideoPlayer::SeekToTime(double time)
{
	IGraphBuilder *pGraph = (IGraphBuilder *)this->pGraphObj;
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;

	IMediaSeeking* pSeeking;
	pGraph->QueryInterface(IID_IMediaSeeking, (void **)(&pSeeking));

	REFERENCE_TIME rtBegin = COARefTime(time);
	REFERENCE_TIME rtEnd = COARefTime(time + 0.1);

	pSeeking->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
	//HRESULT hr = pSeeking->SetPositions(&rtBegin, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
	HRESULT hr = pSeeking->SetPositions(&rtBegin, AM_SEEKING_AbsolutePositioning, &rtEnd, AM_SEEKING_AbsolutePositioning);
	if (hr != S_OK) return hr;

	IMediaEventEx* pEvent = (IMediaEventEx *)this->pEventObj;

	hr = pControl->Pause();
	hr = pControl->Run();
	//pControl->Pause();

	long evCode;
	hr = pEvent->WaitForCompletion(INFINITE, &evCode);

	hr = pControl->Pause();

	return hr;
}

HRESULT VideoPlayer::SeekToTimeAndRun(double time)
{
	IGraphBuilder *pGraph = (IGraphBuilder *)this->pGraphObj;
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;

	IMediaSeeking* pSeeking;
	pGraph->QueryInterface(IID_IMediaSeeking, (void **)(&pSeeking));

	REFERENCE_TIME rtBegin = COARefTime(time);
	REFERENCE_TIME rtEnd = COARefTime(time + 0.1);

	pSeeking->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);
	HRESULT hr = pSeeking->SetPositions(&rtBegin, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
	//HRESULT hr = pSeeking->SetPositions(&rtBegin, AM_SEEKING_AbsolutePositioning, &rtEnd, AM_SEEKING_AbsolutePositioning);
	if (hr != S_OK) return hr;

	IMediaEventEx* pEvent = (IMediaEventEx *)this->pEventObj;

	hr = pControl->Pause();
	hr = pControl->Run();

	//long evCode;
	//hr = pEvent->WaitForCompletion(INFINITE, &evCode);
	//hr = pControl->Run();

	return hr;
}

float VideoPlayer::GetCurrentPosition()
{
	IGraphBuilder *pGraph = (IGraphBuilder *)this->pGraphObj;
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;

	IMediaSeeking* pSeeking;
	pGraph->QueryInterface(IID_IMediaSeeking, (void **)(&pSeeking));

	pSeeking->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);

	REFERENCE_TIME current;
	REFERENCE_TIME total;
	HRESULT hr = pSeeking->GetPositions(&current, &total);

	if (hr != S_OK)
		return -1.0f;

	COARefTime reftime = current;
	double result = static_cast<double>(reftime);

	return result;
}

float VideoPlayer::GetTotalLength()
{
	IGraphBuilder *pGraph = (IGraphBuilder *)this->pGraphObj;
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;

	IMediaSeeking* pSeeking;
	pGraph->QueryInterface(IID_IMediaSeeking, (void **)(&pSeeking));

	pSeeking->SetTimeFormat(&TIME_FORMAT_MEDIA_TIME);

	REFERENCE_TIME current;
	REFERENCE_TIME total;
	HRESULT hr = pSeeking->GetPositions(&current, &total);

	if (hr != S_OK)
		return -1.0f;

	COARefTime reftime = total;
	double result = static_cast<double>(reftime);

	return result;
}


bool VideoPlayer::CanOpenVideo(wchar_t* pszVideoFile)
{
	HRESULT hr;
	IGraphBuilder* pGraphBuilder;

	hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_ALL, IID_IGraphBuilder, (void**)&pGraphBuilder);

	hr = pGraphBuilder->RenderFile(pszVideoFile, 0);
	IEnumFilters* pEnum;
	hr = pGraphBuilder->EnumFilters(&pEnum);

	bool bRet = (hr == S_OK);

	pEnum->Release();
	pGraphBuilder->Release();

	return bRet;
}

void VideoPlayer::SetVerticalFlip(bool bFlag)
{
	this->bVerticalFlip = bFlag;
}

void VideoPlayer::SetRenderVisibleOnly(bool bFlag)
{
	this->bRenderVisibleOnly = bFlag;
}
