#pragma once

#include "PlatformLink.h"

#ifdef _WIN32PC
#include <Windows.h>
#endif
// by ghostfilm


class _PLATFORM_DECL VideoThumbnail
{
	void* pGraphObj;
	void* pControlObj;
	void* pEventObj;
	void* pGrabberFObj;
	void* pGrabberObj;
	void* pSourceFObj;
	void* pNullFObj;
	void* pVideoProcessorAdapterObj;
	BYTE *m_pBuffer;
	long m_nBufferLen;
	CRITICAL_SECTION  m_csBuffer;

public:
	int m_width;
	int m_height;
	int m_bitCount;
	LONGLONG m_duration;
	LONGLONG m_nTotalFrames;
	wchar_t m_targetOutputDirectory[MAX_PATH];

	VideoThumbnail();
	~VideoThumbnail();
	void OpenFile(wchar_t* pszVideoFile);
	HRESULT GetThumbnail(double t);
	HRESULT DumpAllThumbnails(wchar_t* outputDirectory);
	long long GetDuration();
	void Close();
	HRESULT ProcessFrame(double SampleTime, BYTE *pBuffer, long nBufferLen);
};

