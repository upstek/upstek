


#ifdef USE_PYTHON

#ifdef _WIN32PC
#include <Windows.h>
#endif
#include "video/TexImageVideo.h"
#include "ComponentDictionary.h"

#include "../Platform/Context/Context.h"

#include "BasicType/All.h"

#include "PythonInterface/PythonInterface.h"


extern void Engine_TextureVideo_Play(const es_char * VideoFilePath);
extern void Engine_TextureVideo_Play_time(const es_char * VideoFilePath, double time);
extern void Engine_TextureVideo_Stop(const es_char * VideoFilePath);
extern void Engine_TextureVideo_Pause(const es_char * VideoFilePath);
extern bool Engine_TextureVideo_IsPlaying(const es_char * VideoFilePath);
extern bool Engine_TextureVideo_IsTimeEnd(const es_char * VideoFilePath);
extern float Engine_TextureVideo_GetPlayTime(const es_char * VideoFilePath);
extern bool Engine_TextureVideo_SetPlayTime(const es_char * VideoFilePath, float time);
extern float Engine_TextureVideo_GetTotalPlayTime(const es_char * VideoFilePath);

using namespace EngineNamespace;
using namespace TexImage;


static PyObject* PythonExtend_TextureVideo_Play(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	if (!PyArg_ParseTuple(args, "u", &VideoPath))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_Play");
		return Python::EngineDataToPyObject(0);
	}
	Engine_TextureVideo_Play(VideoPath);
	return Python::EngineDataToPyObject(0);
}

static PyObject* PythonExtend_TextureVideo_Play_time(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	double time;
	if (!PyArg_ParseTuple(args, "ud", &VideoPath, &time))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_Play");
		return Python::EngineDataToPyObject(0);
	}
	Engine_TextureVideo_Play_time(VideoPath, time);
	return Python::EngineDataToPyObject(0);
}

static PyObject* PythonExtend_TextureVideo_Stop(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	if (!PyArg_ParseTuple(args, "u", &VideoPath))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_Stop");
		return Python::EngineDataToPyObject(0);
	}
	Engine_TextureVideo_Stop(VideoPath);
	return Python::EngineDataToPyObject(0);
}

static PyObject* PythonExtend_TextureVideo_Pause(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	if (!PyArg_ParseTuple(args, "u", &VideoPath))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_Pause");
		return Python::EngineDataToPyObject(0);
	}
	Engine_TextureVideo_Pause(VideoPath);
	return Python::EngineDataToPyObject(0);
}

static PyObject* PythonExtend_TextureVideo_IsPlaying(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	if (!PyArg_ParseTuple(args, "u", &VideoPath))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_IsPlaying");
		return Python::EngineDataToPyObject(false);
	}
	bool result = Engine_TextureVideo_IsPlaying(VideoPath);
	return Python::EngineDataToPyObject(result);
}

static PyObject* PythonExtend_TextureVideo_IsTimeEnd(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	if (!PyArg_ParseTuple(args, "u", &VideoPath))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_IsTimeEnd");
		return Python::EngineDataToPyObject(false);
	}
	bool result = Engine_TextureVideo_IsTimeEnd(VideoPath);
	return Python::EngineDataToPyObject(result);
}

static PyObject* PythonExtend_TextureVideo_GetPlayTime(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	if (!PyArg_ParseTuple(args, "u", &VideoPath))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_GetPlayTime");
		return Python::EngineDataToPyObject(-1.0f);
	}
	double result = Engine_TextureVideo_GetPlayTime(VideoPath);
	return Python::EngineDataToPyObject(result);
}

static PyObject* PythonExtend_TextureVideo_SetPlayTime(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	double time;
	if (!PyArg_ParseTuple(args, "ud", &VideoPath, &time))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_SetPlayTime");
		return Python::EngineDataToPyObject(false);
	}
	bool result = Engine_TextureVideo_SetPlayTime(VideoPath, time);
	return Python::EngineDataToPyObject(result);
}

static PyObject* PythonExtend_TextureVideo_GetTotalPlayTime(PyObject* self, PyObject* args)
{
	es_char *VideoPath;
	if (!PyArg_ParseTuple(args, "u", &VideoPath))
	{
		PYTHON_LOG("Invalid Python call parameter to PythonExtend_TextureVideo_GetTotalPlayTime");
		return Python::EngineDataToPyObject(-1.0f);
	}
	double result = Engine_TextureVideo_GetTotalPlayTime(VideoPath);
	return Python::EngineDataToPyObject(result);
}


PYTHON_EXFUNC_METHODDEF_BEGIN(TextureVideo)
PYTHON_EXFUNC_METHODDEF(TextureVideo, Play)
PYTHON_EXFUNC_METHODDEF(TextureVideo, Play_time)
PYTHON_EXFUNC_METHODDEF(TextureVideo, Stop)
PYTHON_EXFUNC_METHODDEF(TextureVideo, Pause)
PYTHON_EXFUNC_METHODDEF(TextureVideo, IsPlaying)
PYTHON_EXFUNC_METHODDEF(TextureVideo, IsTimeEnd)
PYTHON_EXFUNC_METHODDEF(TextureVideo, GetPlayTime)
PYTHON_EXFUNC_METHODDEF(TextureVideo, SetPlayTime)
PYTHON_EXFUNC_METHODDEF(TextureVideo, GetTotalPlayTime)
PYTHON_EXFUNC_METHODDEF_END(TextureVideo)

void PythonEx_Register_TextureVideo()
{
	BasicType::String pythonCode;
	pythonCode =
			"import EngineTextureVideo\n"
			"class TextureVideo(object) :\n"
			"    def __init__(self, VideoPath):\n"
			"        self.VideoPath = VideoPath\n"
			"    def Play(self):\n"
			"        EngineTextureVideo.Play(self.VideoPath)\n"
			"    def Play_time(self,time):\n"
			"        EngineTextureVideo.Play_time(self.VideoPath, time)\n"
			"    def Stop(self):\n"
			"        EngineTextureVideo.Stop(self.VideoPath)\n"
			"    def Pause(self):\n"
			"        EngineTextureVideo.Pause(self.VideoPath)\n"
			"    def IsPlaying(self):\n"
			"        return EngineTextureVideo.IsPlaying(self.VideoPath)\n"
			"    def IsTimeEnd(self):\n"
			"        return EngineTextureVideo.IsTimeEnd(self.VideoPath)\n"
			"    def GetPlayTime(self):\n"
			"        return EngineTextureVideo.GetPlayTime(self.VideoPath)\n"
			"    def SetPlayTime(self, time):\n"
			"        return EngineTextureVideo.SetPlayTime(self.VideoPath, time)\n"
			"    def GetTotalPlayTime(self):\n"
			"        return EngineTextureVideo.GetTotalPlayTime(self.VideoPath)\n"

			
			
		;


	Python::EnginePythonCreateIntellisense(pythonCode, BasicType::String("TextureVideo"), EnablePythonCreateIntellisense);
	Python_RunCode( pythonCode );



}




#endif // USE_PYTHON



