#pragma once
#include "PlatformLink.h"

#include <Windows.h>

// by ghostfilm



class VideoPlayer
{
	void* pGraphObj;
	void* pControlObj;
	void* pEventObj;
	void* pGrabberFObj;
	void* pGrabberObj;
	void* pSourceFObj;
	void* pNullFObj;
	void* pVideoProcessorAdapterObj;
	BYTE *m_pBuffer;
	long m_nBufferLen;
	CRITICAL_SECTION  m_csBuffer;
	bool bVerticalFlip;
	bool bRenderVisibleOnly;
	bool m_is360; // Q 2017.8.21

public:
	int m_width;
	int m_height;
	int m_bitCount;
	LONGLONG m_duration;
	LONGLONG m_nTotalFrames;

	VideoPlayer(bool renderVisibleOnly = true, bool verticalFlip = false);
	~VideoPlayer();
	bool OpenFile(wchar_t* pszVideoFile, bool is360 = false); // Q 2017.8.21
	HRESULT Run();
	HRESULT Pause();
	HRESULT Stop();
	HRESULT ProcessFrame(double SampleTime, BYTE *pBuffer, long nBufferLen);
	HRESULT LoadTexture(void* pPixels, double x, double y, double z);
	HRESULT SeekToTime(double time);
	HRESULT VideoPlayer::SeekToTimeAndRun(double time);
	float GetCurrentPosition();
	float GetTotalLength();
	bool CanOpenVideo(wchar_t* pszVideoFile);
	void SetVerticalFlip(bool bFlag);
	void SetRenderVisibleOnly(bool bFlag);
};

