#ifdef _WIN32PC
#include <Windows.h>
#endif
#include <dshow.h>
#include "qedit.h"
#include <assert.h>
#include <gdiplus.h>

#include "VideoThumbnail.h"

// by ghostfilm


#ifndef COLOR_ARGB
#define COLOR_ARGB(a,r,g,b) ((unsigned long)((((a)&0xff)<<24)|(((r)&0xff)<<16)|(((g)&0xff)<<8)|((b)&0xff)))
#endif

#define MAX(A, B)	(((A) >= (B))? (A) : (B))
#define MIN(A, B)	(((A) <= (B))? (A) : (B))




class _PLATFORM_DECL StaticInitializer
{
	ULONG_PTR gdiplusToken;

public:
	StaticInitializer()
	{
		using namespace Gdiplus;

		CoInitialize(NULL);
		//
		GdiplusStartupInput gdiplusStartupInput;
		GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
	}
	~StaticInitializer()
	{
		using namespace Gdiplus;

		GdiplusShutdown(gdiplusToken);
	}
} g_staticInitializer;




template <class T> static void SafeRelease(T **ppT)
{
	if (*ppT)
	{
		(*ppT)->Release();
		*ppT = NULL;
	}
}

// Query whether a pin is connected to another pin.
//
// Note: This function does not return a pointer to the connected pin.
static HRESULT IsPinConnected(IPin *pPin, BOOL *pResult)
{
	IPin *pTmp = NULL;
	HRESULT hr = pPin->ConnectedTo(&pTmp);
	if (SUCCEEDED(hr))
	{
		*pResult = TRUE;
	}
	else if (hr == VFW_E_NOT_CONNECTED)
	{
		// The pin is not connected. This is not an error for our purposes.
		*pResult = FALSE;
		hr = S_OK;
	}

	SafeRelease(&pTmp);
	return hr;
}

// Query whether a pin has a specified direction (input / output)
static HRESULT IsPinDirection(IPin *pPin, PIN_DIRECTION dir, BOOL *pResult)
{
	PIN_DIRECTION pinDir;
	HRESULT hr = pPin->QueryDirection(&pinDir);
	if (SUCCEEDED(hr))
	{
		*pResult = (pinDir == dir);
	}
	return hr;
}

// Match a pin by pin direction and connection state.
static HRESULT MatchPin(IPin *pPin, PIN_DIRECTION direction, BOOL bShouldBeConnected, BOOL *pResult)
{
	assert(pResult != NULL);

	BOOL bMatch = FALSE;
	BOOL bIsConnected = FALSE;

	HRESULT hr = IsPinConnected(pPin, &bIsConnected);
	if (SUCCEEDED(hr))
	{
		if (bIsConnected == bShouldBeConnected)
		{
			hr = IsPinDirection(pPin, direction, &bMatch);
		}
	}

	if (SUCCEEDED(hr))
	{
		*pResult = bMatch;
	}
	return hr;
}

// Return the first unconnected input pin or output pin.
static HRESULT FindUnconnectedPin(IBaseFilter *pFilter, PIN_DIRECTION PinDir, IPin **ppPin)
{
	IEnumPins *pEnum = NULL;
	IPin *pPin = NULL;
	BOOL bFound = FALSE;

	HRESULT hr = pFilter->EnumPins(&pEnum);
	if (FAILED(hr))
	{
		goto done;
	}

	while (S_OK == pEnum->Next(1, &pPin, NULL))
	{
		hr = MatchPin(pPin, PinDir, FALSE, &bFound);
		if (FAILED(hr))
		{
			goto done;
		}
		if (bFound)
		{
			*ppPin = pPin;
			(*ppPin)->AddRef();
			break;
		}
		SafeRelease(&pPin);
	}

	if (!bFound)
	{
		hr = VFW_E_NOT_FOUND;
	}

done:
	SafeRelease(&pPin);
	SafeRelease(&pEnum);
	return hr;
}

static HRESULT ConnectFilters(
	IGraphBuilder *pGraph, // Filter Graph Manager.
	IPin *pOut,            // Output pin on the upstream filter.
	IBaseFilter *pDest)    // Downstream filter.
{
	IPin *pIn = NULL;

	// Find an input pin on the downstream filter.
	HRESULT hr = FindUnconnectedPin(pDest, PINDIR_INPUT, &pIn);
	if (SUCCEEDED(hr))
	{
		// Try to connect them.
		hr = pGraph->Connect(pOut, pIn);
		pIn->Release();
	}
	return hr;
}

// Connect filter to filter
static HRESULT ConnectFilters(IGraphBuilder *pGraph, IBaseFilter *pSrc, IBaseFilter *pDest)
{
	IPin *pOut = NULL;

	// Find an output pin on the first filter.
	HRESULT hr = FindUnconnectedPin(pSrc, PINDIR_OUTPUT, &pOut);
	if (SUCCEEDED(hr))
	{
		hr = ConnectFilters(pGraph, pOut, pDest);
		pOut->Release();
	}
	return hr;
}

static HRESULT SaveGraphFile(IGraphBuilder *pGraph, WCHAR *wszPath)
{
	const WCHAR wszStreamName[] = L"ActiveMovieGraph";
	HRESULT hr;

	IStorage *pStorage = NULL;
	hr = StgCreateDocfile(
		wszPath,
		STGM_CREATE | STGM_TRANSACTED | STGM_READWRITE | STGM_SHARE_EXCLUSIVE,
		0, &pStorage);
	if (FAILED(hr))
	{
		return hr;
	}

	IStream *pStream;
	hr = pStorage->CreateStream(
		wszStreamName,
		STGM_WRITE | STGM_CREATE | STGM_SHARE_EXCLUSIVE,
		0, 0, &pStream);
	if (FAILED(hr))
	{
		pStorage->Release();
		return hr;
	}

	IPersistStream *pPersist = NULL;
	pGraph->QueryInterface(IID_IPersistStream, (void**)&pPersist);
	hr = pPersist->Save(pStream, TRUE);
	pStream->Release();
	pPersist->Release();
	if (SUCCEEDED(hr))
	{
		hr = pStorage->Commit(STGC_DEFAULT);
	}
	pStorage->Release();
	return hr;
}

static int GetEncoderClsid(const WCHAR* format, CLSID* pClsid)
{
	using namespace Gdiplus;

	UINT  num = 0;          // number of image encoders
	UINT  size = 0;         // size of the image encoder array in bytes

	ImageCodecInfo* pImageCodecInfo = NULL;

	GetImageEncodersSize(&num, &size);
	if (size == 0)
		return -1;  // Failure

	pImageCodecInfo = (ImageCodecInfo*)(malloc(size));
	if (pImageCodecInfo == NULL)
		return -1;  // Failure

	GetImageEncoders(num, size, pImageCodecInfo);

	for (UINT j = 0; j < num; ++j)
	{
		if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0)
		{
			*pClsid = pImageCodecInfo[j].Clsid;
			free(pImageCodecInfo);
			return j;  // Success
		}
	}

	free(pImageCodecInfo);
	return -1;  // Failure
}


//
static class _PLATFORM_DECL SVideoProcessAdapter : public ISampleGrabberCB
{
public:
	SVideoProcessAdapter(VideoThumbnail *pOwner) : m_pOwner(pOwner) {}
public:
	virtual ~SVideoProcessAdapter(void) {}

public:
	STDMETHOD(BufferCB)(double SampleTime, BYTE *pBuffer, long nBufferLen)
	{
		return m_pOwner->ProcessFrame(SampleTime, pBuffer, nBufferLen);
	}
	STDMETHOD(SampleCB)(double, IMediaSample *)
	{
		return S_OK;
	}
	STDMETHOD(QueryInterface)(REFIID iid, LPVOID *ppv)
	{
		if (iid == IID_ISampleGrabberCB || iid == IID_IUnknown)
		{
			*ppv = (void *) static_cast<ISampleGrabberCB*>(this);
			return NOERROR;
		}
		return E_NOINTERFACE;
	}
	STDMETHOD_(ULONG, AddRef)() { return 2; }
	STDMETHOD_(ULONG, Release)() { return 1; }

protected:
	VideoThumbnail *m_pOwner;
};

//
VideoThumbnail::VideoThumbnail()
{
	m_width = m_height = 0;
	m_duration = 0;
	m_nTotalFrames = 0;

	m_pBuffer = NULL;
	m_nBufferLen = 0;

	InitializeCriticalSection(&m_csBuffer);
}


VideoThumbnail::~VideoThumbnail()
{
	this->Close();

	DeleteCriticalSection(&m_csBuffer);
}

void VideoThumbnail::Close()
{
	IGraphBuilder *pGraph = (IGraphBuilder *)this->pGraphObj;
	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
	IMediaEventEx* pEvent = (IMediaEventEx *)this->pEventObj;
	IBaseFilter* pGrabberF = (IBaseFilter *)this->pGrabberFObj;
	ISampleGrabber* pGrabber = (ISampleGrabber *)this->pGrabberObj;
	IBaseFilter* pSourceF = (IBaseFilter *)this->pSourceFObj;
	IBaseFilter* pNullF = (IBaseFilter *)this->pNullFObj;
	SVideoProcessAdapter* pVideoProcessorAdapter = (SVideoProcessAdapter *)this->pVideoProcessorAdapterObj;

	if (pControl != NULL) {
		pControl->Stop();
	}

	SafeRelease(&pGraph);
	SafeRelease(&pControl);
	SafeRelease(&pEvent);
	SafeRelease(&pGrabberF);
	SafeRelease(&pGrabber);
	SafeRelease(&pSourceF);
	SafeRelease(&pNullF);
	delete pVideoProcessorAdapter;

	this->pGraphObj = NULL;
	this->pControlObj = NULL;
	this->pEventObj = NULL;
	this->pGrabberFObj = NULL;
	this->pGrabberObj = NULL;
	this->pSourceFObj = NULL;
	this->pNullFObj = NULL;
	this->pVideoProcessorAdapterObj = NULL;

	if (m_pBuffer) {
		delete[] m_pBuffer;
	}

	m_width = m_height = 0;
	m_duration = 0;
	m_nTotalFrames = 0;

	m_pBuffer = NULL;
	m_nBufferLen = 0;
}

void VideoThumbnail::OpenFile(wchar_t* pszVideoFile)
{
	IGraphBuilder *pGraph = NULL;
	IMediaControl *pControl = NULL;
	IMediaEventEx *pEvent = NULL;
	IBaseFilter *pGrabberF = NULL;
	ISampleGrabber *pGrabber = NULL;
	IBaseFilter *pSourceF = NULL;
	IEnumPins *pEnum = NULL;
	IPin *pPin = NULL;
	IBaseFilter *pNullF = NULL;
	SVideoProcessAdapter* pVideoProcessorAdapter = NULL;

	HRESULT hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pGraph));
	assert(hr == S_OK);

	hr = pGraph->QueryInterface(IID_PPV_ARGS(&pControl));
	assert(hr == S_OK);

	hr = pGraph->QueryInterface(IID_PPV_ARGS(&pEvent));
	assert(hr == S_OK);

	// Create the Sample Grabber filter.
	hr = CoCreateInstance(CLSID_SampleGrabber, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pGrabberF));
	assert(hr == S_OK);

	hr = pGraph->AddFilter(pGrabberF, L"Sample Grabber");
	assert(hr == S_OK);

	hr = pGrabberF->QueryInterface(IID_ISampleGrabber, (void **)&pGrabber);
	assert(hr == S_OK);

	AM_MEDIA_TYPE mt;
	ZeroMemory(&mt, sizeof(mt));
	mt.majortype = MEDIATYPE_Video;
	mt.subtype = MEDIASUBTYPE_NV12;

	hr = pGrabber->SetMediaType(&mt);
	assert(hr == S_OK);

	hr = pGraph->AddSourceFilter(pszVideoFile, L"Source", &pSourceF);
	assert(hr == S_OK);

	//
	hr = pSourceF->EnumPins(&pEnum);
	assert(hr == S_OK);

	//PIN_INFO info;
	while (S_OK == pEnum->Next(1, &pPin, NULL))
	{
		hr = ConnectFilters(pGraph, pPin, pGrabberF);
		SafeRelease(&pPin);
		if (SUCCEEDED(hr))
		{
			break;
		}
	}
	assert(SUCCEEDED(hr));

	hr = CoCreateInstance(CLSID_NullRenderer, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pNullF));
	assert(hr == S_OK);

	hr = pGraph->AddFilter(pNullF, L"Null Filter");
	assert(hr == S_OK);

	hr = ConnectFilters(pGraph, pGrabberF, pNullF);
	assert(hr == S_OK);

	//
	hr = pGrabber->SetBufferSamples(FALSE);
	assert(hr == S_OK);

	pVideoProcessorAdapter = new SVideoProcessAdapter(this);
	hr = pGrabber->SetCallback(pVideoProcessorAdapter, 1);
	assert(hr == S_OK);

	//
	// Retrieve the actual media type
	ZeroMemory(&mt, sizeof(mt));
	hr = pGrabber->GetConnectedMediaType(&mt);
	VIDEOINFOHEADER *pVih;
	if (mt.formattype == FORMAT_VideoInfo) {
		pVih = reinterpret_cast<VIDEOINFOHEADER*>(mt.pbFormat);
	}
	else assert(false);

	this->m_width = pVih->bmiHeader.biWidth;
	this->m_height = pVih->bmiHeader.biHeight;
	this->m_bitCount = pVih->bmiHeader.biBitCount;

	// Get video info
	IMediaSeeking *pSeeking = NULL;
	pGraph->QueryInterface(IID_IMediaSeeking, (void **)(&pSeeking));
	pSeeking->GetDuration(&this->m_duration);
	if (FAILED(pSeeking->SetTimeFormat(&TIME_FORMAT_FRAME))) {
		this->m_nTotalFrames = this->m_duration / pVih->AvgTimePerFrame;
	}
	else {
		pSeeking->GetDuration(&this->m_nTotalFrames);
	}
	SafeRelease(&pSeeking);

	// Free the media type
	if (mt.cbFormat != 0) {
		CoTaskMemFree((PVOID)mt.pbFormat);
		// Strictly unnecessary but tidier
		mt.cbFormat = 0;
		mt.pbFormat = NULL;
	}
	if (mt.pUnk != NULL) {
		// Unnecessary because pUnk should not be used, but safest.
		mt.pUnk->Release();
		mt.pUnk = NULL;
	}

	// set sync source to NULL for the fastest speed
	IMediaFilter *pMediaFilter = 0;
	pGraph->QueryInterface(IID_IMediaFilter, (void**)&pMediaFilter);
	pMediaFilter->SetSyncSource(NULL);
	pMediaFilter->Release();

	//
	this->pGraphObj = pGraph;
	this->pControlObj = pControl;
	this->pEventObj = pEvent;
	this->pGrabberFObj = pGrabberF;
	this->pGrabberObj = pGrabber;
	this->pSourceFObj = pSourceF;
	this->pNullFObj = pNullF;
	this->pVideoProcessorAdapterObj = pVideoProcessorAdapter;
}

HRESULT VideoThumbnail::GetThumbnail(double t)
{
	return S_OK;
}

HRESULT VideoThumbnail::DumpAllThumbnails(wchar_t* outputDirectory)
{
	wcscpy_s(m_targetOutputDirectory, MAX_PATH, outputDirectory);

	IMediaControl* pControl = (IMediaControl *)this->pControlObj;
	HRESULT hr = pControl->Run();

	IMediaEventEx* pEvent = (IMediaEventEx *)this->pEventObj;

	long evCode;
	hr = pEvent->WaitForCompletion(INFINITE, &evCode);

	return hr;
}

long long VideoThumbnail::GetDuration()
{
	return this->m_duration;
}

HRESULT VideoThumbnail::ProcessFrame(double SampleTime, BYTE *pBuffer, long nBufferLen)
{
	using namespace Gdiplus;

	EnterCriticalSection(&m_csBuffer);

	if (m_nBufferLen < nBufferLen) {
		unsigned char* pNewBuffer = (unsigned char*)realloc(m_pBuffer, nBufferLen);
		if (!pNewBuffer) {
			return E_OUTOFMEMORY;
		}
		m_pBuffer = pNewBuffer;
	}

	memcpy(m_pBuffer, pBuffer, nBufferLen);
	m_nBufferLen = nBufferLen;

	//
	Status status;
	const int offset_uv = m_width * m_height;
	Bitmap* bmp = new Bitmap(m_width, m_height, PixelFormat32bppARGB);
	BitmapData bitmapData;
	status = bmp->LockBits(&Rect(0, 0, m_width, m_height), ImageLockModeWrite, PixelFormat32bppARGB, &bitmapData);
	for (int i = 0; i < m_height; i++) {
		unsigned char* pDest = ((unsigned char *)bitmapData.Scan0) + bitmapData.Stride * i;
		for (int j = 0; j < m_width; j++) {
			int index_y = i * m_width + j;
			int index_uv = offset_uv + (i / 2) * m_width + (j / 2) * 2;
			int y = pBuffer[index_y];
			int u = pBuffer[index_uv];
			int v = pBuffer[index_uv + 1];
			pDest[j * 4] = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 2.018 * (u - 128))));
			pDest[j * 4 + 1] = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) - 0.813 * (v - 128) - 0.391 * (u - 128))));
			pDest[j * 4 + 2] = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 1.596*(v - 128))));
			pDest[j * 4 + 3] = 0xff;
		}
	}
	bmp->UnlockBits(&bitmapData);

	wchar_t output_pathname[256];
	wsprintf(output_pathname, L"%s\\frame_%d.jpg", m_targetOutputDirectory, int(SampleTime * 1000));

	CLSID jpgClsid;
	GetEncoderClsid(L"image/jpeg", &jpgClsid);
	bmp->Save(output_pathname, &jpgClsid);

	delete bmp;

	LeaveCriticalSection(&m_csBuffer);

	return S_OK;
}
#if 0
// should be called by main thread
HRESULT VideoThumbnail::LoadTexture(void* pPixels)					// Load bitmaps to texture
{
	EnterCriticalSection(&m_csBuffer);

	if (m_pBuffer != NULL && m_nBufferLen > 0)
	{
		//glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, m_bi.bmiHeader.biWidth, m_bi.bmiHeader.biHeight, 0, GL_BGRA_EXT, GL_UNSIGNED_BYTE, m_pBuffer);
		const int nChannels = (m_bitCount / 8);
		unsigned int* pPixel = (unsigned int *)pPixels;
		const int offset_uv = m_width * m_height;
		for (int row = 0; row < m_height; row++) {
			for (int col = 0; col < m_width; col++)
			{
				int index_y = row * m_width + col;
				int index_uv = offset_uv + (row / 2) * m_width + (col / 2) * 2;
				int y = m_pBuffer[index_y];
				int u = m_pBuffer[index_uv];
				int v = m_pBuffer[index_uv + 1];
				byte b = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 2.018 * (u - 128))));
				byte g = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) - 0.813 * (v - 128) - 0.391 * (u - 128))));
				byte r = (byte)(MAX(0, MIN(255, 1.164 * (y - 16) + 1.596*(v - 128))));
				/*
				int index = (row * m_width + col);
				byte b = m_pBuffer[(row * m_width + col) * nChannels];
				byte g = m_pBuffer[(row * m_width + col) * nChannels  + 1];
				byte r = m_pBuffer[(row * m_width + col) * nChannels + 2];*/
				byte a = 0xff;
				pPixel[index_y] = COLOR_ARGB(a, b, g, r);
			}
		}
	}

	LeaveCriticalSection(&m_csBuffer);

	return S_OK;
}
#endif
