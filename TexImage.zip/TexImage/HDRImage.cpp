#include "BasicType/All.h"

#include "DataCollection/All.h"

#include "HDRImage.h"

#include "rgbe.h"

#include "FileIO/BufferedFile.h"

#include "Debugger/Logger.h"

#include <math.h>

namespace EngineNamespace
{

	namespace TexImage
	{

		TextureImageHDR::TextureImageHDR()
		{
			Pixel = NULL;
			Width = 0;
			Height = 0;
			Channel = 3;
		}

		TextureImageHDR::TextureImageHDR(int width, int height, int channel)
		{
			Pixel = new long[width * height];
			Width = width;
			Height = height;
			Channel = channel;
		}

		TextureImageHDR::~TextureImageHDR()
		{
			Delete<long*>(Pixel);
		}

		bool TextureImageHDR::Prepare(int width, int height, int channel)
		{
			Delete<long*>(Pixel);

			Width = width;
			Height = height;
			Channel = channel;

			return true;
		}

		void TextureImageHDR::Create(int width, int height, int deep, int colortype)
		{
			Pixel = new long[width * height];
			Width = width;
			Height = height;
			Channel = deep;
		}

		#define INVERTED_BIT            (1 << 5)

		#if !defined(_ANDROID) && !defined(_IPHONE) 
		#pragma pack(push,x1)                            // Byte alignment (8-bit)
		#endif

		#pragma pack(1)

				typedef struct
				{
					unsigned char  IdSize,
						MapType,
						ImageType;
					unsigned short PaletteStart,
						PaletteSize;
					unsigned char  PaletteEntryDepth;
					unsigned short X,
						Y,
						Width,
						Height;
					unsigned char  ColorDepth,
						Descriptor;

				} TGA_HEADER;

		#if !defined(_ANDROID) && !defined(_IPHONE) 
		#pragma pack(pop,x1)
		#endif

		

		bool TextureImageHDR::ReadFile(FileIO::Path& fileName)
		{
			FileName = fileName;
			memset(&Res, 0, sizeof(HDRLoaderResult));

			HDRLoader::load(fileName.GetAbsolutePath(), Res);
			Width = Res.width;
			Height = Res.height;
			Pixel = Res.Pixel;

			return true;
		}

		bool TextureImageHDR::SaveFile(FileIO::Path& imageFileName, BasicType::String oldExt)
		{
			Res.Pixel = Pixel;
			HDRLoader::save(imageFileName.GetAbsolutePath(), Res);

			return true;
		}
	}

}