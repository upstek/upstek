#include "BasicType/All.h"

#include "TexImagePalette.h"
#include "DataCollection/All.h"

#ifdef _ANDROID
		#ifndef max
			#define max(a,b)            (((a) > (b)) ? (a) : (b))
		#endif

		#ifndef min
			#define min(a,b)            (((a) < (b)) ? (a) : (b))
		#endif

#endif


#ifdef _DEBUG
	//#define new DEBUG_NEW

	
#endif


namespace EngineNamespace
{



	namespace TexImage
	{





		TextureImagePalette::TextureImagePalette()
		{
			PaletteSize = 0;
			Palette = NULL;

		}


		TextureImagePalette::~TextureImagePalette()
		{
			PaletteSize = 0;
			Delete<TRGBA *>(Palette);
		}


		bool TextureImagePalette::Create(int size)
		{
			PaletteSize = size;
			Delete<TRGBA *>(Palette);
			Palette = new TRGBA[PaletteSize];

			return true;
		}



		unsigned long TextureImagePalette::GetRGB(int index)
		{
			if (index < PaletteSize && index >= 0)
			{
				return MakeRGB(Palette[index].r, Palette[index].g, Palette[index].b) ;
			}
			/*
			for (int i = 0; i < PaletteSize; i ++)
			{
				if (Palette[i].index == index)
					return Palette[i].color;
			}
			*/

			return MakeRGB(0,0,0);
		}





		TRGBA TextureImagePalette::GetRGBA(int index)
		{
			if (index < PaletteSize && index >= 0)
			{
				return Palette[index];
			}
			/*
			for (int i = 0; i < PaletteSize; i ++)
			{
				if (Palette[i].index == index)
					return Palette[i].color;
			}
			*/

			return TRGBA(0,0,0,0);
		}








		bool TextureImagePalette::GetRGB(int index, unsigned char *r, unsigned char *g, unsigned char *b)
		{
			if (index < PaletteSize && index >= 0)
			{
				TRGBA c = Palette[index];
				*r = c.r;
				*g = c.g;
				*b = c.b;
				return true;
			}
			*r = 0;
			*g = 0;
			*b = 0;
			/*
			for (int i = 0; i < PaletteSize; i ++)
			{
				if (Palette[i].index == index)
				{
					unsigned long c = Palette[i].color;
					*r = GetRValue(c);
					*g = GetGValue(c);
					*b = GetBValue(c);
					return true;
				}
			}
			*/
			return false;
		}




		bool TextureImagePalette::GetRGBA(int index, unsigned char *r, unsigned char *g, unsigned char *b, unsigned char *a)
		{
			if (index < PaletteSize && index >= 0)
			{
				TRGBA c = Palette[index];
				*r = c.r;
				*g = c.g;
				*b = c.b;
				*a = c.a;
				return true;
			}
			*r = 0;
			*g = 0;
			*b = 0;
			*a = 0;
			return false;
		}







		int TextureImagePalette::GetIndex(const unsigned char red, const unsigned char green, const unsigned char blue)
		{
			int mindist = 3 * 255*255; 
			int minindex = -1;
			for (int i = 0; i < PaletteSize; i ++)
			{
				int r = Palette[i].r;
				int g = Palette[i].g;
				int b = Palette[i].b;
				int dist = (r-red) * (r-red) + (g-green)*(g-green) + (b-blue)*(b-blue);
				if (minindex == -1 || dist < mindist)
				{
					mindist = dist;
					minindex = i;
				}
			}

			return minindex;

		}



		/*
		void TextureImagePalette::SetPalette(unsigned long n, unsigned char *r, unsigned char *g, unsigned char *b)
		{
			if (!g) 
				g = r;
			if (!b) 
				b = g;

			RGBQUAD* ppal = GetPalette();

			unsigned long m = min( n, PaletteSize );

			for (unsigned long i=0; i<m;i++)
			{
				ppal[i].rgbRed=r[i];
				ppal[i].rgbGreen=g[i];
				ppal[i].rgbBlue=b[i];
			}

			info.last_c_isvalid = false;
		}

		void TextureImagePalette::SetPalette(RGBQUAD* pPal,unsigned long nColors)
		{
			if ((pPal==NULL)||(pDib==NULL)||(head.biClrUsed==0)) 
				return;
			memcpy(GetPalette(),pPal,min(GetPaletteSize(),nColors*sizeof(RGBQUAD)));
			info.last_c_isvalid = false;
		}



		*/


		void TextureImagePalette::SetPalette(TRGB *rgb, unsigned long nColors)
		{
			//if ((!rgb)||(pDib==NULL)||(head.biClrUsed==0)) 
			//	return;
			if ((!rgb) ) 
				return;

			unsigned long m = min(nColors, PaletteSize);
			for (unsigned long i=0; i<m;i++)
			{
				Palette[i].r = rgb[i].r;
				Palette[i].g = rgb[i].g;
				Palette[i].b = rgb[i].b;
				Palette[i].a = 255;
			}

			//info.last_c_isvalid = false;
		}






		////////////////////////////////////////////////////////////////////////////////
		void TextureImagePalette::SetPaletteColor(unsigned char idx, unsigned char r, unsigned char g, unsigned char b, unsigned char alpha)
		{
			if (idx< PaletteSize)
			{
				Palette[idx].b = (unsigned char) b;
				Palette[idx].g = (unsigned char) g;
				Palette[idx].r = (unsigned char) r;
				Palette[idx].a = (unsigned char) alpha;
			}
		}



		void TextureImagePalette::SetGrayPalette()
		{
			for (unsigned long ni=0;ni<PaletteSize;ni++)
				Palette[ni].b
					= Palette[ni].g 
					= Palette[ni].r 
					= (unsigned char)(ni*(255/(PaletteSize-1)));

		}





		bool TextureImagePalette::IsGrayScale()
		{
			if(!(Palette && PaletteSize > 0)) 
				return false;

			for(unsigned long i=0;i<PaletteSize;i++)
			{
				if (Palette[i].b!=i || Palette[i].g!=i || Palette[i].r!=i) 
					return false;
			}
			return true;
		}
		



	}; // namespace

}; // namespace EngineNamespace



