/*
 * File:	cimageb.cc
 * Purpose:	Platform Independent Image Base Class (Windows version)
 * Author:	Alejandro Aguilar Sierra
 * Created:	1995
 * Copyright:	(c) 1995 Alejandro Aguilar Sierra <asierra@servidor.unam.mx>
 */

#include "BasicType/All.h"
//#include <windowsx.h>


#include "DataCollection/All.h"


#include "TexImageBase.h"
#include "TexImagePalette.h"

#ifdef _DEBUG
//#define new DEBUG_NEW


#endif




namespace EngineNamespace
{



	namespace TexImage
	{
			/*
			void AlphaClear();
			void AlphaDelete();
			void AlphaInvert();
			bool AlphaMirror();
			bool AlphaFlip();
			bool AlphaCopy(CxImage &from);
			bool AlphaSplit(CxImage *dest);
			void AlphaStrip();
			void AlphaSet(unsigned char level);
			bool AlphaSet(CxImage &from);
			unsigned char AlphaGetMax() const;
			void AlphaSetMax(unsigned char nAlphaMax);
			bool AlphaIsValid();
			unsigned char* AlphaGetPointer(const long x = 0,const long y = 0);
			bool AlphaFromTransparency();

			void AlphaPaletteClear();
			void AlphaPaletteEnable(bool enable=true);
			bool AlphaPaletteIsEnabled();
			bool AlphaPaletteIsValid();
			bool AlphaPaletteSplit(CxImage *dest);
			*/



		#define DEFAULT_IMAGE_QUALITY 90




		TextureImageBase::TextureImageBase()
		{
			RawImageData = 0; 
			Width = Height = 0;
			Depth = 0;
			ColorType = 0;
			bgindex = -1;
			Quality = DEFAULT_IMAGE_QUALITY;
			Loaded = false;

			ImagePalette = NULL;

			BackGroundIndex = -1;

			AlphaImage = NULL;

			RBSwap = false;

			PsdImg = NULL;

			FileType = -1;

			// Q 2018.4.19
			DXTnBuff = NULL;
		}


		TextureImageBase::TextureImageBase(int width, int height, int depth, int colortype)
		{

			Width = Height = 0;
			Depth = 0;
			ColorType = 0;
			bgindex = -1;
			RawImageData = 0;
			Quality = DEFAULT_IMAGE_QUALITY;

			Create(width, height, depth, colortype);
			Loaded = true;
		}





		bool TextureImageBase::Inside(int x, int y)
		{
			return (0<=y && y<Height && 0<=x && x<Width);
		}







		void
		TextureImageBase::Create(int width, int height, int depth, int colortype)
		{
			Delete<TImagePointerType >(RawImageData);

			Width = width; 
			Height = height; 
			Depth = depth;
			ColorType = (colortype>=0) ? colortype: ((Depth>8) ? COLORTYPE_COLOR: 0);

			RawImageData = 0;
			EffWidth = (long)(((long)Width*Depth + 31) / 32) * 4;
			RawImageData = new unsigned char[height * EffWidth];
			memset(RawImageData, 0, height * EffWidth);
		}

		void TextureImageBase::Create(int width, int height, int deep, int colortype, int eff)
		{
			Delete<TImagePointerType >(RawImageData);

			Width = width;
			Height = height;
			Depth = deep;
			ColorType = (colortype >= 0) ? colortype : ((Depth>8) ? COLORTYPE_COLOR : 0);

			RawImageData = 0;
			EffWidth = eff;
			RawImageData = new unsigned char[height * EffWidth];
			memset(RawImageData, 0, height * EffWidth);
		}




		TextureImageBase::~TextureImageBase ( )
		{
			Delete<unsigned char*>(AlphaImage);
			Delete<unsigned char * >(RawImageData);
			
			
		}




		int TextureImageBase::GetIndex(int x, int y)
		{
			if (!Inside(x, y) || (Depth>8)) return -1;

			TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);
			int index = (int)(*ImagePointer);
			return index;
		}




		bool TextureImageBase::SetIndex(int x, int y, int index)
		{
			if (!Inside(x, y) || (Depth>8)) return false;

			TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);
			*ImagePointer = index;

			return true;
		}








		bool TextureImageBase::GetRGB(int x, int y, byte* r, byte* g, byte* b)
		{
			if (!Inside(x, y)) 
				return false;

			if (ImagePalette) 
				return ImagePalette->GetRGB(GetIndex(x, y), r, g, b);
			else
			{
				TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);
				if (!RBSwap)
				{
					*b = ImagePointer[0];
					*g = ImagePointer[1];
					*r = ImagePointer[2];
				}
				else
				{
					*r = ImagePointer[0];
					*g = ImagePointer[1];
					*b = ImagePointer[2];
				}
			}

			return true;
		}


		bool TextureImageBase::SetRGB(int x, int y, byte r, byte g, byte b)
		{
			if (!Inside(x, y)) 
				return false;

			if (ColorType & COLORTYPE_PALETTE)
			{
				if (!ImagePalette) 
					return false;
				SetIndex(x, y, ImagePalette->GetIndex(r, g, b));

			}
			else
			{
				TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);
				if (!RBSwap)
				{
					ImagePointer[0] = b;
					ImagePointer[1] = g;
					ImagePointer[2] = r;
				}
				else
				{
					ImagePointer[0] = r;
					ImagePointer[1] = g;
					ImagePointer[2] = b;
				}
			}

			return true;
		}





		bool TextureImageBase::GetRGBA(int x, int y, byte* r, byte* g, byte* b, byte *a)
		{
			if (!Inside(x, y)) 
				return false;

			TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);
			if (!RBSwap)
			{
				*b = ImagePointer[0];
				*g = ImagePointer[1];
				*r = ImagePointer[2];
			}
			else
			{
				*r = ImagePointer[0];
				*g = ImagePointer[1];
				*b = ImagePointer[2];
			}

			if (Depth >= 32)
			{
				*a = ImagePointer[3];
			}
			else
			if (AlphaIsValid())
			{
				*a = AlphaGet(x,y);
			}
			else
			{
				*a = 0xFF;
			}

			return true;
		}


		bool TextureImageBase::SetRGBA(int x, int y, byte r, byte g, byte b, byte a)
		{
			if (!Inside(x, y)) 
				return false;

			TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);
			if (!RBSwap)
			{
				ImagePointer[0] = b;
				ImagePointer[1] = g;
				ImagePointer[2] = r;
			}
			else
			{
				ImagePointer[0] = r;
				ImagePointer[1] = g;
				ImagePointer[2] = b;
			}

			if (Depth >= 32)
			{
				ImagePointer[3] = a;
			}
			else
			if (AlphaIsValid())
			{
				AlphaSet(x,y,a);
			}

			return true;
		}




		byte TextureImageBase::GetAlpha(int x, int y)
		{
			if (!Inside(x, y)) 
				return 0xFF;

			TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);

			if (Depth >= 32)
			{
				return ImagePointer[3];
			}
			else
			if (AlphaIsValid())
			{
				return AlphaGet(x,y);
			}
			else
			{
				return 0xFF;
			}

		}


		bool TextureImageBase::SetAlpha(int x, int y, byte a)
		{
			if (!Inside(x, y)) 
				return false;

			TImagePointerType ImagePointer = RawImageData + EffWidth*y + (x*Depth >> 3);

			if (Depth >= 32)
			{
				ImagePointer[3] = a;
			}
			else
			if (AlphaIsValid())
			{
				AlphaSet(x,y,a);
			}

			return true;
		}


		long *TextureImageBase::GetHDRPixel(int x, int y)
		{
			if (x > Width || y > Height)
			{
				return NULL;
			}

			return Pixel + (y * Width + x);
		}

		void TextureImageBase::SetHDRPixel(int x, int y, long pixel)
		{
			if (x > Width || y > Height)
			{
				return;
			}

			Pixel[y * Width + x] = pixel;
		}

		void TextureImageBase::CopyMergedBuffer(DataCollection::Array<psdlite::RGBA, psdlite::RGBA>& sourceArray)
		{
			//std::copy(begin, end, MergedPixelBuffer.begin());
			sourceArray.CopyTo(MergedPixelBuffer);
		}

		bool TextureImageBase::GetLayeredPixel(int layer, int x, int y, int *r, int *g, int *b, int *a)
		{
			if (x > Width - 1 || y > Height - 1)
			{
				return false;
			}
			int sizeX = PsdImg->layers_[layer].data_.get_size().x;
			int sizeY = PsdImg->layers_[layer].data_.get_size().y;

			if (x >sizeX - 1 || y >sizeY - 1)
			{
				return false;
			}
			//psdlite::pixel pic = Img->layers_[layer].data_.get_pixel(offsetX + x, offsetY +y);
			psdlite::pixel pic = PsdImg->layers_[layer].data_.get_pixel(x, y);

			*r = pic.r();
			*g = pic.g();
			*b = pic.b();
			*a = pic.a();

			return true;
		}

		bool TextureImageBase::GetMergedPixel(int x, int y, int * r, int * g, int * b, int * a)
		{
			*a = MergedPixelBuffer[y * Width + x].a;
			*r = MergedPixelBuffer[y * Width + x].r;
			*g = MergedPixelBuffer[y * Width + x].g;
			*b = MergedPixelBuffer[y * Width + x].b;

			return true;
		}

		int TextureImageBase::GetChannelDepth()
		{
			if (PsdImg->layers_.GetSize() <= 0)
				return 0;

			return PsdImg->layers_[0].data_.get_channel_count() * 8;
		}

		int TextureImageBase::GetNumOfLayer()
		{
			//return Img->layers_.GetSize();
			return PsdImg->layers_.GetSize();
		}

		psdlite::vi2 TextureImageBase::GetLayerSize(int layerIndex)
		{
			return PsdImg->layers_[layerIndex].data_.get_size();
		}

		void TextureImageBase::GetOffset(int index, int &x, int &y)
		{
			x = PsdImg->layers_[index].offs_.x;
			y = PsdImg->layers_[index].offs_.y;
		}

		bool TextureImageBase::GetPixelBuffer(squish::u8* pBuffer)
		{

			int nBuffSize = Width * Height * 4;

			int nFlag = DdsImg->GetImageData().format;
			if (nFlag == PicoDDS::FORMAT_BGRA)
			{
				memcpy(pBuffer, DdsImg->GetImageData().imgData, nBuffSize * sizeof(squish::u8));
			}

			else
			{
				if (nFlag == PicoDDS::FORMAT_DXT1)
					squish::DecompressImage(DXTnBuff, Width, Height,
						DdsImg->GetImageData().imgData, squish::kDxt1);
				else if (nFlag == PicoDDS::FORMAT_DXT3)
					squish::DecompressImage(DXTnBuff, Width, Height,
						DdsImg->GetImageData().imgData, squish::kDxt3);
				else if (nFlag == PicoDDS::FORMAT_DXT5)
					squish::DecompressImage(DXTnBuff, Width, Height,
						DdsImg->GetImageData().imgData, squish::kDxt5);

				memcpy(pBuffer, DXTnBuff, nBuffSize * sizeof(squish::u8));
			}


			return true;
		}

		bool TextureImageBase::ParseRGBA(char *bits, unsigned char *r, unsigned char *g, unsigned char *b, unsigned char *a)
		{
			if (Channel >= 3)
			{
				*r = bits[0];
				*g = bits[1];
				*b = bits[2];
			}
			if (Channel > 3) // fix tga alpha bug 2016.07.11
				*a = bits[3];
			else
				*a = 0xff;

			return true;
		}


		char *TextureImageBase::GetPixel(int x, int y)
		{
			if (x >= Width || y >= Height)
				return NULL;

			return Buffer + (y * Width + x) * Channel;
		}

		/*
		void TextureImageBase::TransferBits(TextureImageBase *from)
		{
			if (lpbi)
			{
				GlobalFreePtr(lpbi);
				lpbi = NULL;
			}
			if (imagePalette)
			{
				delete imagePalette;
				imagePalette = NULL;
			}

			lpbi = from->lpbi;
			bgindex = from->bgindex;
			imagePalette = from->imagePalette;
			RawImageData = from->RawImageData;
			Width = from->Width;
			Height = from->Height;
			Depth = from->Depth;
			ColorType = from->ColorType;
			EffWidth = from->EffWidth;
		  
			from->RawImageData = NULL;
			from->lpbi = NULL;
			from->imagePalette = NULL;
		}

		*/




		bool TextureImageBase::AlphaCreate()
		{
			Delete<unsigned char*>(AlphaImage);
			if (AlphaImage==NULL) 
			{
				AlphaImage = new unsigned char[Width * Height];
				if (AlphaImage) 
					memset(AlphaImage, 255, Width * Height);
			}
			return (AlphaImage!=0);
		}




		bool TextureImageBase::AlphaIsValid()
		{
			return AlphaImage!=0;
		}



		unsigned char TextureImageBase::AlphaGet(const long x,const long y)
		{
			if (AlphaImage && Inside(x,y)) 
				return AlphaImage[x+y*Width];
			return 0;
		}



		void TextureImageBase::AlphaSet(const long x,const long y,const unsigned char level)
		{
			if (AlphaImage && Inside(x,y)) 
				AlphaImage[x+y*Width]=level;
		}


		
	}; // namespace

}; // namespace EngineNamespace



