// Special configuration file for building jpeg under CodeWarrior


//#define HAVE_BOOLEAN


