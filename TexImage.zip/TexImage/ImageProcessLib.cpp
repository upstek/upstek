// PhotoForWeb.cpp : Defines the class  behaviors for the application.
//

#include "BasicType/All.h"
#include "ImageProcessLib.h"

#include "TexImageBase.h"

#include "RawImage.h"
#include "PSDImage.h"
#include "HDRImage.h"
#include "DDSImage.h"

#ifdef _DEBUG
//#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



namespace EngineNamespace
{
	namespace TexImage
	{
		void Resize(TextureImageDDS &srcimage, TextureImageBase &tarimage, int w, int h)
		{
			int w0 = srcimage.GetWidth();
			int h0 = srcimage.GetHeight();
			int depth = 32;
			int textureColor = 0;

			if (depth / 8 == 3)
				textureColor = 2;
			else if (depth / 8 == 4)
				textureColor = 6;

			tarimage.Create(w, h, depth, textureColor); // Q 2017.7.26 �ؽ��� Į�� Ÿ�� �߰�
			
			squish::u8 *buffer = new squish::u8[w0 * h0 * 4];
			srcimage.GetPixelBuffer(buffer);

			for (int tx = 0; tx < w; tx++)
				for (int ty = 0; ty < h; ty++)
				{
					unsigned char r, g, b, a;
					double sumr = 0;
					double sumg = 0;
					double sumb = 0;
					double suma = 0;

					double sumarea = 0;

					double sxb = ((double)tx) * w0 / w;
					double syb = ((double)ty) * h0 / h;

					double sxe = ((double)(tx + 1)) * w0 / w;
					double sye = ((double)(ty + 1)) * h0 / h;

					if (sxe > w0)
						sxe = w0;

					if (sye > h0)
						sye = h0;

					if (sxb < 0)
						sxb = 0;

					if (syb < 0)
						syb = 0;


					int cnt = 0;

					
					int xcoord = 0;
					
					for (double sx = sxb; sx < sxe; sx = (int)(sx + 1))
						for (double sy = syb; sy < sye; sy = (int)(sy + 1))
						{
							double sx0 = sx;
							double sy0 = sy;
							double sx1 = (int)(sx + 1);
							double sy1 = (int)(sy + 1);

							if (sx1 > sxe)
								sx1 = sxe;

							if (sy1 > sye)
								sy1 = sye;

							double area = (sx1 - sx0)*(sy1 - sy0);
							sumarea += area;
							cnt++;

							xcoord = (sy * w0 * 4) + sx * 4;
							a = buffer[xcoord + 3];
							b = buffer[xcoord + 2];
							g = buffer[xcoord + 1];
							r = buffer[xcoord];

							sumr += r * area;
							sumg += g * area;
							sumb += b * area;
							suma += a * area;
						}

					if (sumarea > 0)
					{
						unsigned char r2, g2, b2, a2;
						r2 = sumr / sumarea;
						g2 = sumg / sumarea;
						b2 = sumb / sumarea;
						a2 = suma / sumarea;

						if (depth == 32)
							tarimage.SetRGBA(tx, h - ty - 1, r2, g2, b2, a2);
						else
							tarimage.SetRGB(tx, h - ty - 1, r2, g2, b2);

					}
					else
					{
						xcoord = (ty*h0 / h * w0 * 4) + tx*w0 / w * 4;
						a = buffer[xcoord + 3];
						b = buffer[xcoord + 2];
						g = buffer[xcoord + 1];
						r = buffer[xcoord];

						/*long *lp = srcimage.GetPixel(tx*w0 / w, ty*h0 / h);
						tarimage.SetPixel(tx, ty, *lp);*/
						if (depth == 32)
						{
							tarimage.SetRGBA(tx, h - ty - 1, r, g, b, a);
						}
						else
						{
							tarimage.SetRGB(tx, h - ty - 1, r, g, b);
						}
					}
				}

			Delete <squish::u8 *>(buffer);
		}

		void Resize(TextureImageHDR &srcimage, TextureImageHDR &tarimage, int w, int h)
		{
			int w0 = srcimage.GetWidth();
			int h0 = srcimage.GetHeight();
			int channel = srcimage.GetChannel();
			TextureImageHDR hdrImage(w, h, channel);
			tarimage = hdrImage;

			for (int tx = 0; tx < w; tx++)
				for (int ty = 0; ty < h; ty++)
				{
					long r, g, b, e;
					double sumr = 0;
					double sumg = 0;
					double sumb = 0;
					double sume = 0;

					double sumarea = 0;

					double sxb = ((double)tx) * w0 / w;
					double syb = ((double)ty) * h0 / h;

					double sxe = ((double)(tx + 1)) * w0 / w;
					double sye = ((double)(ty + 1)) * h0 / h;

					if (sxe > w0)
						sxe = w0;

					if (sye > h0)
						sye = h0;

					if (sxb < 0)
						sxb = 0;

					if (syb < 0)
						syb = 0;


					int cnt = 0;

					for (double sx = sxb; sx < sxe; sx = (int)(sx + 1))
						for (double sy = syb; sy < sye; sy = (int)(sy + 1))
						{
							double sx0 = sx;
							double sy0 = sy;
							double sx1 = (int)(sx + 1);
							double sy1 = (int)(sy + 1);

							if (sx1 > sxe)
								sx1 = sxe;

							if (sy1 > sye)
								sy1 = sye;

							double area = (sx1 - sx0)*(sy1 - sy0);
							sumarea += area;
							cnt++;

							long *lp = srcimage.GetHDRPixel(sx, sy);
							long pixel = 0;
							if (lp)
							{
								pixel = *lp;
								r = *lp & 0x1ff;
								g = (*lp & ((0x1ff) << 9)) >> 9;
								b = (*lp & ((0x1ff) << 18)) >> 18;
								e = (*lp & ((0x1f) << 27)) >> 27;
							}

							sumr += r * area;
							sumg += g * area;
							sumb += b * area;
							sume += e * area;
						}

					if (sumarea > 0)
					{
						long r2, g2, b2, e2;
						r2 = sumr / sumarea;
						g2 = sumg / sumarea;
						b2 = sumb / sumarea;
						e2 = sume / sumarea;

						tarimage.SetHDRPixel(tx, ty, ((unsigned long)((((e2) & 0x1f) << 27) | (((b2) & 0x1ff) << 18) | (((g2) & 0x1ff) << 9) | ((r2) & 0x1ff))));
					}
					else
					{
						long *lp = srcimage.GetHDRPixel(tx*w0 / w, ty*h0 / h);
						tarimage.SetHDRPixel(tx, ty, *lp);
					}
				}
		}

		void Resize(TextureImageRAW &srcimage, TextureImageBase &tarimage, int w, int h)
		{
			int w0 = srcimage.GetWidth();
			int h0 = srcimage.GetHeight();
			int depth = srcimage.GetChannel() * 8;
			int textureColor = 0;

			if (srcimage.GetChannel() == 3)
			{
				textureColor = 2;
			}

			else if(srcimage.GetChannel() == 4)
			{
				textureColor = 6;
			}
			tarimage.Create(w, h, depth, textureColor); // Q 2017.7.26 �ؽ��� Į�� Ÿ�� �߰�

			for (int tx = 0; tx < w; tx++)
				for (int ty = 0; ty < h; ty++)
				{
					unsigned char r, g, b, a;
					double sumr = 0;
					double sumg = 0;
					double sumb = 0;
					double suma = 0;

					double sumarea = 0;

					double sxb = ((double)tx) * w0 / w;
					double syb = ((double)ty) * h0 / h;

					double sxe = ((double)(tx + 1)) * w0 / w;
					double sye = ((double)(ty + 1)) * h0 / h;

					if (sxe > w0)
						sxe = w0;

					if (sye > h0)
						sye = h0;

					if (sxb < 0)
						sxb = 0;

					if (syb < 0)
						syb = 0;


					int cnt = 0;

					for (double sx = sxb; sx < sxe; sx = (int)(sx + 1))
						for (double sy = syb; sy < sye; sy = (int)(sy + 1))
						{
							double sx0 = sx;
							double sy0 = sy;
							double sx1 = (int)(sx + 1);
							double sy1 = (int)(sy + 1);

							if (sx1 > sxe)
								sx1 = sxe;

							if (sy1 > sye)
								sy1 = sye;

							double area = (sx1 - sx0)*(sy1 - sy0);
							sumarea += area;
							cnt++;

							char *p = srcimage.GetPixel(sx, sy);
							r = p[0];
							g = p[1];
							b = p[2];
							if (srcimage.GetChannel() == 4)
								a = p[3];

							sumr += r * area;
							sumg += g * area;
							sumb += b * area;
							if (srcimage.GetChannel() == 4)
								suma += a * area;
						}

					if (sumarea > 0)
					{
						unsigned char r2, g2, b2, a2;
						r2 = sumr / sumarea;
						g2 = sumg / sumarea;
						b2 = sumb / sumarea;
						a2 = suma / sumarea;

						if (depth == 32)
							tarimage.SetRGBA(tx, h - ty - 1, r2, g2, b2, a2);
						else
							tarimage.SetRGB(tx, h - ty - 1, r2, g2, b2);

					}
					else
					{
						char *srcp = srcimage.GetPixel(tx*w0 / w, ty*h0 / h);
						if (depth == 32)
						{
							tarimage.SetRGBA(tx, h - ty - 1, srcp[0], srcp[1], srcp[2], srcp[3]);
						}
						else
						{
							tarimage.SetRGB(tx, h - ty - 1, srcp[0], srcp[1], srcp[2]);
						}
					}
				}



		}

		void Resize(TextureImageBase &srcimage, TextureImageBase &tarimage, int w, int h, BasicType::String ext)
		{
			int w0 = srcimage.GetWidth();
			int h0 = srcimage.GetHeight();
			
			if (ext == "bmp" || ext == "tga")
			{
				int depth = srcimage.GetChannel() * 8;
				int textureColor = 0;

				if (srcimage.GetChannel() == 3)
				{
					textureColor = 2;
				}

				else if (srcimage.GetChannel() == 4)
				{
					textureColor = 6;
				}
				tarimage.Create(w, h, depth, textureColor); // Q 2017.7.26 �ؽ��� Į�� Ÿ�� �߰�

				for (int tx = 0; tx < w; tx++)
					for (int ty = 0; ty < h; ty++)
					{
						unsigned char r, g, b, a;
						double sumr = 0;
						double sumg = 0;
						double sumb = 0;
						double suma = 0;

						double sumarea = 0;

						double sxb = ((double)tx) * w0 / w;
						double syb = ((double)ty) * h0 / h;

						double sxe = ((double)(tx + 1)) * w0 / w;
						double sye = ((double)(ty + 1)) * h0 / h;

						if (sxe > w0)
							sxe = w0;

						if (sye > h0)
							sye = h0;

						if (sxb < 0)
							sxb = 0;

						if (syb < 0)
							syb = 0;


						int cnt = 0;

						for (double sx = sxb; sx < sxe; sx = (int)(sx + 1))
							for (double sy = syb; sy < sye; sy = (int)(sy + 1))
							{
								double sx0 = sx;
								double sy0 = sy;
								double sx1 = (int)(sx + 1);
								double sy1 = (int)(sy + 1);

								if (sx1 > sxe)
									sx1 = sxe;

								if (sy1 > sye)
									sy1 = sye;

								double area = (sx1 - sx0)*(sy1 - sy0);
								sumarea += area;
								cnt++;

								char *p = srcimage.GetPixel(sx, sy);
								r = p[0];
								g = p[1];
								b = p[2];
								if (srcimage.GetChannel() == 4)
									a = p[3];

								sumr += r * area;
								sumg += g * area;
								sumb += b * area;
								if (srcimage.GetChannel() == 4)
									suma += a * area;
							}

						if (sumarea > 0)
						{
							unsigned char r2, g2, b2, a2;
							r2 = sumr / sumarea;
							g2 = sumg / sumarea;
							b2 = sumb / sumarea;
							a2 = suma / sumarea;

							if (depth == 32)
								tarimage.SetRGBA(tx, h - ty - 1, r2, g2, b2, a2);
							else
								tarimage.SetRGB(tx, h - ty - 1, r2, g2, b2);

						}
						else
						{
							char *srcp = srcimage.GetPixel(tx*w0 / w, ty*h0 / h);
							if (depth == 32)
							{
								tarimage.SetRGBA(tx, h - ty - 1, srcp[0], srcp[1], srcp[2], srcp[3]);
							}
							else
							{
								tarimage.SetRGB(tx, h - ty - 1, srcp[0], srcp[1], srcp[2]);
							}
						}
					}
			}
			else if (ext == "hdr")
			{
				int channel = srcimage.GetChannel();

				tarimage.Create(w, h, channel);
				tarimage.Res.width = w;
				tarimage.Res.height = h;
				memcpy(tarimage.Res.Cmd, srcimage.Res.Cmd, 200);

				for (int tx = 0; tx < w; tx++)
					for (int ty = 0; ty < h; ty++)
					{
						long r, g, b, e;
						double sumr = 0;
						double sumg = 0;
						double sumb = 0;
						double sume = 0;

						double sumarea = 0;

						double sxb = ((double)tx) * w0 / w;
						double syb = ((double)ty) * h0 / h;

						double sxe = ((double)(tx + 1)) * w0 / w;
						double sye = ((double)(ty + 1)) * h0 / h;

						if (sxe > w0)
							sxe = w0;

						if (sye > h0)
							sye = h0;

						if (sxb < 0)
							sxb = 0;

						if (syb < 0)
							syb = 0;


						int cnt = 0;

						for (double sx = sxb; sx < sxe; sx = (int)(sx + 1))
							for (double sy = syb; sy < sye; sy = (int)(sy + 1))
							{
								double sx0 = sx;
								double sy0 = sy;
								double sx1 = (int)(sx + 1);
								double sy1 = (int)(sy + 1);

								if (sx1 > sxe)
									sx1 = sxe;

								if (sy1 > sye)
									sy1 = sye;

								double area = (sx1 - sx0)*(sy1 - sy0);
								sumarea += area;
								cnt++;

								long *lp = srcimage.GetHDRPixel(sx, sy);
								long pixel = 0;
								if (lp)
								{
									pixel = *lp;
									r = *lp & 0x1ff;
									g = (*lp & ((0x1ff) << 9)) >> 9;
									b = (*lp & ((0x1ff) << 18)) >> 18;
									e = (*lp & ((0x1f) << 27)) >> 27;
								}

								sumr += r * area;
								sumg += g * area;
								sumb += b * area;
								sume += e * area;
							}

						if (sumarea > 0)
						{
							long r2, g2, b2, e2;
							r2 = sumr / sumarea;
							g2 = sumg / sumarea;
							b2 = sumb / sumarea;
							e2 = sume / sumarea;

							tarimage.SetHDRPixel(tx, ty, ((unsigned long)((((e2) & 0x1f) << 27) | (((b2) & 0x1ff) << 18) | (((g2) & 0x1ff) << 9) | ((r2) & 0x1ff))));
						}
						else
						{
							long *lp = srcimage.GetHDRPixel(tx*w0 / w, ty*h0 / h);
							tarimage.SetHDRPixel(tx, ty, *lp);
						}
					}
			}
			else if (ext == "jpg" || ext == "png")
			{
				int depth = srcimage.GetDepth();
				int textureColor = srcimage.GetColorType();
				tarimage.Create(w, h, depth, textureColor); // Q 2017.7.26 �ؽ��� Į�� Ÿ�� �߰�

				for (int tx = 0; tx < w; tx++)
					for (int ty = 0; ty < h; ty++)
					{
						unsigned char r, g, b, a;
						double sumr = 0;
						double sumg = 0;
						double sumb = 0;
						double suma = 0;

						double sumarea = 0;

						double sxb = ((double)tx) * w0 / w;
						double syb = ((double)ty) * h0 / h;

						double sxe = ((double)(tx + 1)) * w0 / w;
						double sye = ((double)(ty + 1)) * h0 / h;

						if (sxe > w0)
							sxe = w0;

						if (sye > h0)
							sye = h0;

						if (sxb < 0)
							sxb = 0;

						if (syb < 0)
							syb = 0;


						int cnt = 0;

						for (double sx = sxb; sx < sxe; sx = (int)(sx + 1))
							for (double sy = syb; sy < sye; sy = (int)(sy + 1))
							{
								double sx0 = sx;
								double sy0 = sy;
								double sx1 = (int)(sx + 1);
								double sy1 = (int)(sy + 1);

								if (sx1 > sxe)
									sx1 = sxe;

								if (sy1 > sye)
									sy1 = sye;

								double area = (sx1 - sx0)*(sy1 - sy0);
								sumarea += area;
								cnt++;

								if (depth == 32)
									srcimage.GetRGBA(sx, sy, &r, &g, &b, &a);
								else
								{
									srcimage.GetRGB(sx, sy, &r, &g, &b);
									a = 255;
								}

								sumr += r * area;
								sumg += g * area;
								sumb += b * area;
								suma += a * area;
							}

						if (sumarea > 0)
						{
							unsigned char r2, g2, b2, a2;
							r2 = sumr / sumarea;
							g2 = sumg / sumarea;
							b2 = sumb / sumarea;
							a2 = suma / sumarea;

							if (depth == 32)
								tarimage.SetRGBA(tx, ty, r2, g2, b2, a2);
							else
								tarimage.SetRGB(tx, ty, r2, g2, b2);

						}
						else
						{
							if (depth == 32)
							{
								srcimage.GetRGBA(tx*w0 / w, ty*h0 / h, &r, &g, &b, &a);
								tarimage.SetRGBA(tx, ty, r, g, b, a);
							}
							else
							{
								srcimage.GetRGB(tx*w0 / w, ty*h0 / h, &r, &g, &b);
								tarimage.SetRGB(tx, ty, r, g, b);
							}
						}
					}
			}
			else if(ext == "psd")
			{
				int depth = srcimage.GetChannelDepth();
				int textureColor = 6;

				tarimage.Create(w, h, depth, textureColor); // Q 2017.7.26 �ؽ��� Į�� Ÿ�� �߰�

				for (int tx = 0; tx < w; tx++)
					for (int ty = 0; ty < h; ty++)
					{
						int r, g, b, a;
						double sumr = 0;
						double sumg = 0;
						double sumb = 0;
						double suma = 0;

						double sumarea = 0;

						double sxb = ((double)tx) * w0 / w;
						double syb = ((double)ty) * h0 / h;

						double sxe = ((double)(tx + 1)) * w0 / w;
						double sye = ((double)(ty + 1)) * h0 / h;

						if (sxe > w0)
							sxe = w0;

						if (sye > h0)
							sye = h0;

						if (sxb < 0)
							sxb = 0;

						if (syb < 0)
							syb = 0;


						int cnt = 0;

						for (double sx = sxb; sx < sxe; sx = (int)(sx + 1))
							for (double sy = syb; sy < sye; sy = (int)(sy + 1))
							{
								double sx0 = sx;
								double sy0 = sy;
								double sx1 = (int)(sx + 1);
								double sy1 = (int)(sy + 1);

								if (sx1 > sxe)
									sx1 = sxe;

								if (sy1 > sye)
									sy1 = sye;

								double area = (sx1 - sx0)*(sy1 - sy0);
								sumarea += area;
								cnt++;

								if (depth == 32)
									srcimage.GetMergedPixel(sx, sy, &r, &g, &b, &a);
								else
								{
									srcimage.GetMergedPixel(sx, sy, &r, &g, &b, &a);
								}

								sumr += r * area;
								sumg += g * area;
								sumb += b * area;
								suma += a * area;
							}

						if (sumarea > 0)
						{
							unsigned char r2, g2, b2, a2;
							r2 = sumr / sumarea;
							g2 = sumg / sumarea;
							b2 = sumb / sumarea;
							a2 = suma / sumarea;

							if (depth == 32)
								tarimage.SetRGBA(tx, h - ty - 1, r2, g2, b2, a2);
							else
								tarimage.SetRGB(tx, h - ty - 1, r2, g2, b2);

						}
						else
						{
							if (depth == 32)
							{
								srcimage.GetMergedPixel(tx*w0 / w, ty*h0 / h, &r, &g, &b, &a);
								tarimage.SetRGBA(tx, h - ty - 1, r, g, b, a);
							}
							else
							{
								srcimage.GetMergedPixel(tx*w0 / w, ty*h0 / h, &r, &g, &b, &a);
								tarimage.SetRGB(tx, h - ty - 1, r, g, b);
							}
						}
					}
			}

		}



		void Resize(TextureImageRAW &srcimage, TextureImageRAW &tarimage, int w, int h)
		{
			
			int w0 = srcimage.GetWidth();
			int h0 = srcimage.GetHeight();
			tarimage.Prepare(w, h, srcimage.GetChannel());

			for (int tx = 0; tx < w; tx++)																
			for (int ty = 0; ty < h; ty++)
			{
				unsigned char r, g, b, a;
				double sumr = 0;
				double sumg = 0;
				double sumb = 0;
				double suma = 0;
				double sumarea = 0;

				double sxb = ((double)tx) * w0 / w;
				double syb = ((double)ty) * h0 / h;

				double sxe = ((double)(tx+1)) * w0/ w;
				double sye = ((double)(ty+1)) * h0/ h;

				if (sxe > w0)
					sxe = w0;

				if (sye > h0)
					sye = h0;

				if (sxb < 0)
					sxb = 0;

				if (syb < 0)
					syb = 0;

				
				int cnt = 0;

				for (double sx = sxb; sx < sxe; sx = (int)(sx+1))
				for (double sy = syb; sy < sye; sy = (int)(sy+1))
				{
					double sx0 = sx;
					double sy0 = sy;
					double sx1 = (int)(sx+1);
					double sy1 = (int)(sy+1);

					if (sx1 > sxe)
						sx1 = sxe;

					if (sy1 > sye)
						sy1 = sye;
																								
					double area = (sx1-sx0)*(sy1-sy0);
					sumarea += area;
					cnt ++;

					char *p = srcimage.GetPixel(sx, sy);
					r = p[0];
					g = p[1];
					b = p[2];
					if (srcimage.GetChannel() == 4)
						a = p[3];

					sumr += r * area;
					sumg += g * area;
					sumb += b * area;
					if (srcimage.GetChannel() == 4)
						suma += a * area;

				}

				if (sumarea > 0)
				{
					unsigned char r2, g2, b2, a2;
					r2 = sumr/sumarea;
					g2 = sumg/sumarea;
					b2 = sumb/sumarea;
					if (srcimage.GetChannel() == 4)
						a2 = suma/sumarea;

					char *tarp = tarimage.GetPixel(tx,ty);
					tarp[0] = r2;
					tarp[1] = g2;
					tarp[2] = b2;
					if (srcimage.GetChannel() == 4)
						tarp[3] = a2;
				}
				else
				{
					char *srcp = srcimage.GetPixel(tx*w0/w, ty*h0/h);
					char *tarp = tarimage.GetPixel(tx, ty);
					tarp[0] = srcp[0];
					tarp[1] = srcp[1];
					tarp[2] = srcp[2];
					if (srcimage.GetChannel() == 4)
						tarp[3] = srcp[3];

				}
			}



		}



		#if 0 // currently only tex image
		//
		//			CImage m_Image = 
		// *	R = Y                + 1.40200 * Cr
		// *	G = Y - 0.34414 * Cb - 0.71414 * Cr
		// *	B = Y + 1.77200 * Cb
					


		void Crop(CImage &srcimage, CImage &tarimage, int x, int y, int w, int h);

		void PutToCenter(CImage &srcimage, CImage &tarimage, int xy, unsigned char rf, unsigned char gf, unsigned char bf);


		void Sharpen(CImage &srcmage, CImage &tarimage, int rate = 50);
		void Smooth(CImage &srcmage, CImage &tarimage, int size = 1);
		void Rotate(CImage &srcimage, CImage &tarimage, BOOL clockwise);
		void Rotate180(CImage &srcimage, CImage &tarimage);
		void Flip(CImage &srcimage, CImage &tarimage, BOOL vertical);

		// color
		void RGBtoGrayScale(CImage &srcimage, CImage &tarimage);
		void ChangeBrightness(CImage &srcimage, CImage &tarimage, int rate = 50); // 100 = no change
		void ChangeContrast(CImage &srcimage, CImage &tarimage, int rate = 50); // 100 = no change





		void ResizeI(CImage &srcimage, CImage &tarimage, int w, int h)
		{
			
			int w0 = srcimage.GetWidth();
			int h0 = srcimage.GetHeight();
			tarimage.Create(w,h,24);

			for (int x = 0; x < w; x++)																
			for (int y = 0; y < h; y++)
			{
				unsigned char r, g, b;
				int sumr = 0;
				int sumg = 0;
				int sumb = 0;
				int cnt = 0;

				for (int sx = x*w0/w; sx < (x+1)*w0/w; sx++)
				for (int sy = y*h0/h; sy < (y+1)*h0/h; sy++)
				{
					if (sx >= 0 && sx < w && sy >= 0 && sy < h)
					{
						srcimage.GetRGB(sx, sy, &r, &g, &b);
						sumr += r;
						sumg += g;
						sumb += b;
						cnt ++;
					}
				}
				if (cnt > 0)
				{
					tarimage.SetRGB(x,y, sumr/cnt, sumg/cnt, sumb/cnt);
				}
				else
				{
					srcimage.GetRGB(x*w0/w, y*h0/h, &r,&g,&b);
					tarimage.SetRGB(x,y, r, g, b);
				}
			}



		}






		void PutToCenter(CImage &srcimage, CImage &tarimage, int xy, unsigned char rf, unsigned char gf, unsigned char bf)
		{
			int x = srcimage.GetWidth();
			int y = srcimage.GetHeight();

			tarimage.Create(xy,xy,24);

			for (int i = 0; i < xy; i++)
			for (int j = 0; j < xy; j++)
				tarimage.SetRGB(i,j, rf, gf, bf);

			CImage tmpimage;

			int newsize = xy;
			
			int x2, y2;
			int offsetx = 0;
			int offsety = 0;

			if (x > y) 
			{
				x2 = newsize;
				y2 = y * x2 / x;
				offsety = (xy - y2) / 2 ;
			}
			else
			{
				y2 = newsize;
				x2 = x * y2 / y;
				offsetx = (xy - x2) / 2 ;
			}

			Resize(srcimage, tmpimage, x2, y2);

			for (i = 0; i < x2; i++)
			for (int j = 0; j < y2; j++)
			{
				unsigned char r, g, b;
				tmpimage.GetRGB(i,j, &r, &g, &b);
				tarimage.SetRGB(i+offsetx,j+offsety, r, g, b);
			}

			


		}





		void Crop(CImage &srcimage, CImage &tarimage, int x0, int y0, int w, int h)
		{
			
			int w0 = srcimage.GetWidth();
			int h0 = srcimage.GetHeight();
			tarimage.Create(w,h,24);

			for (int x = 0; x < w; x++)																
			for (int y = 0; y < h; y++)
			{
				unsigned char r, g, b;

				srcimage.GetRGB(x+x0,y+y0, &r,&g,&b);
				tarimage.SetRGB(x,y, r, g, b);
			}



		}






		void Sharpen(CImage &srcimage, CImage &tarimage, int rate )
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(w,h,24);

			for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++)
			{
				unsigned char r, g, b;
				int sumr = 0;
				int sumg = 0;
				int sumb = 0;
				int cnt = 0;

				for (int sx = x-1; sx < x+2; sx++)
				for (int sy = y-1; sy < y+2; sy++)
				{
					if (sx == x && sy == y)
					{
					}
					else
					if (sx >= 0 && sx < w && sy >= 0 && sy < h)
					{
						srcimage.GetRGB(sx, sy, &r, &g, &b);
						sumr -= r;
						sumg -= g;
						sumb -= b;
						cnt ++;
					}

				}
				if (cnt > 0)
				{
					srcimage.GetRGB(x, y, &r, &g, &b);
					sumr += r * cnt;
					sumg += g * cnt;
					sumb += b *  cnt;
					cnt ++;
					int ir = (r+sumr*rate/cnt/100);
					int ig = (g+sumg*rate/cnt/100);
					int ib = (b+sumb*rate/cnt/100);

					ir = ir > 255 ? 255:ir;
					ir = ir < 0 ? 0:ir;
														 
					ig = ig > 255 ? 255:ig;
					ig = ig < 0 ? 0:ig;

					ib = ib > 255 ? 255:ib;
					ib = ib < 0 ? 0:ib;

					tarimage.SetRGB(x,y, ir, ig, ib);
				}
			}

		}






		void Smooth(CImage &srcimage, CImage &tarimage, int size )
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(w,h,24);

			for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++)
			{
				unsigned char r, g, b;
				int sumr = 0;
				int sumg = 0;
				int sumb = 0;
				int cnt = 0;

				for (int sx = x-size; sx < x+size+1; sx++)
				for (int sy = y-size; sy < y+size+1; sy++)
				{
					if (sx >= 0 && sx < w && sy >= 0 && sy < h)
					{
						srcimage.GetRGB(sx, sy, &r, &g, &b);
						sumr += r;
						sumg += g;
						sumb += b;
						cnt ++;
					}
				}
				if (cnt > 0)
				{
					tarimage.SetRGB(x,y, sumr/cnt, sumg/cnt, sumb/cnt);
				}
			}

		}





		void Rotate180(CImage &srcimage, CImage &tarimage)
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(w,h,24);

			for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++)
			{
				byte r, g, b;
				srcimage.GetRGB(w-x-1,h-y-1, &r,&g,&b);
				tarimage.SetRGB(x,y, r,g,b);
			}

		}





		void Flip(CImage &srcimage, CImage &tarimage, BOOL vertical)
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(w,h,24);

			if (vertical)
			{
				for (int x = 0; x < w; x++)
				for (int y = 0; y < h; y++)
				{
					byte r, g, b;
					srcimage.GetRGB(x,h-y-1, &r,&g,&b);
					tarimage.SetRGB(x,y, r,g,b);
				}
			}
			else
			{
				for (int x = 0; x < w; x++)
				for (int y = 0; y < h; y++)
				{
					byte r, g, b;
					srcimage.GetRGB(w-x-1,y, &r,&g,&b);
					tarimage.SetRGB(x,y, r,g,b);
				}
			}

		}





		void Rotate(CImage &srcimage, CImage &tarimage, BOOL clockwise)
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(h,w,24);

			if (clockwise)
			{
				for (int x = 0; x < w; x++)
				for (int y = 0; y < h; y++)
				{
					byte r, g, b;
					srcimage.GetRGB(w-x-1,y, &r,&g,&b);
					tarimage.SetRGB(y, x, r,g,b);
				}
			}
			else
			{
				for (int x = 0; x < w; x++)
				for (int y = 0; y < h; y++)
				{
					byte r, g, b;
					srcimage.GetRGB(x,h-y-1, &r,&g,&b);
					tarimage.SetRGB(y, x, r,g,b);
				}
			}

		}




		void RGBtoGrayScale(CImage &srcimage, CImage &tarimage)
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(w,h,24);
			
			for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++)
			{
				byte r, g, b;
				srcimage.GetRGB(x,y, &r,&g,&b);
				int k =	0.299 * r + 0.587 * g + 0.114 * b;

				if (k > 255)
					k = 255;
				else
				if (k < 0)
					k = 0;
				tarimage.SetRGB(x,y, k,k,k);
			}

		}



		void ChangeBrightness(CImage &srcimage, CImage &tarimage, int rate)
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(w,h,24);
			
			for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++)
			{
				byte r, g, b;
				srcimage.GetRGB(x,y, &r,&g,&b);
				int r2, g2, b2;
				r2 = r * rate / 100;
				g2 = g * rate / 100;
				b2 = b * rate / 100;

				if (r2 > 255)
					r2 = 255;
				else
				if (r2 < 0)
					r2 = 0;

				if (g2 > 255)
					g2 = 255;
				else
				if (g2 < 0)
					g2 = 0;

				if (b2 > 255)
					b2 = 255;
				else
				if (b2 < 0)
					b2 = 0;


				tarimage.SetRGB(x,y, r2, g2, b2);
			}

		}





		void ChangeContrast(CImage &srcimage, CImage &tarimage, int rate)
		{
			int w = srcimage.GetWidth();
			int h = srcimage.GetHeight();
			tarimage.Create(w,h,24);
			
			for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++)
			{
				byte r, g, b;
				srcimage.GetRGB(x,y, &r,&g,&b);
				int r2, g2, b2;
				r2 = 128 + (r - 128) * rate / 100;
				g2 = 128 + (g - 128) * rate / 100;
				b2 = 128 + (b - 128) * rate / 100;

				if (r2 > 255)
					r2 = 255;
				else
				if (r2 < 0)
					r2 = 0;

				if (g2 > 255)
					g2 = 255;
				else
				if (g2 < 0)
					g2 = 0;

				if (b2 > 255)
					b2 = 255;
				else
				if (b2 < 0)
					b2 = 0;


				tarimage.SetRGB(x,y, r2, g2, b2);
			}

		}






		#endif



	}; // namespace

}; // namespace EngineNamespace





