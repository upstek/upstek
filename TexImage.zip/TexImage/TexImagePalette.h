#pragma once

#include "BasicType/All.h"


#include "EngineNamespace.h"






//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 



namespace EngineNamespace
{






	struct _PLATFORM_DECL TRGB 
	{ 
		unsigned char r,g,b; 
	};


	struct _PLATFORM_DECL TRGBA 
	{
		unsigned char    b;
		unsigned char    g;
		unsigned char    r;
		unsigned char    a;

		TRGBA(unsigned char r1, unsigned char g1, unsigned char b1, unsigned char a1)
		{
			r = r1;
			g = g1;
			b = b1;
			a = a1;
		}
		TRGBA() {} 
	} ;




	namespace TexImage
	{



		class _PLATFORM_DECL TextureImagePalette
		{
		public:
			//TextureImageJPG(FileIO::Path& imageFileName ): TextureImageBase(imageFileName) { quality = DEFAULT_QUALITY ; } // PHC changed 30 to 80
			TextureImagePalette();
			virtual ~TextureImagePalette();

			bool Create(int size);
			int PaletteSize;
			TRGBA *Palette;

			unsigned long  GetRGB(int index); // same as COLORREF 
			bool GetRGB(int index, unsigned char *r, unsigned char *g, unsigned char *b);

			TRGBA GetRGBA(int index);
			bool GetRGBA(int index, unsigned char *r, unsigned char *g, unsigned char *b, unsigned char *a);

			int GetIndex(const unsigned char red, const unsigned char green, const unsigned char blue);

			void SetPalette(TRGB *rgb, unsigned long nColors);
			void SetPaletteColor(unsigned char idx, unsigned char r, unsigned char g, unsigned char b, unsigned char alpha=0xFF);
			
			void SetGrayPalette();

			bool IsGrayScale();

			void SwapIndex(unsigned char idx1, unsigned char idx2);

		};



	}; // namespace

}; // namespace EngineNamespace


