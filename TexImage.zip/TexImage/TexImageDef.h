#pragma once

#include "BasicType/All.h"


#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 




namespace EngineNamespace
{


	namespace TexImage
	{

		typedef unsigned char *TImagePointerType;


	};
	/*
	enum {
	CIMAGE_FORMAT_BMP,
	CIMAGE_FORMAT_JPEG,
	CIMAGE_FORMAT_GIF,
	CIMAGE_FORMAT_XPM,
	CIMAGE_FORMAT_PNG,
	CMAX_IMAGE_FORMATS
	};
	*/



	#define CIMAGE_COLORS DIB_PAL_COLORS

	#ifdef WIN32
	#define TEXIMAGE_SUPPORT_BMP 1
	#else
	#define TEXIMAGE_SUPPORT_BMP 0
	#endif

	#define TEXIMAGE_SUPPORT_GIF 1
	#define TEXIMAGE_SUPPORT_JPEG 1
	#define TEXIMAGE_SUPPORT_PNG  1


	#define TEXIMAGE_SUPPORT_XPM  0



	/*
	typedef struct
	{
		byte red;
		byte green;
		 byte blue;
	} rgb_color_struct;
	*/

	#ifndef byte
	typedef unsigned char byte;
	#endif

	#define COLORTYPE_PALETTE	1
	#define COLORTYPE_COLOR		2
	#define COLORTYPE_ALPHA		4





}; // namespace EngineNamespace



