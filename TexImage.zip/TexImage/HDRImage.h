#pragma once

#include "BasicType\All.h"
#include "FileIO\Path.h"

#include "EngineNamespace.h"
#include "TexImageBase.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Q Suhmoon
// Summary : 
// 
//------------------------------------------------------------ 

namespace EngineNamespace
{
	namespace TexImage
	{
		class _PLATFORM_DECL TextureImageHDR : public TextureImageBase
		{
		public:
			TextureImageHDR(int widthm, int height, int channel);
			TextureImageHDR();
			
			bool Prepare(int width, int height, int channel);
			~TextureImageHDR();
			virtual bool ReadFile(FileIO::Path& imageFileName);
			virtual bool SaveFile(FileIO::Path& imageFileName, BasicType::String oldExt = "");
			virtual void Create(int width, int height, int deep, int colortype = -1);

			
		};
	}
}