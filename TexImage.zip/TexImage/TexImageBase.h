#pragma once

#include "BasicType/All.h"
#include "FileIO/Path.h"


#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 




#include "TexImageDef.h"

//#include "cimageb.h"


#include "TexImagePalette.h"

#include "PSDlite.h"

#include "dds\PicoDDS.h"
#include "dds\squish.h"

#include "hdrloader.h"

namespace EngineNamespace
{
	

	namespace TexImage
	{
	#ifdef _USE_DLL
		template class _PLATFORM_DECL DataCollection::Array<psdlite::RGBA, psdlite::RGBA> ;
	#endif

		class _PLATFORM_DECL TextureImageBase
		{
		public:
			TextureImageBase();
			TextureImageBase(int width, int height, int depth, int colortype=-1);
			// Destructor
			virtual ~TextureImageBase();

			bool Loaded;

			int Quality;
			FileIO::Path FileName;

			virtual bool ReadFile(FileIO::Path& imageFileName) { return false; }
			virtual bool SaveFile(FileIO::Path& imageFileName, BasicType::String oldExt = "") { return false; }

			// by ghostfilm, by code3 for Video
			virtual bool HasUpdatedTextureData() { return false; }					// by ghostfilm
			virtual bool GetUpdatedTextureData(void* pPixels) { return false; }		// by ghostfilm

		protected:
			TImagePointerType RawImageData;  		//  Image data

			int Width, Height;   		//  Dimensions
			int Depth;	 				// (bits x pixel)
			int ColorType;				// Bit 1 = Palette used
												// Bit 2 = Color used
												// Bit 3 = Alpha used

			long EffWidth;	 			// Effective Width
			//LPBITMAPINFOHEADER lpbi;
			int bgindex;

			TextureImagePalette *ImagePalette;

			int FileType;

			// HDR
			int Channel;
			long *Pixel;
			

			// PSD
			psdlite::layered_image *PsdImg;
			//std::vector<TexImage::TextureImagePSD::RGBA> MergedPixelBuffer;
			DataCollection::Array<psdlite::RGBA, psdlite::RGBA> MergedPixelBuffer;

			// DDS
			PicoDDS::DDSImg* DdsImg;
			squish::u8* DXTnBuff;

			// TextureImageRAW
			char *Buffer;

			// Q 2018.5.26
			int OriginalWidth, OriginalHeight;

		public:
			HDRLoaderResult Res;
			//  Image Information
			void SetFileType(int fileType) { FileType = fileType; }
			int  GetWidth( void ) const { return Width; };
			int  GetHeight( void ) const { return Height; };
			int  GetDepth( void ) const { return Depth; };
			int  GetColorType( void ) const { return ColorType; };
			int	 GetChannel(void) const { return Channel; };
			virtual bool Inside(int x, int y);
			virtual void Create(int width, int height, int deep, int colortype=-1);
			virtual void Create(int width, int height, int deep, int colortype, int eff);

			// Q 2018.5.26
			int  GetOriginalWidth(void) const { return OriginalWidth; };
			int  GetOriginalHeight(void) const { return OriginalHeight; };
			void  SetOriginalWidth(int oriW) { OriginalWidth = oriW; };
			void  SetOriginalHeight(int oriH) { OriginalHeight = oriH; };
			// Drawing routines

			virtual int  GetIndex(int x, int y);

			// This didn't work (caused black image in Ellipse transform)


			virtual bool GetRGB(int x, int y, byte* r, byte* g, byte* b);
			virtual bool SetIndex(int x, int y, int index);
			virtual bool SetRGB(int x, int y, byte r, byte g, byte b);

			virtual bool GetRGBA(int x, int y, byte* r, byte* g, byte* b, byte *a);
			virtual bool SetRGBA(int x, int y, byte r, byte g, byte b, byte a);

			virtual byte GetAlpha(int x, int y);
			virtual bool SetAlpha(int x, int y, byte a);

			// HDR functions
			virtual long *GetHDRPixel(int x, int y);
			virtual void SetHDRPixel(int x, int y, long pixel);

			// PSD functions
			void CopyMergedBuffer(DataCollection::Array<psdlite::RGBA, psdlite::RGBA>& sourceArray);
			bool GetLayeredPixel(int layer, int x, int y, int *r, int *g, int *b, int *a);
			bool GetMergedPixel(int x, int y, int* r, int* g, int* b, int* a);
			int GetChannelDepth();
			int GetNumOfLayer();
			psdlite::vi2 GetLayerSize(int layerIndex);
			void GetOffset(int index, int &x, int &y);

			// DDS functions
			bool GetPixelBuffer(squish::u8* pBuffer);

			// RAW functions
			char *GetPixel(int x, int y);
			bool ParseRGBA(char *bits, unsigned char *r, unsigned char *g, unsigned char *b, unsigned char *a);

			inline TImagePointerType GetRawImage() { return RawImageData; }
			//inline LPBITMAPINFOHEADER GetBits() { return lpbi; }
			inline long GetEffWidth() { return EffWidth; }

			virtual void SetQuality(int q) {Quality = q;} 

			// 'Copy' the raw image data et. from 'from' to 'this'. NULLify these attributes
			// in 'from' so we can then delete it without deleting the raw image data.
			//void TransferBits(TextureImageBase *from);


		public:
		// new alpha support 

			unsigned char*				AlphaImage; //alpha channel

			bool AlphaCreate();
			bool AlphaIsValid();

			unsigned char AlphaGet(const long x,const long y);
			void AlphaSet(const long x,const long y,const unsigned char level);


			int BackGroundIndex;
			TRGBA BackGroundColor;

			bool RBSwap;
		};









	}; // namespace

}; // namespace EngineNamespace

