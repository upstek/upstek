

#include "BasicType/All.h"

#include "DataCollection/All.h"


#include <stdlib.h>
#include <string.h>
#include "TexImage.h"


#include "TexImajpg.h"
#include "TexImapng.h"
#include "TexImagif.h"
#include "HDRImage.h"
#include "PSDImage.h"
#include "DDSImage.h"
#include "RawImage.h"




#include "Debugger/Logger.h"

#include "Utility/FileTool.h"


// by ghostfilm, by code3 for Video
#ifdef _DX //WIN32PC 
#include "Video/TexImageVideo.h"
#endif




#ifdef _DEBUG
//#define new DEBUG_NEW
#endif



namespace EngineNamespace
{


	namespace TexImage
	{


		TextureImageBase *LoadTextureImage(FileIO::Path &filenameIn, BasicType::String ext)
		{
			if (ext == "")
			{
				ext = filenameIn.GetExt();
				int out = ext.Find(']');
				if (out != -1)
				{
					int size = ext.GetLength();
					char tempBuffer[4];
					tempBuffer[0] = ext.GetAt(0);
					tempBuffer[1] = ext.GetAt(1);
					tempBuffer[2] = ext.GetAt(2);
					tempBuffer[3] = '\0';
					ext = BasicType::String(tempBuffer);
					int temp = 0;
				}
			}
			ext.MakeLower();
#ifdef DEBUG
			Debugger::GetLogger().Log(Debugger::FilterDebug, "Open Texture %s", (const char*)filenameIn.GetPathName() );
#endif // DEBUG

			

			if (ext == "jpg" || ext == "jpeg" )
			{
				TextureImageJPG *image = new TextureImageJPG;
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}
			else
			if (ext == "png" )
			{
				TextureImagePNG *image = new TextureImagePNG;
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}
			else
			if (ext == "gif" )
			{
				CTextureImageGIF *image = new CTextureImageGIF;
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}

			// Q 2017.9.4
			else
			if (ext == "hdr")
			{
				TextureImageHDR *image = new TextureImageHDR();
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}
			else
			if (ext == "psd")
			{
				TextureImagePSD *image = new TextureImagePSD();
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}
			else 
			if (ext == "dds")
			{
				TextureImageDDS *image = new TextureImageDDS();
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}
			else 
			if (ext == "tga")
			{
				TextureImageRAW *image = new TextureImageRAW();
				image->SetFileType(0);
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}
			else
			if (ext == "bmp")
			{
				TextureImageRAW *image = new TextureImageRAW();
				image->SetFileType(1);
				if (image->ReadFile(filenameIn))
				{
					return image;
				}
				else
				{
					delete image;
					return NULL;
				}
			}

			return NULL;
		}

#ifdef _DX
	#if (_MSC_VER >= 1900) // VS 2015 

		// by ghostfilm, by code3 for Video
		TextureVideo *LoadTextureVideo(FileIO::Path &filenameIn, bool is360)
		{
			BasicType::String ext = filenameIn.GetExt();
			ext.MakeLower();

			Debugger::GetLogger().Log(Debugger::FilterDebug, "Open Video %s", (const char*)filenameIn.GetPathName());

			if (ext == "mp4")
			{
				TextureVideo* texVideo = new TextureVideo();
				if (texVideo->ReadFile(filenameIn, is360)) 
				{
					return texVideo;
				}
				else 
				{
					delete texVideo;
					return NULL;
				}
			}

			return NULL;
		}

	#endif
#endif


	}; // namespace

}; // namespace EngineNamespace



