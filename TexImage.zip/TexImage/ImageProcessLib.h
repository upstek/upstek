#pragma once

#include "BasicType/All.h"


#include "EngineNamespace.h"

//------------------------------------------------------------
// Copyright. 2004-2018 Code3 Corp.  http://www.code3.co.kr
// 
// Author : Heechan Park
// Summary : 
// 
//------------------------------------------------------------ 



namespace EngineNamespace
{


	namespace TexImage
	{
		class _PLATFORM_DECL TextureImageBase;
		class _PLATFORM_DECL TextureImageRAW;
		class _PLATFORM_DECL TextureImagePSD;
		class _PLATFORM_DECL TextureImageHDR;
		class _PLATFORM_DECL TextureImageDDS;

		extern void Resize(TextureImageDDS &srcimage, TextureImageBase &tarimage, int w, int h);
		extern void Resize(TextureImageHDR &srcimage, TextureImageHDR &tarimage, int w, int h);
		extern void Resize(TextureImageRAW &srcimage, TextureImageBase &tarimage, int w, int h);
		extern void Resize(TextureImageBase &srcimage, TextureImageBase &tarimage, int w, int h, BasicType::String ext = "");
		extern void Resize(TextureImageRAW &srcimage, TextureImageRAW &tarimage, int w, int h);


	}; // namespace

}; // namespace EngineNamespace

